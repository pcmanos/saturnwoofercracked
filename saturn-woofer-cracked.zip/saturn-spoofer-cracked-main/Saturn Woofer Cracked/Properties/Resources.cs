﻿// Decompiled with JetBrains decompiler
// Type: Saturn.Properties.Resources
// Assembly: Saturn, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 782363C4-840F-42BB-9DE3-89C9DB6D215C
// Assembly location: C:\Users\xande\Desktop\32 bit spy\unpacked_saturn.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Saturn.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (Saturn.Properties.Resources.resourceMan == null)
          Saturn.Properties.Resources.resourceMan = new ResourceManager("Saturn.Properties.Resources", typeof (Saturn.Properties.Resources).Assembly);
        return Saturn.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => Saturn.Properties.Resources.resourceCulture;
      set => Saturn.Properties.Resources.resourceCulture = value;
    }

    internal static Bitmap _1c22433b8d3aec799fd8187ca3030193 => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject("1c22433b8d3aec799fd8187ca3030193", Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap a_12a8d124eb232fb93b8f7b7e152934a4 => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (a_12a8d124eb232fb93b8f7b7e152934a4), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap a_2ac5e2ea57ef6fe001c396cf99280edb => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (a_2ac5e2ea57ef6fe001c396cf99280edb), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap a_444e2cda0e74ed885c48b79012898b10 => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (a_444e2cda0e74ed885c48b79012898b10), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap a_444e2cda0e74ed885c48b79012898b101 => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (a_444e2cda0e74ed885c48b79012898b101), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap a_4bc3eaf172e88b1615d0dc7e9adb9ca8 => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (a_4bc3eaf172e88b1615d0dc7e9adb9ca8), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap download => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (download), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap eternity => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (eternity), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap Full_Moon_Eclipse_2010_Animation => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (Full_Moon_Eclipse_2010_Animation), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap game => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (game), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap hennessy_woofer => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject("hennessy-woofer", Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap IGclout => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (IGclout), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap kindpng_3933927 => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (kindpng_3933927), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap lean_woofer => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject("lean-woofer", Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap pngaaa_com_3790696 => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject("pngaaa.com-3790696", Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap PngItem_2354504 => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (PngItem_2354504), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap PngItem_4777188 => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (PngItem_4777188), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap spoof => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (spoof), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap spoof1 => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (spoof1), Saturn.Properties.Resources.resourceCulture);

    internal static Bitmap valorant => (Bitmap) Saturn.Properties.Resources.ResourceManager.GetObject(nameof (valorant), Saturn.Properties.Resources.resourceCulture);
  }
}
