﻿// Decompiled with JetBrains decompiler
// Type: Saturn.Properties.Settings
// Assembly: Saturn, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 782363C4-840F-42BB-9DE3-89C9DB6D215C
// Assembly location: C:\Users\xande\Desktop\32 bit spy\unpacked_saturn.exe

using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Saturn.Properties
{
  [CompilerGenerated]
  [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.10.0.0")]
  internal sealed class Settings : ApplicationSettingsBase
  {
    private static Settings defaultInstance = (Settings) SettingsBase.Synchronized((SettingsBase) new Settings());

    public static Settings Default
    {
      get
      {
        Settings defaultInstance = Settings.defaultInstance;
        return defaultInstance;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string username
    {
      get => (string) this[nameof (username)];
      set => this[nameof (username)] = (object) value;
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string password
    {
      get => (string) this[nameof (password)];
      set => this[nameof (password)] = (object) value;
    }
  }
}
