﻿// Decompiled with JetBrains decompiler
// Type: Saturn_ProcessedByFody
// Assembly: Saturn, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 782363C4-840F-42BB-9DE3-89C9DB6D215C
// Assembly location: C:\Users\xande\Desktop\32 bit spy\unpacked_saturn.exe

internal class Saturn_ProcessedByFody
{
  internal const string FodyVersion = "6.5.5.0";
  internal const string Costura = "5.7.0";
}
