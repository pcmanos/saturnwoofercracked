﻿// Decompiled with JetBrains decompiler
// Type: NVIDIA_Cleaner.Paths
// Assembly: Saturn, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 782363C4-840F-42BB-9DE3-89C9DB6D215C
// Assembly location: C:\Users\xande\Desktop\32 bit spy\unpacked_saturn.exe

using System;
using System.IO;

namespace NVIDIA_Cleaner
{
  public static class Paths
  {
    public static string SystemPath => Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System));

    public static string AppData => Directory.GetParent(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)).FullName;

    public static string NVCache => Path.Combine(Path.Combine(Path.Combine(Paths.SystemPath, "ProgramData"), "NVIDIA Corporation"), "NV_Cache");

    public static string DCache => Path.Combine(Path.Combine(Paths.AppData, "Local"), "D3DSCache");

    public static string GlCache => Path.Combine(Path.Combine(Path.Combine(Paths.AppData, "Local"), "NVIDIA"), "GLCache");

    public static string Temp => Path.Combine(Path.Combine(Paths.AppData, "Local"), nameof (Temp));
  }
}
