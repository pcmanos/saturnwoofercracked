﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Saturn W00fer  | DimisUI")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Saturn Woofer")]
[assembly: AssemblyCopyright("Saturn Woofer - 2022")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("a982d807-7afa-47fa-a1dc-0671e0edbb8a")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
