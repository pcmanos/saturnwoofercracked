﻿// Decompiled with JetBrains decompiler
// Type: Saturn.Forms.connect
// Assembly: Saturn, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 782363C4-840F-42BB-9DE3-89C9DB6D215C
// Assembly location: C:\Users\xande\Desktop\32 bit spy\unpacked_saturn.exe

using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Suite;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace Saturn.Forms
{
  public class connect : Form
  {
    private IContainer components = (IContainer) null;
    private SiticoneTextBox enterip;
    private SiticoneLabel textip;
    private SiticoneButton siticoneButton1;
    private SiticoneControlBox siticoneControlBox1;

    public connect() => this.InitializeComponent();

    private void siticoneControlBox1_Click(object sender, EventArgs e)
    {
      new Main().Show();
      this.Hide();
    }

    private void connect_Load(object sender, EventArgs e) => this.CenterToParent();

    private void siticoneButton1_Click(object sender, EventArgs e)
    {
      new Process()
      {
        StartInfo = new ProcessStartInfo()
        {
          WindowStyle = ProcessWindowStyle.Hidden,
          FileName = "cmd.exe",
          Arguments = ("/C Start Explorer.exe fivem://connect/" + ((TextBox) this.enterip).Text)
        }
      }.Start();
      Thread.Sleep(1000);
      Application.Exit();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (connect));
      this.enterip = new SiticoneTextBox();
      this.textip = new SiticoneLabel();
      this.siticoneButton1 = new SiticoneButton();
      this.siticoneControlBox1 = new SiticoneControlBox();
      this.SuspendLayout();
      this.enterip.BorderColor = Color.WhiteSmoke;
      this.enterip.BorderRadius = 3;
      ((Control) this.enterip).Cursor = Cursors.IBeam;
      ((TextBox) this.enterip).DefaultText = "127.0.0.1:30120";
      this.enterip.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
      this.enterip.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
      this.enterip.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
      this.enterip.DisabledState.Parent = (TextBox) this.enterip;
      this.enterip.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
      this.enterip.FillColor = Color.FromArgb(47, 48, 51);
      this.enterip.FocusedState.BorderColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.enterip.FocusedState.Parent = (TextBox) this.enterip;
      ((TextBox) this.enterip).ForeColor = Color.Black;
      this.enterip.HoveredState.BorderColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.enterip.HoveredState.Parent = (TextBox) this.enterip;
      ((Control) this.enterip).Location = new Point(68, 21);
      ((Control) this.enterip).Margin = new Padding(4);
      ((Control) this.enterip).Name = "enterip";
      ((TextBox) this.enterip).PasswordChar = char.MinValue;
      this.enterip.PlaceholderText = "";
      ((TextBox) this.enterip).SelectedText = "";
      this.enterip.ShadowDecoration.Parent = (Control) this.enterip;
      ((Control) this.enterip).Size = new Size(109, 22);
      ((Control) this.enterip).TabIndex = 74;
      ((TextBox) this.enterip).TextAlign = HorizontalAlignment.Center;
      ((Control) this.textip).BackColor = Color.Transparent;
      this.textip.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.textip.ForeColor = Color.White;
      ((Control) this.textip).Location = new Point(11, 24);
      ((Control) this.textip).Margin = new Padding(2);
      ((Control) this.textip).Name = "textip";
      ((Control) this.textip).Size = new Size(51, 15);
      ((Control) this.textip).TabIndex = 75;
      ((Control) this.textip).Text = "Server IP:";
      this.siticoneButton1.BorderRadius = 4;
      this.siticoneButton1.BorderThickness = 2;
      this.siticoneButton1.CheckedState.Parent = (CustomButtonBase) this.siticoneButton1;
      this.siticoneButton1.CustomImages.Parent = (CustomButtonBase) this.siticoneButton1;
      this.siticoneButton1.FillColor = Color.FromArgb(47, 48, 51);
      ((Control) this.siticoneButton1).Font = new Font("Segoe UI Black", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      ((Control) this.siticoneButton1).ForeColor = Color.White;
      this.siticoneButton1.HoveredState.Parent = (CustomButtonBase) this.siticoneButton1;
      ((Control) this.siticoneButton1).Location = new Point(184, 21);
      ((Control) this.siticoneButton1).Name = "siticoneButton1";
      this.siticoneButton1.PressedColor = Color.FromArgb(26, 32, 54);
      this.siticoneButton1.ShadowDecoration.Parent = (Control) this.siticoneButton1;
      ((Control) this.siticoneButton1).Size = new Size(69, 23);
      ((Control) this.siticoneButton1).TabIndex = 76;
      ((Control) this.siticoneButton1).Text = "Connect";
      ((Control) this.siticoneButton1).Click += new EventHandler(this.siticoneButton1_Click);
      ((Control) this.siticoneControlBox1).Anchor = AnchorStyles.Top | AnchorStyles.Right;
      this.siticoneControlBox1.BorderRadius = 10;
      this.siticoneControlBox1.FillColor = Color.FromArgb(47, 48, 51);
      this.siticoneControlBox1.HoveredState.FillColor = Color.FromArgb(232, 17, 35);
      this.siticoneControlBox1.HoveredState.IconColor = Color.White;
      this.siticoneControlBox1.HoveredState.Parent = (ControlBox) this.siticoneControlBox1;
      this.siticoneControlBox1.IconColor = Color.White;
      ((Control) this.siticoneControlBox1).Location = new Point(225, 2);
      ((Control) this.siticoneControlBox1).Name = "siticoneControlBox1";
      this.siticoneControlBox1.ShadowDecoration.Parent = (Control) this.siticoneControlBox1;
      ((Control) this.siticoneControlBox1).Size = new Size(31, 15);
      ((Control) this.siticoneControlBox1).TabIndex = 81;
      ((Control) this.siticoneControlBox1).Click += new EventHandler(this.siticoneControlBox1_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = Color.FromArgb(47, 48, 51);
      this.ClientSize = new Size(256, 63);
      this.Controls.Add((Control) this.siticoneControlBox1);
      this.Controls.Add((Control) this.siticoneButton1);
      this.Controls.Add((Control) this.textip);
      this.Controls.Add((Control) this.enterip);
      this.FormBorderStyle = FormBorderStyle.None;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.Name = nameof (connect);
      this.Opacity = 0.85;
      this.Text = "Form1";
      this.Load += new EventHandler(this.connect_Load);
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
