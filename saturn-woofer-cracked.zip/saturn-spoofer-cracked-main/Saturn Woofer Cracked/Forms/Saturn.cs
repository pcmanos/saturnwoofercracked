﻿// Decompiled with JetBrains decompiler
// Type: Saturn.Forms.Saturn
// Assembly: Saturn, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 782363C4-840F-42BB-9DE3-89C9DB6D215C
// Assembly location: C:\Users\xande\Desktop\32 bit spy\unpacked_saturn.exe

using Saturn.Resources;
using Siticone.UI.AnimatorNS;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;
using Siticone.UI.WinForms.Suite;
using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Security.Principal;
using System.Timers;
using System.Windows.Forms;

namespace Saturn.Forms
{
  public class Saturn : Form
  {
    public static api KeyAuthApp = new api("Saturn-Woofer", "eL5ziJxiR9", "aca66f187acb76f8bcf4005a5157f0f531410c08cccb7ceb7bb50a3754a842e9", "1.6");
    private bool mouseDown;
    private Point lastLocation;
    private IContainer components = (IContainer) null;
    private SiticoneDragControl siticoneDragControl1;
    private SiticoneControlBox siticoneControlBox1;
    private SiticoneControlBox siticoneControlBox2;
    private SiticoneTransition siticoneTransition1;
    private Label label1;
    private Label label2;
    private SiticoneShadowForm siticoneShadowForm;
    private SiticoneButton siticoneButton1;
    private SiticoneButton PingButton;
    private SiticoneTextBox UsernameTB;
    private Label label10;
    private Label label3;
    private SiticoneTextBox siticoneTextBox2;
    private Label label4;
    private Label label6;
    private SiticoneTextBox siticoneTextBox4;
    private Label label5;
    private SiticoneTextBox siticoneTextBox3;
    private SiticoneButton siticoneButton2;
    private SiticoneButton siticoneButton3;
    private SiticoneTextBox siticoneTextBox1;
    private SiticoneLabel siticoneLabel8;
    private System.Windows.Forms.Timer timer210;
    private System.Windows.Forms.Timer timer2310;

    public object JsonConvert { get; private set; }

    public Saturn()
    {
      System.Timers.Timer timer = new System.Timers.Timer(50.0);
      timer.AutoReset = true;
      timer.Elapsed += new ElapsedEventHandler(Saturn.Forms.Saturn.MyMethod);
      timer.Start();
      this.InitializeComponent();
      this.label4.Hide();
      ((Control) this.siticoneTextBox2).Hide();
      this.label5.Hide();
      ((Control) this.siticoneTextBox3).Hide();
      this.label6.Hide();
      ((Control) this.siticoneTextBox4).Hide();
      ((Control) this.siticoneButton2).Hide();
      ((Control) this.siticoneButton3).Hide();
    }

    public static void MyMethod(object sender, ElapsedEventArgs e) => Saturn.Forms.Saturn.DimisProtection();

    private void siticoneControlBox1_Click(object sender, EventArgs e) => Environment.Exit(0);

    private static void DimisProtection()
    {
      if (Process.GetProcessesByName("dnSpy").Length != 0)
      {
        Process.Start(new ProcessStartInfo("shutdown.exe", "-r -t 0")
        {
          CreateNoWindow = true,
          UseShellExecute = false,
          ErrorDialog = false
        });
        Process.Start("cmd.exe", "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath);
        Application.Exit();
      }
      if (Process.GetProcessesByName("ida64").Length != 0)
      {
        Process.Start(new ProcessStartInfo("shutdown.exe", "-r -t 0")
        {
          CreateNoWindow = true,
          UseShellExecute = false,
          ErrorDialog = false
        });
        Process.Start("cmd.exe", "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath);
        Application.Exit();
      }
      if (Process.GetProcessesByName("64dbg").Length != 0)
      {
        Process.Start(new ProcessStartInfo("shutdown.exe", "-r -t 0")
        {
          CreateNoWindow = true,
          UseShellExecute = false,
          ErrorDialog = false
        });
        Process.Start("cmd.exe", "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath);
        Application.Exit();
      }
      if (Process.GetProcessesByName("ollydbg").Length != 0)
      {
        Process.Start(new ProcessStartInfo("shutdown.exe", "-r -t 0")
        {
          CreateNoWindow = true,
          UseShellExecute = false,
          ErrorDialog = false
        });
        Process.Start("cmd.exe", "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath);
        Application.Exit();
      }
      if (Process.GetProcessesByName("x32dbg").Length != 0)
      {
        Process.Start(new ProcessStartInfo("shutdown.exe", "-r -t 0")
        {
          CreateNoWindow = true,
          UseShellExecute = false,
          ErrorDialog = false
        });
        Process.Start("cmd.exe", "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath);
        Application.Exit();
      }
      if (Process.GetProcessesByName("MasterDumper").Length == 0)
        return;
      Process.Start(new ProcessStartInfo("shutdown.exe", "-r -t 0")
      {
        CreateNoWindow = true,
        UseShellExecute = false,
        ErrorDialog = false
      });
      Process.Start("cmd.exe", "/C choice /C Y /N /D Y /T 3 & Del " + Application.ExecutablePath);
      Application.Exit();
    }

    private void Login_Load(object sender, EventArgs e)
    {
      string path = "C:\\Program Files\\SaturnWoofer";
      if (!Directory.Exists(path))
        Directory.CreateDirectory(path);
      try
      {
        Ping ping = new Ping();
        string hostNameOrAddress = "google.com";
        byte[] buffer = new byte[32];
        int timeout = 1000;
        PingOptions options = new PingOptions();
        ping.Send(hostNameOrAddress, timeout, buffer, options);
      }
      catch (Exception ex)
      {
        this.Hide();
        int num = (int) MessageBox.Show("Failed to access netservers, check your connection.", "Saturn Woofer - Protection", MessageBoxButtons.OK);
      }
      string friendlyName = AppDomain.CurrentDomain.FriendlyName;
      if (!(friendlyName == "Saturn.exe"))
      {
        this.Hide();
        int num = (int) MessageBox.Show("Program Filename( " + friendlyName + " ) was changed, download again.", "Saturn Woofer", MessageBoxButtons.OK);
        Application.Exit();
      }
      Saturn.Forms.Saturn.DimisProtection();
      Directory.CreateDirectory("C:\\Program Files\\SaturnWoofer");
      ((Control) this.siticoneLabel8).Show();
      Directory.CreateDirectory("C:\\Program Files\\SaturnWoofer");
      if (System.IO.File.Exists("C:\\Program Files\\saturn-user.txt"))
        ((TextBox) this.UsernameTB).Text = System.IO.File.ReadAllText("C:\\Program Files\\saturn-user.txt");
      if (System.IO.File.Exists("C:\\Program Files\\saturn-passwd.txt"))
        ((TextBox) this.siticoneTextBox1).Text = System.IO.File.ReadAllText("C:\\Program Files\\saturn-passwd.txt");
      this.Size = new Size(219, 235);
      Saturn.Forms.Saturn.KeyAuthApp.init();
      if (new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))
      {
        if (Saturn.Forms.Saturn.KeyAuthApp.response.success)
          return;
        switch (MessageBox.Show("A new version is unavailable, do you want to use it or exit?", "Saturn - Auto Updater", MessageBoxButtons.OKCancel))
        {
          case DialogResult.OK:
            Process.Start(Saturn.Forms.Saturn.KeyAuthApp.app_data.downloadLink);
            Environment.Exit(0);
            break;
          case DialogResult.Cancel:
            Application.Exit();
            break;
        }
      }
      else
      {
        int num = (int) MessageBox.Show("Please Run As Admin", "Saturn Woofer", MessageBoxButtons.OK);
        Application.Exit();
      }
    }

    private static string random_string()
    {
      string str = (string) null;
      Random random = new Random();
      for (int index = 0; index < 5; ++index)
        str += Convert.ToChar(Convert.ToInt32(Math.Floor(26.0 * random.NextDouble() + 65.0))).ToString();
      return str;
    }

    public static void sendWebHook(string Url, string msg, string Username, string Plan) => Saturn.Resources.Http.Post(Url, new NameValueCollection()
    {
      {
        "username",
        Username
      },
      {
        "content",
        msg
      },
      {
        "content",
        Plan
      }
    });

    public static void sendWebHookregister(
      string Url,
      string msg,
      string Username,
      string Plan,
      string Key)
    {
      Saturn.Resources.Http.Post(Url, new NameValueCollection()
      {
        {
          "username",
          Username
        },
        {
          "content",
          msg
        },
        {
          "content",
          Plan
        },
        {
          "content",
          Key
        }
      });
    }

    private void PingButton_Click(object sender, EventArgs e)
    {
      Directory.CreateDirectory("C:\\Program Files\\SaturnWoofer");
      try
      {
        Saturn.Forms.Saturn.KeyAuthApp.login(((TextBox) this.UsernameTB).Text, ((TextBox) this.siticoneTextBox1).Text);
        if (Saturn.Forms.Saturn.KeyAuthApp.response.success)
        {
          string[] strArray1 = new string[1]
          {
            ((TextBox) this.UsernameTB).Text
          };
          string path1_1 = "C:\\Program Files";
          string path1 = "C:\\Program Files\\saturn-user.txt";
          if (System.IO.File.Exists(path1))
            System.IO.File.Delete(path1);
          using (StreamWriter streamWriter = new StreamWriter(Path.Combine(path1_1, "saturn-user.txt")))
          {
            foreach (string str in strArray1)
              streamWriter.WriteLine(str);
          }
          string[] strArray2 = new string[1]
          {
            ((TextBox) this.siticoneTextBox1).Text
          };
          string path1_2 = "C:\\Program Files";
          string path2 = "C:\\Program Files\\saturn-passwd.txt";
          if (System.IO.File.Exists(path2))
            System.IO.File.Delete(path2);
          using (StreamWriter streamWriter = new StreamWriter(Path.Combine(path1_2, "saturn-passwd.txt")))
          {
            foreach (string str in strArray2)
              streamWriter.WriteLine(str);
          }
          string[] strArray3 = new string[1]
          {
            ((TextBox) this.UsernameTB).Text
          };
          string path1_3 = "C:\\Program Files";
          string path3 = "C:\\Program Files\\saturn-userv2.txt";
          if (System.IO.File.Exists(path3))
            System.IO.File.Delete(path3);
          using (StreamWriter streamWriter = new StreamWriter(Path.Combine(path1_3, "saturn-userv2.txt")))
          {
            foreach (string str in strArray3)
              streamWriter.WriteLine(str);
          }
          string[] strArray4 = new string[1]
          {
            ((TextBox) this.siticoneTextBox1).Text
          };
          string path1_4 = "C:\\Program Files";
          string path4 = "C:\\Program Files\\saturn-passwdv2.txt";
          if (System.IO.File.Exists(path4))
            System.IO.File.Delete(path4);
          using (StreamWriter streamWriter = new StreamWriter(Path.Combine(path1_4, "saturn-passwdv2.txt")))
          {
            foreach (string str in strArray4)
              streamWriter.WriteLine(str);
          }
          new Main().Show();
          this.Hide();
        }
        else
        {
          int num = (int) MessageBox.Show(Saturn.Forms.Saturn.KeyAuthApp.response.message, "Saturn: Failed to login", MessageBoxButtons.OK);
        }
      }
      catch
      {
      }
    }

    private void siticoneButton1_Click(object sender, EventArgs e)
    {
      ((Control) this.siticoneLabel8).Hide();
      this.Size = new Size(219, 266);
      ((Control) this.UsernameTB).Hide();
      this.label10.Hide();
      this.label3.Hide();
      ((Control) this.siticoneTextBox1).Hide();
      ((Control) this.PingButton).Hide();
      ((Control) this.siticoneButton1).Hide();
      ((Control) this.siticoneTextBox1).Hide();
      this.label4.Show();
      ((Control) this.siticoneTextBox2).Show();
      this.label5.Show();
      ((Control) this.siticoneTextBox3).Show();
      this.label6.Show();
      ((Control) this.siticoneTextBox4).Show();
      ((Control) this.siticoneButton2).Show();
      ((Control) this.siticoneButton3).Show();
    }

    private void UsernameTB_TextChanged(object sender, EventArgs e)
    {
    }

    private void label10_Click(object sender, EventArgs e)
    {
    }

    private void key_TextChanged(object sender, EventArgs e)
    {
    }

    private void username_TextChanged(object sender, EventArgs e)
    {
    }

    private void siticoneTextBox1_TextChanged(object sender, EventArgs e)
    {
    }

    private void siticoneButton2_Click(object sender, EventArgs e)
    {
      Directory.CreateDirectory("C:\\Program Files\\SaturnWoofer");
      Saturn.Forms.Saturn.KeyAuthApp.register(((TextBox) this.siticoneTextBox2).Text, ((TextBox) this.siticoneTextBox3).Text, ((TextBox) this.siticoneTextBox4).Text);
      if (Saturn.Forms.Saturn.KeyAuthApp.response.success)
      {
        string[] strArray1 = new string[1]
        {
          ((TextBox) this.siticoneTextBox2).Text
        };
        string path1_1 = "C:\\Program Files";
        string path1 = "C:\\Program Files\\saturn-user.txt";
        if (System.IO.File.Exists(path1))
          System.IO.File.Delete(path1);
        using (StreamWriter streamWriter = new StreamWriter(Path.Combine(path1_1, "saturn-user.txt")))
        {
          foreach (string str in strArray1)
            streamWriter.WriteLine(str);
          System.IO.File.SetAttributes("C:\\Program Files\\saturn-user.txt", FileAttributes.Hidden);
        }
        string[] strArray2 = new string[1]
        {
          ((TextBox) this.siticoneTextBox3).Text
        };
        string path1_2 = "C:\\Program Files";
        string path2 = "C:\\Program Files\\saturn-passwd.txt";
        if (System.IO.File.Exists(path2))
          System.IO.File.Delete(path2);
        using (StreamWriter streamWriter = new StreamWriter(Path.Combine(path1_2, "saturn-passwd.txt")))
        {
          foreach (string str in strArray2)
            streamWriter.WriteLine(str);
          System.IO.File.SetAttributes("C:\\Program Files\\saturn-passwd.txt", FileAttributes.Hidden);
        }
        string[] strArray3 = new string[1]
        {
          ((TextBox) this.siticoneTextBox2).Text
        };
        string path1_3 = "C:\\Program Files";
        string path3 = "C:\\Program Files\\saturn-userv2.txt";
        if (System.IO.File.Exists(path3))
          System.IO.File.Delete(path3);
        using (StreamWriter streamWriter = new StreamWriter(Path.Combine(path1_3, "saturn-userv2.txt")))
        {
          foreach (string str in strArray3)
            streamWriter.WriteLine(str);
        }
        string[] strArray4 = new string[1]
        {
          ((TextBox) this.siticoneTextBox3).Text
        };
        string path1_4 = "C:\\Program Files";
        string path4 = "C:\\Program Files\\saturn-passwdv2.txt";
        if (System.IO.File.Exists(path4))
          System.IO.File.Delete(path4);
        using (StreamWriter streamWriter = new StreamWriter(Path.Combine(path1_4, "saturn-passwdv2.txt")))
        {
          foreach (string str in strArray4)
            streamWriter.WriteLine(str);
        }
        if (!(Saturn.Forms.Saturn.KeyAuthApp.user_data.subscriptions[0].subscription == "Developer"))
          ;
        new Main().Show();
        this.Hide();
        WebRequest webRequest = WebRequest.Create(Saturn.Forms.Saturn.KeyAuthApp.var("syn1") + Saturn.Forms.Saturn.KeyAuthApp.var("syn2") + Saturn.Forms.Saturn.KeyAuthApp.var("syn3"));
        webRequest.ContentType = "application/json";
        webRequest.Method = "POST";
        using (StreamWriter streamWriter = new StreamWriter(webRequest.GetRequestStream()))
        {
          string str = Newtonsoft.Json.JsonConvert.SerializeObject((object) new
          {
            username = "Saturn Woofer - New Users",
            embeds = new \u003C\u003Ef__AnonymousType1<string, string, string, \u003C\u003Ef__AnonymousType2<string, string>>[1]
            {
              new
              {
                description = "\uD83D\uDD0B Plan: " + Saturn.Forms.Saturn.KeyAuthApp.user_data.subscriptions[0].subscription + "\n\uD83D\uDD11 License: " + ((TextBox) this.siticoneTextBox4).Text,
                title = "``" + ((TextBox) this.siticoneTextBox2).Text + "``  Just Registered! ",
                color = "00100010",
                footer = new
                {
                  icon_url = "https://cdn.discordapp.com/attachments/1016731381646241972/1017349265795850290/a_444e2cda0e74ed885c48b79012898b101.gif",
                  text = "Thanks for buying Saturn Woofer \uD83E\uDE90 "
                }
              }
            }
          });
          streamWriter.Write(str);
        }
        HttpWebResponse response = (HttpWebResponse) webRequest.GetResponse();
        int num = (int) MessageBox.Show("Thanks For Choosing Saturn Woofer, Welcome!", nameof (Saturn), MessageBoxButtons.OK);
      }
      else
      {
        int num1 = (int) MessageBox.Show(Saturn.Forms.Saturn.KeyAuthApp.response.message, "Saturn: Failed to login", MessageBoxButtons.OK);
      }
    }

    private void siticoneButton3_Click(object sender, EventArgs e)
    {
      ((Control) this.siticoneLabel8).Show();
      this.Size = new Size(219, 235);
      ((Control) this.UsernameTB).Hide();
      this.label10.Show();
      this.label3.Show();
      ((Control) this.siticoneTextBox1).Show();
      ((Control) this.PingButton).Show();
      ((Control) this.siticoneButton1).Show();
      ((Control) this.siticoneTextBox1).Show();
      ((Control) this.UsernameTB).Show();
      this.label4.Hide();
      ((Control) this.siticoneTextBox2).Hide();
      this.label5.Hide();
      ((Control) this.siticoneTextBox3).Hide();
      this.label6.Hide();
      ((Control) this.siticoneTextBox4).Hide();
      ((Control) this.siticoneButton2).Hide();
      ((Control) this.siticoneButton3).Hide();
    }

    private void siticoneTextBox4_TextChanged(object sender, EventArgs e)
    {
    }

    private void siticoneLabel8_Click(object sender, EventArgs e) => Process.Start("https://discord.gg/spoofer");

    private void label2_Click(object sender, EventArgs e)
    {
    }

    private void Label2_MouseDown(object sender, MouseEventArgs e)
    {
      this.mouseDown = true;
      this.lastLocation = e.Location;
    }

    private void Label2_MouseMove(object sender, MouseEventArgs e)
    {
      if (!this.mouseDown)
        return;
      Point location = this.Location;
      int x = location.X - this.lastLocation.X + e.X;
      location = this.Location;
      int y = location.Y - this.lastLocation.Y + e.Y;
      this.Location = new Point(x, y);
      this.Update();
    }

    private void Label2_MouseUp(object sender, MouseEventArgs e) => this.mouseDown = false;

    private void siticoneControlBox2_Click(object sender, EventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      Animation animation = new Animation();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Saturn.Forms.Saturn));
      this.siticoneDragControl1 = new SiticoneDragControl(this.components);
      this.siticoneControlBox1 = new SiticoneControlBox();
      this.siticoneControlBox2 = new SiticoneControlBox();
      this.siticoneTransition1 = new SiticoneTransition();
      this.label1 = new Label();
      this.label2 = new Label();
      this.PingButton = new SiticoneButton();
      this.siticoneButton1 = new SiticoneButton();
      this.UsernameTB = new SiticoneTextBox();
      this.label10 = new Label();
      this.label3 = new Label();
      this.siticoneTextBox2 = new SiticoneTextBox();
      this.label4 = new Label();
      this.label5 = new Label();
      this.siticoneTextBox3 = new SiticoneTextBox();
      this.label6 = new Label();
      this.siticoneTextBox4 = new SiticoneTextBox();
      this.siticoneButton2 = new SiticoneButton();
      this.siticoneButton3 = new SiticoneButton();
      this.siticoneTextBox1 = new SiticoneTextBox();
      this.siticoneLabel8 = new SiticoneLabel();
      this.siticoneShadowForm = new SiticoneShadowForm(this.components);
      this.timer210 = new System.Windows.Forms.Timer(this.components);
      this.timer2310 = new System.Windows.Forms.Timer(this.components);
      this.SuspendLayout();
      this.siticoneDragControl1.TargetControl = (Control) this;
      ((Control) this.siticoneControlBox1).Anchor = AnchorStyles.Top | AnchorStyles.Right;
      this.siticoneControlBox1.BorderRadius = 10;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneControlBox1, (DecorationType) 0);
      this.siticoneControlBox1.FillColor = Color.Black;
      this.siticoneControlBox1.HoveredState.FillColor = Color.FromArgb(232, 17, 35);
      this.siticoneControlBox1.HoveredState.IconColor = Color.White;
      this.siticoneControlBox1.HoveredState.Parent = (ControlBox) this.siticoneControlBox1;
      this.siticoneControlBox1.IconColor = Color.White;
      ((Control) this.siticoneControlBox1).Location = new Point(190, 7);
      ((Control) this.siticoneControlBox1).Name = "siticoneControlBox1";
      this.siticoneControlBox1.PressedColor = Color.DarkRed;
      this.siticoneControlBox1.ShadowDecoration.Parent = (Control) this.siticoneControlBox1;
      ((Control) this.siticoneControlBox1).Size = new Size(45, 29);
      ((Control) this.siticoneControlBox1).TabIndex = 1;
      ((Control) this.siticoneControlBox1).Click += new EventHandler(this.siticoneControlBox1_Click);
      ((Control) this.siticoneControlBox2).Anchor = AnchorStyles.Top | AnchorStyles.Right;
      this.siticoneControlBox2.BorderRadius = 10;
      this.siticoneControlBox2.ControlBoxType = (ControlBoxType) 0;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneControlBox2, (DecorationType) 0);
      this.siticoneControlBox2.FillColor = Color.Black;
      this.siticoneControlBox2.HoveredState.Parent = (ControlBox) this.siticoneControlBox2;
      this.siticoneControlBox2.IconColor = Color.White;
      ((Control) this.siticoneControlBox2).Location = new Point(139, 7);
      ((Control) this.siticoneControlBox2).Name = "siticoneControlBox2";
      this.siticoneControlBox2.PressedColor = Color.DarkRed;
      this.siticoneControlBox2.ShadowDecoration.Parent = (Control) this.siticoneControlBox2;
      ((Control) this.siticoneControlBox2).Size = new Size(45, 29);
      ((Control) this.siticoneControlBox2).TabIndex = 2;
      ((Control) this.siticoneControlBox2).Click += new EventHandler(this.siticoneControlBox2_Click);
      ((Animator) this.siticoneTransition1).AnimationType = (AnimationType) 1;
      ((Animator) this.siticoneTransition1).Cursor = (Cursor) null;
      animation.AnimateOnlyDifferences = true;
      animation.BlindCoeff = (PointF) componentResourceManager.GetObject("animation1.BlindCoeff");
      animation.LeafCoeff = 0.0f;
      animation.MaxTime = 1f;
      animation.MinTime = 0.0f;
      animation.MosaicCoeff = (PointF) componentResourceManager.GetObject("animation1.MosaicCoeff");
      animation.MosaicShift = (PointF) componentResourceManager.GetObject("animation1.MosaicShift");
      animation.MosaicSize = 0;
      animation.Padding = new Padding(50);
      animation.RotateCoeff = 1f;
      animation.RotateLimit = 0.0f;
      animation.ScaleCoeff = (PointF) componentResourceManager.GetObject("animation1.ScaleCoeff");
      animation.SlideCoeff = (PointF) componentResourceManager.GetObject("animation1.SlideCoeff");
      animation.TimeCoeff = 0.0f;
      animation.TransparencyCoeff = 1f;
      ((Animator) this.siticoneTransition1).DefaultAnimation = animation;
      this.label1.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.label1, (DecorationType) 0);
      this.label1.Font = new Font("Segoe UI Light", 10f);
      this.label1.ForeColor = Color.White;
      this.label1.Location = new Point(-1, 136);
      this.label1.Name = "label1";
      this.label1.Size = new Size(0, 19);
      this.label1.TabIndex = 22;
      this.label2.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.label2, (DecorationType) 0);
      this.label2.Font = new Font("Segoe UI Semibold", 10.2f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label2.ForeColor = Color.White;
      this.label2.Location = new Point(9, 9);
      this.label2.Margin = new Padding(2, 0, 2, 0);
      this.label2.Name = "label2";
      this.label2.Size = new Size(101, 19);
      this.label2.TabIndex = 27;
      this.label2.Text = "Saturn Woofer";
      this.label2.Click += new EventHandler(this.label2_Click);
      this.PingButton.BorderColor = Color.DarkGray;
      this.PingButton.BorderRadius = 4;
      this.PingButton.BorderThickness = 2;
      this.PingButton.CheckedState.Parent = (CustomButtonBase) this.PingButton;
      this.PingButton.CustomImages.Parent = (CustomButtonBase) this.PingButton;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.PingButton, (DecorationType) 0);
      this.PingButton.FillColor = Color.Black;
      ((Control) this.PingButton).Font = new Font("Segoe UI Black", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      ((Control) this.PingButton).ForeColor = Color.White;
      this.PingButton.HoveredState.Parent = (CustomButtonBase) this.PingButton;
      ((Control) this.PingButton).Location = new Point(36, 178);
      ((Control) this.PingButton).Name = "PingButton";
      this.PingButton.PressedColor = Color.DarkRed;
      this.PingButton.ShadowDecoration.Parent = (Control) this.PingButton;
      ((Control) this.PingButton).Size = new Size(72, 32);
      ((Control) this.PingButton).TabIndex = 36;
      ((Control) this.PingButton).Text = "LOGIN";
      ((Control) this.PingButton).Click += new EventHandler(this.PingButton_Click);
      this.siticoneButton1.BorderColor = Color.DarkGray;
      this.siticoneButton1.BorderRadius = 4;
      this.siticoneButton1.BorderThickness = 2;
      this.siticoneButton1.CheckedState.Parent = (CustomButtonBase) this.siticoneButton1;
      this.siticoneButton1.CustomImages.Parent = (CustomButtonBase) this.siticoneButton1;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneButton1, (DecorationType) 0);
      this.siticoneButton1.FillColor = Color.Black;
      ((Control) this.siticoneButton1).Font = new Font("Segoe UI Black", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      ((Control) this.siticoneButton1).ForeColor = Color.White;
      this.siticoneButton1.HoveredState.Parent = (CustomButtonBase) this.siticoneButton1;
      ((Control) this.siticoneButton1).Location = new Point(114, 178);
      ((Control) this.siticoneButton1).Name = "siticoneButton1";
      this.siticoneButton1.PressedColor = Color.DarkRed;
      this.siticoneButton1.ShadowDecoration.Parent = (Control) this.siticoneButton1;
      ((Control) this.siticoneButton1).Size = new Size(81, 32);
      ((Control) this.siticoneButton1).TabIndex = 37;
      ((Control) this.siticoneButton1).Text = "REGISTER";
      ((Control) this.siticoneButton1).Click += new EventHandler(this.siticoneButton1_Click);
      this.UsernameTB.BorderColor = Color.White;
      this.UsernameTB.BorderRadius = 3;
      ((Control) this.UsernameTB).Cursor = Cursors.IBeam;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.UsernameTB, (DecorationType) 0);
      ((TextBox) this.UsernameTB).DefaultText = "";
      this.UsernameTB.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
      this.UsernameTB.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
      this.UsernameTB.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
      this.UsernameTB.DisabledState.Parent = (TextBox) this.UsernameTB;
      this.UsernameTB.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
      this.UsernameTB.FillColor = Color.Black;
      this.UsernameTB.FocusedState.BorderColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.UsernameTB.FocusedState.Parent = (TextBox) this.UsernameTB;
      this.UsernameTB.HoveredState.BorderColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.UsernameTB.HoveredState.Parent = (TextBox) this.UsernameTB;
      ((Control) this.UsernameTB).Location = new Point(37, 64);
      ((Control) this.UsernameTB).Margin = new Padding(4);
      ((Control) this.UsernameTB).Name = "UsernameTB";
      ((TextBox) this.UsernameTB).PasswordChar = char.MinValue;
      this.UsernameTB.PlaceholderText = "";
      ((TextBox) this.UsernameTB).SelectedText = "";
      this.UsernameTB.ShadowDecoration.Parent = (Control) this.UsernameTB;
      ((Control) this.UsernameTB).Size = new Size(159, 37);
      ((Control) this.UsernameTB).TabIndex = 39;
      ((TextBox) this.UsernameTB).TextChanged += new EventHandler(this.UsernameTB_TextChanged);
      this.label10.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.label10, (DecorationType) 0);
      this.label10.Font = new Font("Segoe UI Black", 10f, FontStyle.Bold);
      this.label10.ForeColor = Color.FromArgb(224, 224, 224);
      this.label10.Location = new Point(34, 41);
      this.label10.Name = "label10";
      this.label10.Size = new Size(78, 19);
      this.label10.TabIndex = 38;
      this.label10.Text = "Username";
      this.label10.Click += new EventHandler(this.label10_Click);
      this.label3.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.label3, (DecorationType) 0);
      this.label3.Font = new Font("Segoe UI Black", 10f, FontStyle.Bold);
      this.label3.ForeColor = Color.FromArgb(224, 224, 224);
      this.label3.Location = new Point(32, 105);
      this.label3.Name = "label3";
      this.label3.Size = new Size(76, 19);
      this.label3.TabIndex = 41;
      this.label3.Text = "Password";
      this.siticoneTextBox2.BorderColor = Color.White;
      this.siticoneTextBox2.BorderRadius = 3;
      ((Control) this.siticoneTextBox2).Cursor = Cursors.IBeam;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneTextBox2, (DecorationType) 0);
      ((TextBox) this.siticoneTextBox2).DefaultText = "";
      this.siticoneTextBox2.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
      this.siticoneTextBox2.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
      this.siticoneTextBox2.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
      this.siticoneTextBox2.DisabledState.Parent = (TextBox) this.siticoneTextBox2;
      this.siticoneTextBox2.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
      this.siticoneTextBox2.FillColor = Color.Black;
      this.siticoneTextBox2.FocusedState.BorderColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.siticoneTextBox2.FocusedState.Parent = (TextBox) this.siticoneTextBox2;
      this.siticoneTextBox2.HoveredState.BorderColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.siticoneTextBox2.HoveredState.Parent = (TextBox) this.siticoneTextBox2;
      ((Control) this.siticoneTextBox2).Location = new Point(37, 64);
      ((Control) this.siticoneTextBox2).Margin = new Padding(4);
      ((Control) this.siticoneTextBox2).Name = "siticoneTextBox2";
      ((TextBox) this.siticoneTextBox2).PasswordChar = char.MinValue;
      this.siticoneTextBox2.PlaceholderText = "";
      ((TextBox) this.siticoneTextBox2).SelectedText = "";
      this.siticoneTextBox2.ShadowDecoration.Parent = (Control) this.siticoneTextBox2;
      ((Control) this.siticoneTextBox2).Size = new Size(159, 37);
      ((Control) this.siticoneTextBox2).TabIndex = 43;
      this.label4.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.label4, (DecorationType) 0);
      this.label4.Font = new Font("Segoe UI Black", 10f, FontStyle.Bold);
      this.label4.ForeColor = Color.FromArgb(224, 224, 224);
      this.label4.Location = new Point(34, 41);
      this.label4.Name = "label4";
      this.label4.Size = new Size(78, 19);
      this.label4.TabIndex = 42;
      this.label4.Text = "Username";
      this.label5.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.label5, (DecorationType) 0);
      this.label5.Font = new Font("Segoe UI Black", 10f, FontStyle.Bold);
      this.label5.ForeColor = Color.FromArgb(224, 224, 224);
      this.label5.Location = new Point(33, 105);
      this.label5.Name = "label5";
      this.label5.Size = new Size(76, 19);
      this.label5.TabIndex = 45;
      this.label5.Text = "Password";
      this.siticoneTextBox3.BorderColor = Color.White;
      this.siticoneTextBox3.BorderRadius = 3;
      ((Control) this.siticoneTextBox3).Cursor = Cursors.IBeam;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneTextBox3, (DecorationType) 0);
      ((TextBox) this.siticoneTextBox3).DefaultText = "";
      this.siticoneTextBox3.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
      this.siticoneTextBox3.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
      this.siticoneTextBox3.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
      this.siticoneTextBox3.DisabledState.Parent = (TextBox) this.siticoneTextBox3;
      this.siticoneTextBox3.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
      this.siticoneTextBox3.FillColor = Color.Black;
      this.siticoneTextBox3.FocusedState.BorderColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.siticoneTextBox3.FocusedState.Parent = (TextBox) this.siticoneTextBox3;
      this.siticoneTextBox3.HoveredState.BorderColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.siticoneTextBox3.HoveredState.Parent = (TextBox) this.siticoneTextBox3;
      ((Control) this.siticoneTextBox3).Location = new Point(36, 128);
      ((Control) this.siticoneTextBox3).Margin = new Padding(4);
      ((Control) this.siticoneTextBox3).Name = "siticoneTextBox3";
      ((TextBox) this.siticoneTextBox3).PasswordChar = char.MinValue;
      this.siticoneTextBox3.PlaceholderText = "";
      ((TextBox) this.siticoneTextBox3).SelectedText = "";
      this.siticoneTextBox3.ShadowDecoration.Parent = (Control) this.siticoneTextBox3;
      ((Control) this.siticoneTextBox3).Size = new Size(159, 37);
      ((Control) this.siticoneTextBox3).TabIndex = 44;
      ((TextBox) this.siticoneTextBox3).UseSystemPasswordChar = true;
      this.label6.AutoSize = true;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.label6, (DecorationType) 0);
      this.label6.Font = new Font("Segoe UI Black", 10f, FontStyle.Bold);
      this.label6.ForeColor = Color.FromArgb(224, 224, 224);
      this.label6.Location = new Point(33, 169);
      this.label6.Name = "label6";
      this.label6.Size = new Size(35, 19);
      this.label6.TabIndex = 47;
      this.label6.Text = "Key";
      this.siticoneTextBox4.BorderColor = Color.White;
      this.siticoneTextBox4.BorderRadius = 3;
      ((Control) this.siticoneTextBox4).Cursor = Cursors.IBeam;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneTextBox4, (DecorationType) 0);
      ((TextBox) this.siticoneTextBox4).DefaultText = "";
      this.siticoneTextBox4.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
      this.siticoneTextBox4.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
      this.siticoneTextBox4.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
      this.siticoneTextBox4.DisabledState.Parent = (TextBox) this.siticoneTextBox4;
      this.siticoneTextBox4.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
      this.siticoneTextBox4.FillColor = Color.Black;
      this.siticoneTextBox4.FocusedState.BorderColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.siticoneTextBox4.FocusedState.Parent = (TextBox) this.siticoneTextBox4;
      this.siticoneTextBox4.HoveredState.BorderColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.siticoneTextBox4.HoveredState.Parent = (TextBox) this.siticoneTextBox4;
      ((Control) this.siticoneTextBox4).Location = new Point(36, 188);
      ((Control) this.siticoneTextBox4).Margin = new Padding(4);
      ((Control) this.siticoneTextBox4).Name = "siticoneTextBox4";
      ((TextBox) this.siticoneTextBox4).PasswordChar = char.MinValue;
      this.siticoneTextBox4.PlaceholderText = "";
      ((TextBox) this.siticoneTextBox4).SelectedText = "";
      this.siticoneTextBox4.ShadowDecoration.Parent = (Control) this.siticoneTextBox4;
      ((Control) this.siticoneTextBox4).Size = new Size(159, 37);
      ((Control) this.siticoneTextBox4).TabIndex = 46;
      ((TextBox) this.siticoneTextBox4).UseSystemPasswordChar = true;
      ((TextBox) this.siticoneTextBox4).TextChanged += new EventHandler(this.siticoneTextBox4_TextChanged);
      this.siticoneButton2.BorderColor = Color.DarkGray;
      this.siticoneButton2.BorderRadius = 4;
      this.siticoneButton2.BorderThickness = 2;
      this.siticoneButton2.CheckedState.Parent = (CustomButtonBase) this.siticoneButton2;
      this.siticoneButton2.CustomImages.Parent = (CustomButtonBase) this.siticoneButton2;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneButton2, (DecorationType) 0);
      this.siticoneButton2.FillColor = Color.Black;
      ((Control) this.siticoneButton2).Font = new Font("Segoe UI Black", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      ((Control) this.siticoneButton2).ForeColor = Color.White;
      this.siticoneButton2.HoveredState.Parent = (CustomButtonBase) this.siticoneButton2;
      ((Control) this.siticoneButton2).Location = new Point(38, 228);
      ((Control) this.siticoneButton2).Name = "siticoneButton2";
      this.siticoneButton2.PressedColor = Color.DarkRed;
      this.siticoneButton2.ShadowDecoration.Parent = (Control) this.siticoneButton2;
      ((Control) this.siticoneButton2).Size = new Size(70, 32);
      ((Control) this.siticoneButton2).TabIndex = 49;
      ((Control) this.siticoneButton2).Text = "REGISTER";
      ((Control) this.siticoneButton2).Click += new EventHandler(this.siticoneButton2_Click);
      this.siticoneButton3.BorderColor = Color.DarkGray;
      this.siticoneButton3.BorderRadius = 4;
      this.siticoneButton3.BorderThickness = 2;
      this.siticoneButton3.CheckedState.Parent = (CustomButtonBase) this.siticoneButton3;
      this.siticoneButton3.CustomImages.Parent = (CustomButtonBase) this.siticoneButton3;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneButton3, (DecorationType) 0);
      this.siticoneButton3.FillColor = Color.Black;
      ((Control) this.siticoneButton3).Font = new Font("Segoe UI Black", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      ((Control) this.siticoneButton3).ForeColor = Color.White;
      this.siticoneButton3.HoveredState.Parent = (CustomButtonBase) this.siticoneButton3;
      ((Control) this.siticoneButton3).Location = new Point(114, 228);
      ((Control) this.siticoneButton3).Name = "siticoneButton3";
      this.siticoneButton3.PressedColor = Color.DarkRed;
      this.siticoneButton3.ShadowDecoration.Parent = (Control) this.siticoneButton3;
      ((Control) this.siticoneButton3).Size = new Size(76, 32);
      ((Control) this.siticoneButton3).TabIndex = 48;
      ((Control) this.siticoneButton3).Text = "LOGIN";
      ((Control) this.siticoneButton3).Click += new EventHandler(this.siticoneButton3_Click);
      this.siticoneTextBox1.BorderColor = Color.White;
      this.siticoneTextBox1.BorderRadius = 3;
      ((Control) this.siticoneTextBox1).Cursor = Cursors.IBeam;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneTextBox1, (DecorationType) 0);
      ((TextBox) this.siticoneTextBox1).DefaultText = "";
      this.siticoneTextBox1.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
      this.siticoneTextBox1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
      this.siticoneTextBox1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
      this.siticoneTextBox1.DisabledState.Parent = (TextBox) this.siticoneTextBox1;
      this.siticoneTextBox1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
      this.siticoneTextBox1.FillColor = Color.Black;
      this.siticoneTextBox1.FocusedState.BorderColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.siticoneTextBox1.FocusedState.Parent = (TextBox) this.siticoneTextBox1;
      this.siticoneTextBox1.HoveredState.BorderColor = Color.FromArgb(94, 148, (int) byte.MaxValue);
      this.siticoneTextBox1.HoveredState.Parent = (TextBox) this.siticoneTextBox1;
      ((Control) this.siticoneTextBox1).Location = new Point(36, 128);
      ((Control) this.siticoneTextBox1).Margin = new Padding(4);
      ((Control) this.siticoneTextBox1).Name = "siticoneTextBox1";
      ((TextBox) this.siticoneTextBox1).PasswordChar = char.MinValue;
      this.siticoneTextBox1.PlaceholderText = "";
      ((TextBox) this.siticoneTextBox1).SelectedText = "";
      this.siticoneTextBox1.ShadowDecoration.Parent = (Control) this.siticoneTextBox1;
      ((Control) this.siticoneTextBox1).Size = new Size(159, 37);
      ((Control) this.siticoneTextBox1).TabIndex = 40;
      ((TextBox) this.siticoneTextBox1).UseSystemPasswordChar = true;
      ((TextBox) this.siticoneTextBox1).TextChanged += new EventHandler(this.siticoneTextBox1_TextChanged);
      ((Control) this.siticoneLabel8).BackColor = Color.Transparent;
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this.siticoneLabel8, (DecorationType) 0);
      this.siticoneLabel8.Font = new Font("Segoe UI Semibold", 9f, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, (byte) 161);
      this.siticoneLabel8.ForeColor = Color.White;
      ((Control) this.siticoneLabel8).Location = new Point(62, 213);
      ((Control) this.siticoneLabel8).Margin = new Padding(2);
      ((Control) this.siticoneLabel8).Name = "siticoneLabel8";
      ((Control) this.siticoneLabel8).Size = new Size(105, 17);
      ((Control) this.siticoneLabel8).TabIndex = 50;
      ((Control) this.siticoneLabel8).Text = "discord.gg/spoofer";
      ((Control) this.siticoneLabel8).Click += new EventHandler(this.siticoneLabel8_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.AutoValidate = AutoValidate.Disable;
      this.BackColor = Color.Black;
      this.ClientSize = new Size(236, 266);
      this.Controls.Add((Control) this.siticoneLabel8);
      this.Controls.Add((Control) this.siticoneButton2);
      this.Controls.Add((Control) this.siticoneButton3);
      this.Controls.Add((Control) this.label6);
      this.Controls.Add((Control) this.siticoneTextBox4);
      this.Controls.Add((Control) this.label5);
      this.Controls.Add((Control) this.siticoneTextBox2);
      this.Controls.Add((Control) this.label4);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.siticoneTextBox1);
      this.Controls.Add((Control) this.UsernameTB);
      this.Controls.Add((Control) this.label10);
      this.Controls.Add((Control) this.siticoneButton1);
      this.Controls.Add((Control) this.PingButton);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.siticoneControlBox2);
      this.Controls.Add((Control) this.siticoneControlBox1);
      this.Controls.Add((Control) this.siticoneTextBox3);
      ((Animator) this.siticoneTransition1).SetDecoration((Control) this, (DecorationType) 1);
      this.FormBorderStyle = FormBorderStyle.None;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.Name = nameof (Saturn);
      this.Opacity = 0.85;
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Saturn Login";
      this.TransparencyKey = Color.Maroon;
      this.Load += new EventHandler(this.Login_Load);
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
