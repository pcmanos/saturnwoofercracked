﻿// Decompiled with JetBrains decompiler
// Type: Saturn.Resources.Program
// Assembly: Saturn, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 782363C4-840F-42BB-9DE3-89C9DB6D215C
// Assembly location: C:\Users\xande\Desktop\32 bit spy\unpacked_saturn.exe

using System;
using System.Windows.Forms;

namespace Saturn.Resources
{
  internal static class Program
  {
    [STAThread]
    private static void Main()
    {
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run((Form) new Saturn.Forms.Saturn());
    }
  }
}
