﻿// Decompiled with JetBrains decompiler
// Type: Saturn.Class1
// Assembly: Saturn, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 782363C4-840F-42BB-9DE3-89C9DB6D215C
// Assembly location: C:\Users\xande\Desktop\32 bit spy\unpacked_saturn.exe

using Microsoft.Win32;
using System;
using System.Linq;

namespace Saturn
{
  internal class Class1
  {
    private string generatedID;
    private static Random random = new Random();
    private string[] registryKeys = new string[7]
    {
      "Hardware\\Description\\System\\CentralProcessor\\0",
      "HARDWARE\\DEVICEMAP\\Scsi\\Scsi Port 0\\Scsi Bus 0\\Target Id 0\\Logical Unit Id 0",
      "SYSTEM\\CurrentControlSet\\Control\\SystemInformation",
      "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion",
      "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WindowsUpdate",
      "SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}\\0001",
      "SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}\\0012"
    };
    private string[,] registryKeysValues = new string[7, 7]
    {
      {
        "SystemProductName",
        "Identifier",
        "Previous Update Revision",
        "ProcessorNameString",
        "VendorIdentifier",
        "Platform Specific Field1",
        "Component Information"
      },
      {
        "SerialNumber",
        "Identifier",
        "SystemManufacturer",
        "nop",
        "nop",
        "nop",
        "nop"
      },
      {
        "ComputerHardwareId",
        "ComputerHardwareIds",
        "BIOSVendor",
        "ProductId",
        "ProcessorNameString",
        "BIOSReleaseDate",
        "nop"
      },
      {
        "ProductId",
        "InstallDate",
        "InstallTime",
        "nop",
        "nop",
        "nop",
        "nop"
      },
      {
        "SusClientId",
        "nop",
        "nop",
        "nop",
        "nop",
        "nop",
        "nop"
      },
      {
        "NetCfgInstanceId",
        "NetLuidIndex",
        "nop",
        "nop",
        "nop",
        "nop",
        "nop"
      },
      {
        "NetworkAddress",
        "NetCfgInstanceId",
        "NetworkInterfaceInstallTimestamp",
        "nop",
        "nop",
        "nop",
        "nop"
      }
    };

    public static string randomString(int length) => new string(Enumerable.Repeat<string>("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", length).Select<string, char>((Func<string, char>) (s => s[Class1.random.Next(s.Length)])).ToArray<char>());

    public void spoofUserMode()
    {
      this.generatedID = Class1.randomString(20);
      for (int regKeyIndex = 0; regKeyIndex < this.registryKeys.Length; ++regKeyIndex)
        this.spoofRegistryKey(regKeyIndex);
    }

    private void spoofRegistryKey(int regKeyIndex)
    {
      RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(this.registryKeys[regKeyIndex], true);
      if (registryKey == null)
        return;
      for (int index = 0; index < this.registryKeysValues.GetLength(1) && !(this.registryKeysValues[regKeyIndex, index] == "nop"); ++index)
      {
        registryKey.SetValue(this.registryKeysValues[regKeyIndex, index], (object) this.generatedID);
        this.generatedID = Class1.randomString(20);
      }
      registryKey.Close();
    }

    public string[] getSpoofingRegistryKeys() => this.registryKeys;

    public string[,] getSpoofingRegistryKeyValues() => this.registryKeysValues;
  }
}
